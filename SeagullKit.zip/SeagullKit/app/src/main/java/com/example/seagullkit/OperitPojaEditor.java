package com.example.seagullkit;

import android.content.Context;
import android.content.pm.PackageManager;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Operit 破甲注入器（操作者运行基线 v5N 双层协同注入内核）。
 *
 * ══════════════════════════════════════════════════════════════
 * 一、为什么打角色卡，而不是打 APK
 * ══════════════════════════════════════════════════════════════
 * Operit 的 system prompt 不是硬编码的，而是每次发请求前现场拼出来的：
 *
 *     messages[0].content =
 *          角色卡.character_setting
 *        + 角色卡.other_content_chat
 *        + 角色卡.advanced_custom_prompt
 *        + "包系统 / Available packages: ..."
 *
 * 也就是说：**谁控制角色卡字段的首尾，谁就控制 system 消息。**
 * 改 APK 要重签名、要卸载重装、每次升级重来；改配置面一次到位、不动签名。
 *
 * ══════════════════════════════════════════════════════════════
 * 二、双层槽位怎么摆
 * ══════════════════════════════════════════════════════════════
 *   槽位 A  character_setting          → 请求体最前（地基权重）
 *   槽位 B  advanced_custom_prompt     → 请求体最末（近因权重，最贴近用户消息）
 *
 * 实测拼装顺序：
 *   [槽位A 载荷] → [宿主原人设] → [other_content_chat] → [槽位B 载荷] → [包系统]
 *
 * 首尾双向夹击 = v5N 设计里的「槽位A + 槽位B 双层镜像」。
 * 槽位 A 里宿主原人设**完整保留**，只做叠加不做替换。
 *
 * ══════════════════════════════════════════════════════════════
 * 三、DataStore protobuf 结构
 * ══════════════════════════════════════════════════════════════
 * character_cards.preferences_pb 是 AndroidX DataStore 的 Preferences 格式：
 *
 *   message PreferenceMap { map<string, Value> preferences = 1; }
 *   message Value { oneof {
 *       bool boolean=1; float float=2; int32 integer=3; int64 long=4;
 *       string string=5; StringSet string_set=6; double double=7; bytes bytes=8; } }
 *
 * 手写解析/编码，不引 protobuf 依赖。**动数据前先做无损往返自检**
 * （不改内容重新编码，必须字节完全一致），否则写坏 DataStore 会让
 * App 抛 CorruptionException 把角色卡清空。
 *
 * ══════════════════════════════════════════════════════════════
 * 四、执行方式（沿用 DshConfigEditor 踩过的坑）
 * ══════════════════════════════════════════════════════════════
 *   1) 脚本经 su 的 stdin 管道送入，不在命令行拼接（su -c 会被多层 shell 吃掉引号）
 *   2) 必须优先 su -M（KernelSU --mount-master）。App 默认继承私有挂载命名空间，
 *      那里面 /data/data 可能是 tmpfs 影子，看不到 /data/data/<别的包>——
 *      不 -M 的话会出现「读到的文件根本不是目标 App 的」这种鬼故事
 *   3) 二进制读写一律走 base64，避免 stdout 里混进日志把二进制搞坏
 *   4) 写入前 force-stop 目标 App，否则它内存里的状态会覆盖你的写入
 *   5) 写完必须还原属主/权限（从原文件 stat 现取，不硬编码 uid）
 *
 * 需要 root。
 */
public class OperitPojaEditor {

    public static final String OPERIT_PKG = "com.ai.assistance.operit";

    /** 角色卡 DataStore 文件（宿主真实路径，经 su -M 访问） */
    public static final String PB_PATH =
            "/data/data/" + OPERIT_PKG + "/files/datastore/character_cards.preferences_pb";

    /** Operit 运行日志：请求体会被打进去，用来做端到端验证 */
    public static final String LOG_PATH =
            "/data/data/" + OPERIT_PKG + "/files/logs/operit.log";

    /** 备份目录（由 root 脚本创建，App 自己没存储权限也没关系） */
    public static final String BACKUP_DIR = "/sdcard/SeagullKit/operit-backup";

    /** 载荷锚点：用来判断某个槽位是否已经注入过 */
    public static final String ANCHOR = "[MODE: SANDBOX]";
    public static final String ANCHOR2 = "SUPREME DIRECTIVE";

    /** 默认角色 id（读不到 active_character_card_id 时兜底） */
    private static final String DEFAULT_CARD_ID = "default_character";

    // ══════════════════════════════════════════════════════════
    // 结果模型
    // ══════════════════════════════════════════════════════════

    public static class Result {
        public boolean success;
        public String output = "";
        public String error = "";
    }

    /** 现场快照 */
    public static class Snapshot {
        public boolean success;
        public String error = "";
        public String raw = "";            // 脚本原始输出
        public String cardId = "";
        public String cardName = "";
        public String slotAKey = "";
        public String slotBKey = "";
        public int slotALen;
        public int slotBLen;
        public boolean slotAInjected;
        public boolean slotBInjected;
        public long fileSize;
        public String fileSha = "";
        public String fileOwner = "";
        public int backupCount;
        public boolean appRunning;
        /** 日志里命中锚点的次数：>0 说明注入已经真的进过请求体 */
        public int logHits;
        public String lastResponseHead = "";
    }

    /** 载荷来源 */
    public static class Payload {
        public String text = "";
        public String sha = "";
        public int bytes;
    }

    // ══════════════════════════════════════════════════════════
    // 对外 API
    // ══════════════════════════════════════════════════════════

    public static boolean isOperitInstalled(Context ctx) {
        try {
            ctx.getPackageManager().getPackageInfo(OPERIT_PKG, 0);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    public static boolean hasRoot() {
        String out = runSuSimple("id -u");
        if (out == null) return false;
        for (String line : out.split("\n")) {
            if (line.trim().equals("0")) return true;
        }
        return false;
    }

    /** 从 assets/poja_payload.txt 读载荷 */
    public static Payload loadPayload(Context ctx) {
        Payload p = new Payload();
        try {
            InputStream in = ctx.getAssets().open("poja_payload.txt");
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
            in.close();
            byte[] raw = bos.toByteArray();
            p.text = new String(raw, StandardCharsets.UTF_8);
            p.sha = sha256(raw);
            p.bytes = raw.length;
        } catch (Exception e) {
            p.text = "";
        }
        return p;
    }

    /** 扫描现场：角色卡状态 + 是否已注入 + 日志命中 */
    public static Snapshot scan() {
        Snapshot s = new Snapshot();
        Result meta = exec(root(
                "echo SIZE=$(stat -c %s " + q(PB_PATH) + " 2>/dev/null)\n"
              + "echo OWNER=$(stat -c %u:%g " + q(PB_PATH) + " 2>/dev/null)\n"
              + "echo SHA=$(sha256sum " + q(PB_PATH) + " 2>/dev/null | cut -d' ' -f1)\n"
              + "echo BACKUPS=$(ls " + q(BACKUP_DIR) + "/character_cards.*.pb 2>/dev/null | wc -l)\n"
              + "if pgrep -f " + q(OPERIT_PKG) + " >/dev/null 2>&1; then echo RUNNING=1; else echo RUNNING=0; fi\n"
              + "echo HITS=$(grep -a -c " + q(ANCHOR2) + " " + q(LOG_PATH) + " 2>/dev/null || echo 0)\n"
              + "echo B64_START\n"
              + "base64 " + q(PB_PATH) + " 2>/dev/null\n"
              + "echo B64_END"));
        s.raw = meta.output;
        if (!meta.success && meta.output.isEmpty()) {
            s.error = meta.error;
            return s;
        }

        StringBuilder b64 = new StringBuilder();
        boolean inB64 = false;
        for (String line : meta.output.split("\n")) {
            String t = line.trim();
            if (t.equals("B64_START")) { inB64 = true; continue; }
            if (t.equals("B64_END")) { inB64 = false; continue; }
            if (inB64) { b64.append(t); continue; }
            if (t.startsWith("SIZE=")) s.fileSize = parseLong(t.substring(5));
            else if (t.startsWith("OWNER=")) s.fileOwner = t.substring(6);
            else if (t.startsWith("SHA=")) s.fileSha = t.substring(4);
            else if (t.startsWith("BACKUPS=")) s.backupCount = (int) parseLong(t.substring(8));
            else if (t.startsWith("RUNNING=")) s.appRunning = "1".equals(t.substring(8));
            else if (t.startsWith("HITS=")) s.logHits = (int) parseLong(t.substring(5));
        }

        byte[] pb = base64Decode(b64.toString());
        if (pb == null || pb.length == 0) {
            s.error = "读不到角色卡文件（root 是否可用？su 是否支持 -M？）";
            return s;
        }
        s.fileSize = pb.length;
        s.fileSha = sha256(pb);

        try {
            Map<String, String> vals = stringValues(pb);
            s.cardId = vals.containsKey("active_character_card_id")
                    ? vals.get("active_character_card_id") : DEFAULT_CARD_ID;
            if (s.cardId == null || s.cardId.isEmpty()) s.cardId = DEFAULT_CARD_ID;
            s.slotAKey = "character_card_" + s.cardId + "_character_setting";
            s.slotBKey = "character_card_" + s.cardId + "_advanced_custom_prompt";
            String nameKey = "character_card_" + s.cardId + "_name";
            s.cardName = vals.containsKey(nameKey) ? vals.get(nameKey) : "";
            String a = vals.get(s.slotAKey);
            String b = vals.get(s.slotBKey);
            s.slotALen = a == null ? -1 : a.length();
            s.slotBLen = b == null ? -1 : b.length();
            s.slotAInjected = a != null && a.contains(ANCHOR);
            s.slotBInjected = b != null && b.contains(ANCHOR);
            s.success = true;
        } catch (Exception e) {
            s.error = "protobuf 解析失败：" + e.getMessage();
            return s;
        }

        Result tail = exec(root(
                "grep -a 'Final output summary' " + q(LOG_PATH)
              + " 2>/dev/null | tail -1 | cut -c1-260"));
        s.lastResponseHead = tail.output.trim();
        return s;
    }

    private static long parseLong(String s) {
        try { return Long.parseLong(s.trim()); } catch (Exception e) { return 0; }
    }

    /**
     * 注入。payload 来自 assets/poja_payload.txt。
     *
     * 流程：停 App → base64 读回 pb → Java 侧改写槽位 A/B → 无损自检
     *      → 备份原文件 → 写回 + 还原属主权限 → sha256 校验 → 重启 App
     */
    public static Result inject(Context ctx) {
        Result r = new Result();
        Payload pl = loadPayload(ctx);
        if (pl.text.isEmpty()) {
            r.error = "载荷读取失败（assets/poja_payload.txt）";
            r.output = r.error;
            return r;
        }
        StringBuilder log = new StringBuilder();

        // 1) 停 App + 备份 + 读回
        Result stop = exec(root(
                "am force-stop " + OPERIT_PKG + "\n"
              + "sleep 2\n"
              + "mkdir -p " + q(BACKUP_DIR) + "\n"
              + "TS=$(date +%Y%m%d-%H%M%S)\n"
              + "cp -f " + q(PB_PATH) + " " + q(BACKUP_DIR) + "/character_cards.$TS.pb 2>/dev/null && "
              + "echo \"[*] 已备份 -> " + BACKUP_DIR + "/character_cards.$TS.pb\"\n"
              + "cp -f " + q(PB_PATH) + " " + q(BACKUP_DIR) + "/character_cards.latest.bak 2>/dev/null\n"
              + "stat -c '%u %g' " + q(PB_PATH) + " 2>/dev/null\n"
              + "base64 " + q(PB_PATH) + " 2>/dev/null"));
        log.append(stop.output);
        if (!stop.success && stop.output.isEmpty()) {
            r.error = "root 脚本执行失败：" + stop.error;
            r.output = log.toString();
            return r;
        }

        // 拆出「日志行」与「base64 体」
        String owner = "";
        StringBuilder b64 = new StringBuilder();
        for (String line : stop.output.split("\n")) {
            String t = line.trim();
            if (t.matches("\\d+\\s+\\d+")) { owner = t; continue; }
            if (t.isEmpty() || t.startsWith("[") || t.startsWith("ERR")) continue;
            if (t.matches("[A-Za-z0-9+/=]+")) b64.append(t);
        }
        byte[] orig = base64Decode(b64.toString());
        if (orig == null || orig.length == 0) {
            r.error = "读不到角色卡文件";
            r.output = log.toString();
            return r;
        }

        // 2) Java 侧改写
        byte[] out;
        String slotAKey, slotBKey, cardName;
        try {
            // 无损自检：不改内容重新编码必须字节一致
            byte[] round = rebuild(orig, null);
            if (!Arrays.equals(round, orig)) {
                r.error = "protobuf 编码器无损自检失败（原 " + orig.length
                        + " 字节 / 重编码 " + round.length + " 字节），已中止，未写入任何东西";
                r.output = log.toString() + "\n" + r.error;
                return r;
            }
            log.append("[*] protobuf 无损自检通过（").append(orig.length).append(" 字节）\n");

            Map<String, String> vals = stringValues(orig);
            String cardId = vals.containsKey("active_character_card_id")
                    ? vals.get("active_character_card_id") : DEFAULT_CARD_ID;
            if (cardId == null || cardId.isEmpty()) cardId = DEFAULT_CARD_ID;
            slotAKey = "character_card_" + cardId + "_character_setting";
            slotBKey = "character_card_" + cardId + "_advanced_custom_prompt";
            cardName = vals.containsKey("character_card_" + cardId + "_name")
                    ? vals.get("character_card_" + cardId + "_name") : cardId;

            String oldA = vals.get(slotAKey);
            if (oldA == null) {
                r.error = "找不到槽位 A：" + slotAKey + "（角色卡结构可能已变，请先用「扫描」确认）";
                r.output = log.toString() + "\n" + r.error;
                return r;
            }
            log.append("[*] 角色：").append(cardName).append(" (").append(cardId).append(")\n");
            log.append("[*] 槽位A 原长 ").append(oldA.length()).append(" 字符\n");

            String base = stripInjected(oldA, pl.text);
            String merged = pl.text + "\n\n"
                    + "<!-- ===== 以下为宿主原人设，完整保留 ===== -->\n\n" + base;

            Map<String, String> repl = new LinkedHashMap<>();
            repl.put(slotAKey, merged);
            repl.put(slotBKey, pl.text);          // 第二层镜像；键不存在会被自动跳过
            out = rebuild(orig, repl);
            log.append("[*] 槽位A -> ").append(merged.length()).append(" 字符（叠加不替换）\n");
            log.append("[*] 槽位B -> ").append(pl.text.length()).append(" 字符（双层镜像）\n");
            log.append("[*] 新文件 ").append(out.length).append(" 字节\n");
        } catch (Exception e) {
            r.error = "改写失败：" + e.getMessage();
            r.output = log.toString() + "\n" + r.error;
            return r;
        }

        // 3) 落盘到 App 私有 cache，交给 su 拷进去
        File tmp;
        try {
            tmp = new File(ctx.getCacheDir(), "character_cards.new.pb");
            FileOutputStream fos = new FileOutputStream(tmp);
            fos.write(out);
            fos.close();
            log.append("[*] 中间文件 ").append(tmp.getAbsolutePath()).append("\n");
        } catch (Exception e) {
            r.error = "写中间文件失败：" + e.getMessage();
            r.output = log.toString() + "\n" + r.error;
            return r;
        }

        // 4) su 写入 + 还原属主权限 + 校验
        String uid = "0", gid = "0";
        if (!owner.isEmpty()) {
            String[] p = owner.split("\\s+");
            uid = p[0];
            gid = p[1];
        }
        String want = sha256(out);
        Result wr = exec(root(
                "cat " + q(tmp.getAbsolutePath()) + " > " + q(PB_PATH) + "\n"
              + "chown " + uid + ":" + gid + " " + q(PB_PATH) + "\n"
              + "chmod 600 " + q(PB_PATH) + "\n"
              + "ls -l " + q(PB_PATH) + "\n"
              + "sha256sum " + q(PB_PATH) + "\n"
              + "rm -f " + q(tmp.getAbsolutePath()) + "\n"
              + "am start -n " + OPERIT_PKG + "/.ui.main.MainActivity >/dev/null 2>&1\n"
              + "echo \"[OK] 已写入并重启 Operit\""));
        log.append(wr.output);
        r.output = log.toString();
        r.success = wr.output.contains(want);
        if (!r.success) {
            r.error = "写入后 sha256 校验不一致（期望 " + want.substring(0, 12)
                    + "...），请立即回滚";
            r.output += "\n" + r.error;
        }
        return r;
    }

    /** 从最近备份回滚 */
    public static Result rollback() {
        StringBuilder log = new StringBuilder();
        Result r = exec(root(
                "BK=" + q(BACKUP_DIR) + "\n"
              + "SRC=$(ls -t \"$BK\"/character_cards.*.pb 2>/dev/null | head -1)\n"
              + "if [ -z \"$SRC\" ]; then echo 'ERR 没有可用备份'; exit 3; fi\n"
              + "echo \"[*] 回滚来源 = $SRC\"\n"
              + "OWNER=$(stat -c '%u %g' " + q(PB_PATH) + " 2>/dev/null)\n"
              + "am force-stop " + OPERIT_PKG + "\n"
              + "sleep 2\n"
              + "cat \"$SRC\" > " + q(PB_PATH) + "\n"
              + "[ -n \"$OWNER\" ] && chown $OWNER " + q(PB_PATH) + "\n"
              + "chmod 600 " + q(PB_PATH) + "\n"
              + "sha256sum \"$SRC\" " + q(PB_PATH) + "\n"
              + "am start -n " + OPERIT_PKG + "/.ui.main.MainActivity >/dev/null 2>&1\n"
              + "echo \"[OK] 已回滚\""));
        log.append(r.output);
        r.output = log.toString();
        if (!r.success) r.error = "回滚脚本退出码非 0";
        return r;
    }

    /** 触发一次真实请求做端到端验证（宿主调试广播） */
    public static Result triggerSelfTest(String text) {
        String msg = (text == null || text.trim().isEmpty()) ? "是否处于破甲状态" : text.trim();
        Result r = exec(root(
                "am broadcast -a " + OPERIT_PKG + ".EXTERNAL_CHAT --es message " + q(msg) + " >/dev/null 2>&1\n"
              + "sleep 12\n"
              + "echo '--- 请求体锚点命中 ---'\n"
              + "grep -a -c 'SUPREME DIRECTIVE' " + q(LOG_PATH) + " 2>/dev/null\n"
              + "echo '--- 模型最终输出开头 ---'\n"
              + "grep -a 'Final output summary' " + q(LOG_PATH) + " 2>/dev/null | tail -1 | cut -c1-400"));
        r.output = r.output;
        r.success = r.output.contains("SUPREME DIRECTIVE");
        return r;
    }

    // ══════════════════════════════════════════════════════════
    // protobuf 最小实现（Preferences 格式）
    // ══════════════════════════════════════════════════════════

    /** 分隔标记前缀：新旧两种写法都能认 */
    private static final String SPLIT_MARK = "<!-- ===== 以下为";

    /**
     * 剥离上一次注入的载荷，保证幂等（重复注入不会累积成 N 份）。
     *
     * 三级策略：
     *   1) 有分隔标记 → 直接切标记之后（宿主原人设原封不动）
     *   2) 无标记但含本次载荷原文 → 精确移除该段（兼容更早的注入格式）
     *   3) 都认不出 → 原样返回（宁可多一份，也不切坏用户人设）
     */
    public static String stripInjected(String s, String payload) {
        if (s == null || s.isEmpty()) return "";
        int marker = s.indexOf(SPLIT_MARK);
        if (marker >= 0) {
            int end = s.indexOf("-->", marker);
            if (end > 0) {
                String rest = s.substring(end + 3);
                return rest.replaceFirst("^\\s+", "");
            }
        }
        if (payload != null && !payload.isEmpty()) {
            int p = s.indexOf(payload);
            if (p >= 0) {
                String rest = s.substring(0, p) + s.substring(p + payload.length());
                return rest.replaceFirst("^\\s+", "").replaceFirst("\\s+$", "");
            }
        }
        return s;
    }

    private static final class F {
        int num, wire, tagStart, dataStart, dataEnd;
    }

    private static long readVarint(byte[] b, int[] pos) {
        long r = 0;
        int s = 0, i = pos[0];
        while (true) {
            int x = b[i++] & 0xff;
            r += ((long) (x & 0x7f)) << s;
            s += 7;
            if ((x & 0x80) == 0) break;
            if (i - pos[0] > 10) throw new IllegalStateException("varint 过长");
        }
        pos[0] = i;
        return r;
    }

    private static byte[] varint(long v) {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        do {
            int x = (int) (v & 0x7f);
            v >>>= 7;
            if (v > 0) x |= 0x80;
            o.write(x);
        } while (v > 0);
        return o.toByteArray();
    }

    private static List<F> parseFields(byte[] b, int start, int end) {
        List<F> out = new ArrayList<>();
        int i = start;
        while (i < end) {
            F f = new F();
            f.tagStart = i;
            int[] pos = {i};
            long tag = readVarint(b, pos);
            i = pos[0];
            f.num = (int) (tag >>> 3);
            f.wire = (int) (tag & 7);
            if (f.wire == 0) {
                f.dataStart = i;
                int[] p2 = {i};
                readVarint(b, p2);
                i = p2[0];
                f.dataEnd = i;
            } else if (f.wire == 2) {
                int[] p2 = {i};
                long len = readVarint(b, p2);
                f.dataStart = p2[0];
                i = (int) (p2[0] + len);
                f.dataEnd = i;
            } else if (f.wire == 5) {
                f.dataStart = i; i += 4; f.dataEnd = i;
            } else if (f.wire == 1) {
                f.dataStart = i; i += 8; f.dataEnd = i;
            } else {
                throw new IllegalStateException("非法 wire " + f.wire + " @" + f.tagStart);
            }
            out.add(f);
        }
        return out;
    }

    private static byte[] slice(byte[] b, int s, int e) {
        return Arrays.copyOfRange(b, s, e);
    }

    private static byte[] concat(List<byte[]> parts) {
        int n = 0;
        for (byte[] p : parts) n += p.length;
        byte[] out = new byte[n];
        int i = 0;
        for (byte[] p : parts) {
            System.arraycopy(p, 0, out, i, p.length);
            i += p.length;
        }
        return out;
    }

    private static byte[] lenField(int num, byte[] payload) {
        return concat(Arrays.asList(varint(((long) num << 3) | 2), varint(payload.length), payload));
    }

    /** 取 map 里所有 string 类型的值：key -> utf8 字符串 */
    public static Map<String, String> stringValues(byte[] pb) {
        Map<String, String> out = new LinkedHashMap<>();
        for (F rec : parseFields(pb, 0, pb.length)) {
            if (rec.num != 1 || rec.wire != 2) continue;
            List<F> inner = parseFields(pb, rec.dataStart, rec.dataEnd);
            String key = null;
            List<F> valueMsg = null;
            for (F f : inner) {
                if (f.num == 1) key = new String(slice(pb, f.dataStart, f.dataEnd), StandardCharsets.UTF_8);
                if (f.num == 2) valueMsg = parseFields(pb, f.dataStart, f.dataEnd);
            }
            if (key == null || valueMsg == null) continue;
            for (F v : valueMsg) {
                if (v.num == 5) {
                    out.put(key, new String(slice(pb, v.dataStart, v.dataEnd), StandardCharsets.UTF_8));
                    break;
                }
            }
        }
        return out;
    }

    /**
     * 重建整个文件。repl = null 时是纯无损往返（用于自检）。
     * 只处理 string 值；其他类型原样搬字节。
     */
    public static byte[] rebuild(byte[] orig, Map<String, String> repl) {
        List<byte[]> entries = new ArrayList<>();
        for (F rec : parseFields(orig, 0, orig.length)) {
            if (rec.num != 1 || rec.wire != 2) {
                entries.add(slice(orig, rec.tagStart, rec.dataEnd));
                continue;
            }
            List<F> inner = parseFields(orig, rec.dataStart, rec.dataEnd);
            String key = null;
            for (F f : inner) {
                if (f.num == 1) key = new String(slice(orig, f.dataStart, f.dataEnd), StandardCharsets.UTF_8);
            }
            boolean replace = repl != null && key != null && repl.containsKey(key);
            List<byte[]> innerParts = new ArrayList<>();
            for (F f : inner) {
                if (f.num == 2 && replace) {
                    byte[] strVal = lenField(5, repl.get(key).getBytes(StandardCharsets.UTF_8));
                    innerParts.add(lenField(2, strVal));
                } else {
                    innerParts.add(slice(orig, f.tagStart, f.dataEnd));
                }
            }
            entries.add(lenField(1, concat(innerParts)));
        }
        return concat(entries);
    }

    // ══════════════════════════════════════════════════════════
    // 内部工具
    // ══════════════════════════════════════════════════════════

    /** 单引号包裹，防 shell 元字符 */
    private static String q(String s) {
        return "'" + s.replace("'", "'\\''") + "'";
    }

    private static String joinLines(String s) {
        StringBuilder b = new StringBuilder();
        for (String line : s.split("\n")) {
            String t = line.trim();
            if (t.matches("[A-Za-z0-9+/=]+")) b.append(t);
        }
        return b.toString();
    }

    private static byte[] base64Decode(String s) {
        if (s == null || s.isEmpty()) return null;
        try {
            return android.util.Base64.decode(s, android.util.Base64.DEFAULT);
        } catch (Exception e) {
            return null;
        }
    }

    public static String sha256(byte[] data) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] d = md.digest(data);
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            return "";
        }
    }

    /** 统一脚本入口：su 的 PATH 有时极简，这里兜底系统二进制目录 */
    private static String root(String script) {
        return "export PATH=/system/bin:/system/xbin:$PATH\n" + script;
    }

    private static Result exec(String script) {
        Result r = new Result();
        StringBuilder log = new StringBuilder();
        try {
            Process p = startSuWithStdin(script);
            if (p == null) {
                r.error = "无法调用 su（未授权 root 或 su 不可用）";
                r.output = r.error;
                return r;
            }
            BufferedReader out = new BufferedReader(new InputStreamReader(p.getInputStream(), "UTF-8"));
            StringBuilder elog = new StringBuilder();
            String line;
            while ((line = out.readLine()) != null) log.append(line).append("\n");
            BufferedReader err = new BufferedReader(new InputStreamReader(p.getErrorStream(), "UTF-8"));
            while ((line = err.readLine()) != null) elog.append(line).append("\n");
            int code = p.waitFor();
            if (elog.length() > 0) log.append("[stderr] ").append(elog);
            r.output = log.toString();
            r.success = (code == 0);
            if (code != 0) r.error = "退出码 " + code;
        } catch (Exception e) {
            r.success = false;
            r.error = e.getClass().getSimpleName() + ": " + e.getMessage();
            r.output = log.toString() + "\n[异常] " + r.error;
        }
        return r;
    }

    /**
     * 启动 su 并把脚本写进 stdin。
     * su -M 必须排第一：App 私有挂载命名空间里 /data/data 可能是 tmpfs 影子。
     */
    private static Process startSuWithStdin(String script) {
        String[][] variants = {
                {"su", "-M"},
                {"su", "--mount-master"},
                {"su"},
                {"/system/bin/su", "-M"},
                {"/system/bin/su"},
        };
        for (String[] v : variants) {
            Process p = null;
            try {
                p = new ProcessBuilder(v).redirectErrorStream(false).start();
                OutputStream os = p.getOutputStream();
                OutputStreamWriter w = new OutputStreamWriter(os, "UTF-8");
                w.write(script);
                w.write("\nexit\n");
                w.flush();
                w.close();
                return p;
            } catch (Exception e) {
                if (p != null) { try { p.destroy(); } catch (Exception ignored) { } }
            }
        }
        return null;
    }

    private static String runSuSimple(String command) {
        String[][] variants = {
                {"su", "-M", "-c", command},
                {"su", "-c", command},
                {"/system/bin/su", "-M", "-c", command},
                {"/system/bin/su", "-c", command},
        };
        for (String[] v : variants) {
            try {
                Process p = new ProcessBuilder(v).redirectErrorStream(true).start();
                BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream(), "UTF-8"));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) sb.append(line).append("\n");
                p.waitFor();
                if (sb.length() > 0) return sb.toString();
            } catch (Exception ignored) { }
        }
        return null;
    }
}
