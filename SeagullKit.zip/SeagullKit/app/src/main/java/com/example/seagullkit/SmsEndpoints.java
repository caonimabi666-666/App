package com.example.seagullkit;

import android.content.Context;
import android.util.Base64;
import android.util.Log;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;

/**
 * 工具：短信测压 —— 接口表（脱壳产物）。
 *
 * <p>数据来源：把一个被多层壳（反转 base64 → b85+gzip → SHA256-CTR 异或 + gzip）
 * 包裹的 Python 样本逐层脱壳，再把其中 330 个"发验证码"函数编译成一张表（后又补入滴滴出行 1 条，共 331），
 * 落到 {@code assets/sms_endpoints.tsv}。
 *
 * <p>2026-09-22 清洗：剔除 14 条"跑不出短信"的条目，现 <b>317</b> 条。判据见 README「接口表清洗」：
 * <ul>
 *   <li>7 条完全重复（同方法+URL+头部+形态+载荷，重复录入）</li>
 *   <li>6 条载荷残缺/脱壳损坏：手机号字段被逐字符拆成表单序号（如 {@code 0=%7B&1=P&2=H…}）、
 *       手机号被解析成 {@code {UNKNOWN}}、body 为空 {@code {}}</li>
 *   <li>1 条非 ASCII 域名改写成 punycode（{@code ziyue.中国} → {@code ziyue.xn--fiqs8s}）</li>
 * </ul>
 *
 * <p>TSV 每行 6 列（TAB 分隔）：
 * <pre>
 *   序号  方法  URL  头部(0x1f 分隔)  形态  载荷
 * </pre>
 * 形态取值 {@code json} / {@code form} / {@code query} / {@code none}。
 *
 * <p>原样本里靠 Python 运行时算出来的动态值，在这里用占位符表示，
 * 由 {@link #expand} 在发送前展开：
 * <pre>
 *   {PHONE}        目标号码
 *   {PHONE_B64}    号码的 base64（原 base64.b64encode(phone.encode())）
 *   {UA}           4 个 User-Agent 里随机取一个（原 random.choice）
 *   {TS_MS}        毫秒时间戳（原 str(int(time.time()*1000))）
 *   {TS_S}         秒时间戳
 *   {UUID}         32 位大写 hex（原 uuid.uuid4().hex.upper()）
 *   {RANDHEX:n}    n 位小写 hex（原 ''.join(random.choices("abcdef0123456789", k=n))）
 *   {RANDHEXU:n}   n 位大写 hex
 *   {RANDHEXD:n}   n 位 hex + '-'（用于 deviceId）
 *   {RAND:n}       n 位字母数字
 *   {UNKNOWN}      无法静态还原的签名类动态值，展开为空串（仅 2 条）
 * </pre>
 */
public final class SmsEndpoints {

    private static final String TAG = "SeagullSms";

    /** 资源文件名 */
    public static final String ASSET = "sms_endpoints.tsv";

    /** 头部字段分隔符（0x1f），避免与头值里的逗号/分号冲突 */
    public static final char HEADER_SEP = '\u001f';

    /** 原样本里的 4 个 User-Agent */
    public static final String[] UAS = {
            "Mozilla/5.0 (Linux; Android 16; PKW110 Build/BP2A.250605.015; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/138.0.7204.179 Mobile Safari/537.36 uni-app Html5Plus/1.0",
            "Mozilla/5.0 (Linux; Android 15; OPD2404 Build/UKQ1.231108.001) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.6723.58 Mobile Safari/537.36",
            "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    };

    /** 一条接口记录 */
    public static class Rec {
        public final int idx;
        public final String method;
        public final String url;
        public final String headers;
        public final String kind;
        public final String body;

        Rec(int idx, String method, String url, String headers, String kind, String body) {
            this.idx = idx;
            this.method = method;
            this.url = url;
            this.headers = headers;
            this.kind = kind;
            this.body = body;
        }

        /** 头部按 0x1f 拆成 "Name: Value" 数组 */
        public String[] headerLines() {
            if (headers == null || headers.isEmpty()) return new String[0];
            return headers.split(String.valueOf(HEADER_SEP));
        }

        /** 域名，用于日志展示 */
        public String host() {
            try {
                String u = url;
                int s = u.indexOf("://");
                if (s >= 0) u = u.substring(s + 3);
                int e = u.indexOf('/');
                if (e >= 0) u = u.substring(0, e);
                return u;
            } catch (Exception ex) {
                return url;
            }
        }
    }

    private static List<Rec> cache;

    private SmsEndpoints() {
    }

    // ──────────────────────────────────────────────────────────
    // 固定首发接口（每次测压开始先单独打一发）
    // ──────────────────────────────────────────────────────────

    /** 首发接口的 URL 特征 —— 滴滴出行 codeMT */
    private static final String PINNED_URL_KEY =
            "epassport.diditaxi.com.cn/passport/login/v5/codeMT";

    /**
     * 取首发接口记录。
     *
     * <p>直接从接口表里按 URL 找，保证与表中数据同源（改表即改行为），
     * 找不到就返回 null，调用方跳过首发即可。
     */
    public static Rec pinned(Context ctx) {
        try {
            for (Rec r : load(ctx)) {
                if (r.url != null && r.url.contains(PINNED_URL_KEY)) return r;
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    /** 读取并缓存接口表 */
    public static synchronized List<Rec> load(Context ctx) {
        if (cache != null) return cache;
        List<Rec> list = new ArrayList<>();
        InputStream in = null;
        BufferedReader br = null;
        try {
            in = ctx.getAssets().open(ASSET);
            br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
            String line;
            while ((line = br.readLine()) != null) {
                if (line.isEmpty()) continue;
                String[] c = line.split("\t", 6);
                if (c.length < 6) continue;
                int idx;
                try {
                    idx = Integer.parseInt(c[0].trim());
                } catch (Exception e) {
                    idx = list.size() + 1;
                }
                list.add(new Rec(idx, c[1], c[2], c[3], c[4], c[5]));
            }
        } catch (Exception e) {
            Log.e(TAG, "读取接口表失败", e);
        } finally {
            try {
                if (br != null) br.close();
                if (in != null) in.close();
            } catch (Exception ignored) {
            }
        }
        cache = list;
        Log.d(TAG, "接口表加载完成: " + list.size() + " 条");
        return list;
    }

    /** 接口总数（首页/标题展示用） */
    public static synchronized int count(Context ctx) {
        return load(ctx).size();
    }

    // ── 占位符展开 ────────────────────────────────────────────
    //
    // 注意：这里刻意不使用 java.util.regex —— Android 的 ICU 正则比 JS 严格，
    // "{RAND(HEXU|HEXD|HEX)?:(\\d+)}" 这种写法会因为末尾未转义的 '}' 直接抛
    // PatternSyntaxException（类初始化失败 → 点开页面即闪退）。
    // 改成手写扫描，零正则依赖。

    private static final char[] CS_HEX = "0123456789abcdef".toCharArray();
    private static final char[] CS_HEXU = "0123456789ABCDEF".toCharArray();
    private static final char[] CS_HEXD = "0123456789abcdef-".toCharArray();
    private static final char[] CS_ALNUM =
            "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".toCharArray();

    /** 展开一个字符串里的全部占位符 */
    public static String expand(String s, String phone, Random rnd) {
        if (s == null || s.isEmpty() || s.indexOf('{') < 0) return s;
        long now = System.currentTimeMillis();
        String phoneB64 = Base64.encodeToString(
                phone.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);

        String out = s
                .replace("{PHONE}", phone)
                .replace("{PHONE_B64}", phoneB64)
                .replace("{UA}", UAS[rnd.nextInt(UAS.length)])
                .replace("{TS_MS}", String.valueOf(now))
                .replace("{TS_S}", String.valueOf(now / 1000L))
                .replace("{UUID}", uuidHex(rnd))
                .replace("{UNKNOWN}", "");
        out = replaceRandom(out, rnd);
        // 兜底：把静态分析阶段没能还原的动态值 {?xxx} 清掉
        // （JSON 体里的 {"k":...} 不含 '?'，不会被误伤）
        out = stripUnknown(out);
        return out;
    }

    /** 扫描替换 {RAND:n} / {RANDHEX:n} / {RANDHEXU:n} / {RANDHEXD:n} */
    private static String replaceRandom(String s, Random rnd) {
        if (s.indexOf("{RAND") < 0) return s;
        StringBuilder out = new StringBuilder(s.length() + 32);
        int i = 0;
        while (true) {
            int p = s.indexOf("{RAND", i);
            if (p < 0) {
                out.append(s, i, s.length());
                break;
            }
            int close = s.indexOf('}', p);
            if (close < 0) {
                out.append(s, i, s.length());
                break;
            }
            out.append(s, i, p);
            String token = s.substring(p, close + 1);
            String rep = expandRandToken(token, rnd);
            out.append(rep != null ? rep : token);
            i = close + 1;
        }
        return out.toString();
    }

    /** 解析单个 {RAND...:n}；不认识就返回 null（原样保留） */
    private static String expandRandToken(String token, Random rnd) {
        int colon = token.indexOf(':');
        if (colon < 0) return null;
        String tag = token.substring(5, colon);                       // "RAND" 之后的部分
        String num = token.substring(colon + 1, token.length() - 1);
        int n;
        try {
            n = Integer.parseInt(num.trim());
        } catch (Exception e) {
            return null;
        }
        if (n <= 0 || n > 256) n = 6;
        char[] cs;
        if ("HEXU".equals(tag)) cs = CS_HEXU;
        else if ("HEXD".equals(tag)) cs = CS_HEXD;
        else if ("HEX".equals(tag)) cs = CS_HEX;
        else if (tag.isEmpty()) cs = CS_ALNUM;
        else return null;
        StringBuilder b = new StringBuilder(n);
        for (int i = 0; i < n; i++) b.append(cs[rnd.nextInt(cs.length)]);
        return b.toString();
    }

    /** 去掉残留的 {?...}（静态分析没还原出来的动态值） */
    private static String stripUnknown(String s) {
        if (s.indexOf("{?") < 0) return s;
        StringBuilder out = new StringBuilder(s.length());
        int i = 0;
        while (true) {
            int p = s.indexOf("{?", i);
            if (p < 0) {
                out.append(s, i, s.length());
                break;
            }
            int close = s.indexOf('}', p);
            if (close < 0) {
                out.append(s, i, s.length());
                break;
            }
            out.append(s, i, p);
            i = close + 1;
        }
        return out.toString();
    }

    /** 32 位大写 hex，等价原 uuid.uuid4().hex.upper() */
    public static String uuidHex(Random rnd) {
        StringBuilder b = new StringBuilder(32);
        for (int i = 0; i < 32; i++) b.append(CS_HEXU[rnd.nextInt(16)]);
        return b.toString();
    }

    /** 号码格式校验：11 位纯数字 */
    public static boolean isValidPhone(String phone) {
        if (phone == null) return false;
        String p = phone.trim();
        if (p.length() != 11) return false;
        for (int i = 0; i < p.length(); i++) {
            if (p.charAt(i) < '0' || p.charAt(i) > '9') return false;
        }
        return true;
    }

    /**
     * 把一段自由文本解析成号码列表。
     *
     * <p>只认「回车/换行」作分隔符——一行一个号码。
     * 行内若有空白会被去掉（防止粘贴时带空格），空行丢弃，重复号码自动去重（保持首次出现顺序）。
     * <b>不</b>在此处做合法性校验——校验交给调用方（{@link #isValidPhone}），
     * 这样界面才能把"哪个号码不合法"精确回显给用户。
     */
    public static List<String> parsePhones(String raw) {
        List<String> out = new ArrayList<>();
        if (raw == null || raw.isEmpty()) return out;
        // 只按换行切分；兼容 \r\n。行内空白去掉，避免粘贴时带空格/制表符
        String norm = raw.replace('\r', '\n');
        java.util.LinkedHashSet<String> set = new java.util.LinkedHashSet<>();
        for (String line : norm.split("\n")) {
            String p = line.trim();
            if (!p.isEmpty()) set.add(p);
        }
        out.addAll(set);
        return out;
    }

    /** 便于日志里显示域名统计 */
    public static String describe(Rec r) {
        return String.format(Locale.US, "#%d %s %s", r.idx, r.method, r.host());
    }
}