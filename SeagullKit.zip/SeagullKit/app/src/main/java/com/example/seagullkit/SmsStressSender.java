package com.example.seagullkit;

import android.util.Log;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Random;

/**
 * 工具：短信测压 —— 单次请求发送器。
 *
 * <p>对应脱壳产物里 {@code requests.get(...)} / {@code requests.post(...)} 那一步：
 * <ul>
 *   <li>{@code json=}  → POST + {@code application/json}</li>
 *   <li>{@code data=}  → POST + {@code application/x-www-form-urlencoded}</li>
 *   <li>{@code params=} → GET，查询串拼到 URL 后面</li>
 * </ul>
 * 头部、URL、请求体里的占位符统一由 {@link SmsEndpoints#expand} 展开。
 *
 * <p><b>性能取舍（相对原版 curl/Python 的实现）</b>：
 * <ol>
 *   <li>超时从 8s 收到 3s/4s —— 死接口不再拖住整轮</li>
 *   <li>不读响应体 —— 拿到状态码就 disconnect，省掉 body 传输（本工具"发出去就完事"）</li>
 *   <li>不跟随 302 —— 少一次往返，302 也照样算这条跑通了</li>
 * </ol>
 * 真正的大头是并发，由 {@link SmsStressService} 的线程池负责。
 */
public final class SmsStressSender {

    private static final String TAG = "SeagullSms";

    /** 建连超时：多数接口 1s 内就建好了，3s 足够，且死接口不会拖太久 */
    public static final int CONNECT_TIMEOUT_MS = 3000;
    /** 读取超时：只要响应头（状态码），不需要等 body */
    public static final int READ_TIMEOUT_MS = 4000;

    /** 单次请求结果 */
    public static class Result {
        public boolean ok;
        public int code = -1;
        public String error = "";
        public long ms;
        /** 实际发出的完整 URL（含查询串），日志用 */
        public String finalUrl = "";

        public String shortDesc() {
            if (ok) return "HTTP " + code + " · " + ms + "ms";
            return "失败：" + error;
        }
    }

    private SmsStressSender() {
    }

    /**
     * 发送一条。
     *
     * @param rec       接口记录
     * @param phone     目标号码
     * @param rnd       随机源
     * @param dryRun    true 只构造请求不真发
     */
    public static Result send(SmsEndpoints.Rec rec, String phone, Random rnd, boolean dryRun) {
        Result res = new Result();
        long t0 = System.currentTimeMillis();
        HttpURLConnection conn = null;
        try {
            String url = SmsEndpoints.expand(rec.url, phone, rnd);
            String body = SmsEndpoints.expand(rec.body, phone, rnd);
            String kind = rec.kind == null ? "none" : rec.kind;

            // params= 形态：查询串拼 URL
            if ("query".equals(kind) && body != null && !body.isEmpty()) {
                url = url + (url.indexOf('?') >= 0 ? "&" : "?") + body;
            }
            res.finalUrl = url;

            if (dryRun) {
                res.ok = true;
                res.code = 0;
                res.ms = 0;
                return res;
            }

            URL u = new URL(url);
            conn = (HttpURLConnection) u.openConnection();
            conn.setRequestMethod(rec.method == null ? "GET" : rec.method.toUpperCase());
            conn.setConnectTimeout(CONNECT_TIMEOUT_MS);
            conn.setReadTimeout(READ_TIMEOUT_MS);
            conn.setInstanceFollowRedirects(false);   // 省一次往返
            conn.setDoInput(true);
            conn.setUseCaches(false);

            // Host / Connection / Content-Length 在 HttpURLConnection 里是受限头，
            // setRequestProperty 会被忽略，这里照样尝试，不额外报错。
            boolean hasContentType = false;
            for (String h : rec.headerLines()) {
                if (h == null) continue;
                String line = h.trim();
                if (line.isEmpty()) continue;
                int p = line.indexOf(':');
                if (p <= 0) continue;
                String name = line.substring(0, p).trim();
                String value = SmsEndpoints.expand(line.substring(p + 1).trim(), phone, rnd);
                if (name.equalsIgnoreCase("content-length")) continue;
                if (name.equalsIgnoreCase("content-type")) hasContentType = true;
                try {
                    conn.setRequestProperty(name, value);
                } catch (Exception ignored) {
                }
            }

            if ("json".equals(kind) || "form".equals(kind)) {
                if (!hasContentType) {
                    conn.setRequestProperty("Content-Type",
                            "json".equals(kind)
                                    ? "application/json"
                                    : "application/x-www-form-urlencoded");
                }
                conn.setDoOutput(true);
                byte[] payload = (body == null ? "" : body).getBytes(StandardCharsets.UTF_8);
                conn.setFixedLengthStreamingMode(payload.length);
                OutputStream os = conn.getOutputStream();
                os.write(payload);
                os.flush();
                os.close();
            }

            // 只要状态码，不读 body
            res.code = conn.getResponseCode();
            res.ok = true;   // 与 curl 一致：拿到响应就算这条跑通了
        } catch (Exception e) {
            res.ok = false;
            res.error = e.getClass().getSimpleName()
                    + (e.getMessage() == null ? "" : (": " + e.getMessage()));
            Log.d(TAG, "send fail: " + rec.idx + " " + res.error);
        } finally {
            if (conn != null) {
                try {
                    conn.disconnect();
                } catch (Exception ignored) {
                }
            }
            res.ms = System.currentTimeMillis() - t0;
        }
        return res;
    }
}
