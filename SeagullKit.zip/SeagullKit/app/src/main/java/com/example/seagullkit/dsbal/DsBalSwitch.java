package com.example.seagullkit.dsbal;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

/** 自绘开关：开启时轨道走紫渐变并带辉光，滑块减速滑入。 */
public class DsBalSwitch extends View {

    private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint knob = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();

    private boolean on;
    private float progress;
    private ValueAnimator anim;

    private int colorOff = DsBalUi.SURFACE_ALT;
    private int colorOnStart = DsBalUi.VIOLET_DEEP;
    private int colorOnEnd = DsBalUi.VIOLET;
    private int colorKnobOff = 0xFF9C7E8C;
    private int colorKnobOn = 0xFFFFF0F5;

    public DsBalSwitch(Context c) { this(c, null); }

    public DsBalSwitch(Context c, AttributeSet a) {
        super(c, a);
        setClickable(false);
        setFocusable(false);
        setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
        setLayerType(LAYER_TYPE_SOFTWARE, null);
    }

    public void setColors(int off, int onStart, int onEnd, int knobOff, int knobOn) {
        this.colorOff = off;
        this.colorOnStart = onStart;
        this.colorOnEnd = onEnd;
        this.colorKnobOff = knobOff;
        this.colorKnobOn = knobOn;
        invalidate();
    }

    public boolean isOn() { return on; }

    public void setOn(boolean value, boolean animate) {
        if (on == value && !animate) {
            progress = value ? 1f : 0f;
            invalidate();
            return;
        }
        on = value;
        float target = value ? 1f : 0f;
        if (!animate) {
            progress = target;
            invalidate();
            return;
        }
        if (anim != null) anim.cancel();
        anim = ValueAnimator.ofFloat(progress, target);
        anim.setDuration(220);
        anim.setInterpolator(new DecelerateInterpolator(1.6f));
        anim.addUpdateListener(a -> {
            progress = (float) a.getAnimatedValue();
            invalidate();
        });
        anim.start();
    }

    @Override
    protected void onMeasure(int wSpec, int hSpec) {
        Context c = getContext();
        setMeasuredDimension(
                resolveSize(DsBalUi.dp(c, 52), wSpec),
                resolveSize(DsBalUi.dp(c, 30), hSpec));
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float w = getWidth(), h = getHeight();
        float r = h / 2f;
        rect.set(0, 0, w, h);

        // 开启态的辉光
        if (progress > 0.02f) {
            glow.setColor(0x66F48FB1);
            glow.setAlpha((int) (0x66 * progress));
            glow.setMaskFilter(new BlurMaskFilter(DsBalUi.dp(getContext(), 5),
                    BlurMaskFilter.Blur.NORMAL));
            canvas.drawRoundRect(rect, r, r, glow);
        }

        // 轨道：关=暗面，开=紫渐变（用 progress 混合）
        track.setShader(new LinearGradient(0, 0, w, h,
                new int[]{blend(colorOff, colorOnStart, progress),
                          blend(colorOff, colorOnEnd, progress)},
                null, Shader.TileMode.CLAMP));
        canvas.drawRoundRect(rect, r, r, track);

        // 滑块
        float pad = DsBalUi.dp(getContext(), 3f);
        float d = h - pad * 2;
        float travel = w - d - pad * 2;
        float left = pad + travel * progress;

        knob.setColor(blend(colorKnobOff, colorKnobOn, progress));
        knob.setShadowLayer(DsBalUi.dp(getContext(), 2f), 0, DsBalUi.dp(getContext(), 1f), 0x55000000);
        canvas.drawCircle(left + d / 2f, h / 2f, d / 2f, knob);
    }

    private static int blend(int a, int b, float t) {
        int ar = (a >> 16) & 0xFF, ag = (a >> 8) & 0xFF, ab = a & 0xFF;
        int br = (b >> 16) & 0xFF, bg = (b >> 8) & 0xFF, bb = b & 0xFF;
        int rr = Math.round(ar + (br - ar) * t);
        int rg = Math.round(ag + (bg - ag) * t);
        int rb = Math.round(ab + (bb - ab) * t);
        return 0xFF000000 | (rr << 16) | (rg << 8) | rb;
    }
}
