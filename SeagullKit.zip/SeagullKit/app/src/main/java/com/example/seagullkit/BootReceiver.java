package com.example.seagullkit;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

/** 开机自启：若用户上次开着 DeepSeek 余额悬浮窗，则重新拉起。 */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || !Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) return;

        Context app = context.getApplicationContext();
        if (app.getSharedPreferences("dsbal", Context.MODE_PRIVATE)
                .getBoolean("want_running", false)) {
            Intent svc = new Intent(app, com.example.seagullkit.dsbal.DsBalService.class);
            svc.setAction(com.example.seagullkit.dsbal.DsBalService.ACTION_REFRESH);
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    app.startForegroundService(svc);
                } else {
                    app.startService(svc);
                }
            } catch (Exception ignored) {
            }
        }
    }
}
