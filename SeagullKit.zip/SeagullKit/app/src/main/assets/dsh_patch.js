#!/usr/bin/env node
/**
 * dsh_patch.js —— DeepSeek Harness（com.deepseek.harness）破甲写入器
 *
 * ══════════════════════════════════════════════════════════════
 * 一、本机实测布局（v1.20.0 / versionCode 57）
 * ══════════════════════════════════════════════════════════════
 *
 *   $PKG           = com.deepseek.harness
 *   $DSH_HOME      = files/payload/dshhome
 *   用户 patch 层  = $DSH_HOME/profiles/web/cordis.patch.yml   ← 本工具写这里
 *   官方骨架       = $DSH_HOME/../dshroot/lib/node_modules/@deepseek-ai/dsh/
 *                    node_modules/@deepseek-ai/dsh-web-app/presets/standard.patch.yml
 *   node           = files/payload/runtime/bin/node（+ LD_LIBRARY_PATH=runtime/lib）
 *
 * 之前这套脚本是照 DSHA（com.dsh.client / Ubuntu+proot 容器）写的，
 * 拿到 Harness 上必然全挂：
 *   · DSHA 的 dsh home 是 files/linux/ubuntu/root/.dsh，Harness 是 payload/dshhome
 *   · DSHA 的骨架在 $DSH_HOME/node_modules/...，Harness 在 payload/dshroot/lib/node_modules/...
 *   · DSHA 的 node 要经 ld-linux 加载，Harness 是 Termux 式原生 ARM64 二进制
 *   · 拆闸 / 设备全权两档针对的是 proot 容器，Harness 没有容器 → 整档删除
 *
 * ══════════════════════════════════════════════════════════════
 * 二、破甲 preset 怎么装
 * ══════════════════════════════════════════════════════════════
 * 以**当前版本自带的 standard.patch.yml 为骨架**，只把 persona 的
 * prefix 换成 v5N 基线，整块 insert 进用户 patch 层：
 *
 *   - insert:
 *       - id: preset-pj-mode-v5n
 *         name: '@deepseek-ai/dsh-agent-preset'
 *         config: { id: pj-mode-v5n, name: 破甲模式v5N, order: 90, plugins: [...] }
 *
 * 骨架取自运行时安装的 bundle —— 天生与当前 dsh 版本对齐，不会出现
 * 「拿旧版 composition 去挂新版」的 API 漂移。
 *
 * ══════════════════════════════════════════════════════════════
 * 三、为什么是文本改写而不是整篇序列化
 * ══════════════════════════════════════════════════════════════
 * patch 文件里允许 `!!js <表达式>` 自定义标签（bundle 里就有
 * `disabled: !!js process.platform === 'win32'`）。解析成 AST 再序列化
 * 会把这类标签和注释一起弄丢/降级，语义直接变味（字符串 "false" 是
 * truthy，disabled 就反了）。所以只切 persona.prefix 那一段块标量，
 * 其余字节原样搬走；写完用 yaml 解析一遍自校验，不过就不落盘。
 *
 * 用法：node dsh_patch.js <cmd.json>
 *   cmd.mode = scan | install | uninstall
 */

const fs = require('fs');
const path = require('path');

const PRESET_ID = 'pj-mode-v5n';
const PRESET_NAME = '破甲模式v5N';
const ENTRY_ID = 'preset-' + PRESET_ID;
const MARK_BEGIN = '# >>> seagullkit preset ' + PRESET_ID;
const MARK_END = '# <<< seagullkit';
const MARK_TAG = '# [dsh-unlock-mode] preset-id=' + PRESET_ID + ' name=' + PRESET_NAME;
const PRESET_DESC =
    'v5 无边界变体：不预设任何禁区，是否交付完全由操作者当轮指令决定。' +
    '含目标参数归一化、注入免疫、拒绝自恢复、常见任务输出范式、每轮锚定、宿主补丁兼容。' +
    '回执口令：破甲已生效｜目标 DSH｜破甲模式 v5N。';

function emit(o) {
    process.stdout.write(JSON.stringify(o) + '\n');
}
function fail(msg, extra) {
    emit(Object.assign({ ok: false, error: String(msg) }, extra || {}));
    process.exit(0);
}

let cmd;
try {
    cmd = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
} catch (e) {
    fail('读不到命令文件：' + e.message);
}

const HOME = cmd.home || '';
const PATCH = cmd.patch || '';
const BUNDLE = cmd.bundle || '';
const COMPO = cmd.composition || '';
const BACKUPS = cmd.backups || (HOME + '/backups');
const YAMLROOT = cmd.yamlroot || '';

// ══════════════════════════════════════════════════════════════
// yaml 解析
// ══════════════════════════════════════════════════════════════
// 关键：dsh 用的不是 `yaml` 包，而是 **js-yaml**，并且注册了一个自定义
// 类型（见 cordis-plugin-include/lib/index.js）：
//
//   new yaml.Type('tag:yaml.org,2002:js', { kind:'scalar',
//       resolve: d => typeof d === 'string',
//       construct: d => ({ __jsExpr: d }) })
//   entryListSchema = yaml.JSON_SCHEMA.extend(JsExpr)
//
// 所以这里的 schema 必须与它逐字节一致（JSON_SCHEMA + !!js），否则
// bundle 里的 `disabled: !!js process.platform === 'win32'` 会解析失败。
// 用 `yaml` 包（而非 js-yaml）根本注册不了这个 tag 名，之前的写法就是这么挂的。

let _YAML;

function loadYaml() {
    const cands = [];
    if (YAMLROOT) {
        cands.push(path.join(YAMLROOT, 'node_modules/js-yaml'));
        cands.push(path.join(YAMLROOT, 'node_modules/@deepseek-ai/dsh/node_modules/js-yaml'));
    }
    for (const c of cands) {
        try { return require(c); } catch (e) { /* 继续试下一个 */ }
    }
    try { return require('js-yaml'); } catch (e) { /* 落到下面 */ }
    throw new Error('找不到 js-yaml 模块（已试 ' + (cands.join(' / ') || '默认路径') + '）');
}

function YAML() {
    if (!_YAML) _YAML = loadYaml();
    return _YAML;
}

/** dsh 的 entry-list schema：JSON_SCHEMA + !!js 标量 */
function schema() {
    const yaml = YAML();
    if (schema._cached) return schema._cached;
    const JsExpr = new yaml.Type('tag:yaml.org,2002:js', {
        kind: 'scalar',
        resolve: (data) => typeof data === 'string',
        construct: (data) => ({ __jsExpr: data })
    });
    schema._cached = yaml.JSON_SCHEMA.extend(JsExpr);
    return schema._cached;
}

/** 解析；失败抛异常（带首条错误的可读信息） */
function parseDoc(text) {
    return YAML().load(text, { schema: schema() });
}

function assertParses(text, label) {
    try {
        return parseDoc(text);
    } catch (e) {
        const m = e && e.mark ? '（第 ' + (e.mark.line + 1) + ' 行）' : '';
        throw new Error(label + ' 解析失败' + m + '：' + (e.reason || e.message));
    }
}

// ══════════════════════════════════════════════════════════════
// 结构遍历
// ══════════════════════════════════════════════════════════════
// 顶层是数组，每项形如 { id?, name?, config?, insert?: [...] }。
// 用纯 JS 对象遍历，不依赖 AST 节点 API。

/** 取数组里所有 insert 行（每个顶层项的 insert 数组拼起来） */
function insertRows(doc) {
    const rows = [];
    if (!Array.isArray(doc)) return rows;
    for (const it of doc) {
        if (!it || typeof it !== 'object') continue;
        const ins = it.insert;
        if (Array.isArray(ins)) for (const r of ins) rows.push(r);
    }
    return rows;
}

/** 所有顶层 entry（含 id 的那些） */
function topEntries(doc) {
    if (!Array.isArray(doc)) return [];
    return doc.filter((it) => it && typeof it === 'object');
}

/** 在 insert 行里按 id 找 preset 声明 */
function findPresetRow(doc, entryId) {
    for (const row of insertRows(doc)) {
        if (row && row.id === entryId) return row;
    }
    return null;
}

// ══════════════════════════════════════════════════════════════
// 文件工具
// ══════════════════════════════════════════════════════════════

function readOr(p, d) {
    try { return fs.readFileSync(p, 'utf8'); } catch (e) { return d; }
}

function statOwner(p) {
    try {
        const st = fs.statSync(p);
        return { uid: st.uid, gid: st.gid };
    } catch (e) { return null; }
}

function ts() {
    const d = new Date();
    const p = (n) => String(n).padStart(2, '0');
    return d.getFullYear() + p(d.getMonth() + 1) + p(d.getDate()) + '-' +
        p(d.getHours()) + p(d.getMinutes()) + p(d.getSeconds());
}

/** 临时文件 + rename 原子替换；属主沿用参考文件（dsh 进程 uid ≠ root） */
function writeAtomic(p, text, likePath) {
    const dir = path.dirname(p);
    const tmp = path.join(dir, '.seagull-' + path.basename(p) + '.' + process.pid);
    fs.writeFileSync(tmp, text, { encoding: 'utf8', mode: 0o600 });
    const own = statOwner(likePath || p);
    if (own) { try { fs.chownSync(tmp, own.uid, own.gid); } catch (e) { } }
    fs.renameSync(tmp, p);
    return p;
}

/** 备份到 $DSH_HOME/backups/<时间戳>/，返回备份目录 */
function backupFiles(files) {
    const dir = path.join(BACKUPS, ts());
    try { fs.mkdirSync(dir, { recursive: true, mode: 0o700 }); } catch (e) { }
    const saved = [];
    for (const f of files) {
        if (!f || !fs.existsSync(f)) continue;
        const dst = path.join(dir, path.basename(f));
        try {
            fs.copyFileSync(f, dst);
            const own = statOwner(f);
            if (own) { try { fs.chownSync(dst, own.uid, own.gid); } catch (e) { } }
            saved.push(dst);
        } catch (e) { }
    }
    return dir;
}

// ══════════════════════════════════════════════════════════════
// 文本级 patch 层改写
// ══════════════════════════════════════════════════════════════

function indentOf(line) { return line.match(/^(\s*)/)[1].length; }
function isBlank(line) { return line.trim() === ''; }

/** 删掉上一次写入的整段（MARK_BEGIN ~ MARK_END） */
function stripMarked(text) {
    const lines = text.replace(/\r\n/g, '\n').split('\n');
    const out = [];
    let skip = false, removed = 0;
    for (const l of lines) {
        if (!skip && l.trim().startsWith(MARK_BEGIN)) { skip = true; removed++; continue; }
        if (skip) {
            if (l.trim().startsWith(MARK_END)) skip = false;
            continue;
        }
        out.push(l);
    }
    return { text: out.join('\n'), removed: removed };
}

/** 删掉顶层 id: <entryId> 的那一条（含其所有缩进子块） */
function removeTopEntry(text, entryId) {
    const lines = text.replace(/\r\n/g, '\n').split('\n');
    const out = [];
    let removed = 0;
    for (let i = 0; i < lines.length; i++) {
        const l = lines[i];
        if (/^-\s+id:\s*/.test(l) && l.replace(/^-\s+id:\s*/, '').trim() === entryId) {
            removed++;
            let j = i + 1;
            while (j < lines.length) {
                const n = lines[j];
                if (isBlank(n)) { j++; continue; }
                if (indentOf(n) > 0) { j++; continue; }
                break;
            }
            i = j - 1;
            continue;
        }
        out.push(l);
    }
    return { text: out.join('\n'), removed: removed };
}

/** 从 composition 里取 persona.prefix（必须够长，否则视为取错） */
function extractPersonaPrefix(text) {
    const doc = assertParses(text, 'composition');
    if (!Array.isArray(doc)) throw new Error('composition 顶层不是数组');
    for (const it of doc) {
        if (!it || typeof it !== 'object' || it.id !== 'persona') continue;
        const cfg = it.config;
        if (cfg && typeof cfg === 'object') {
            const p = cfg.prefix;
            if (typeof p === 'string' && p.length > 500) return p;
        }
    }
    throw new Error('composition 里找不到 persona.prefix（或太短）');
}

/**
 * 用 bundle 骨架生成 preset 块。
 * 只替换 persona 行的 prefix 块标量，其余字节原样保留。
 */
function buildPresetBlock(bundleText, prefix) {
    let lines = bundleText.replace(/\r\n/g, '\n').split('\n');
    // 骨架文件开头的注释不要（那是给 standard 看的）
    let i = 0;
    while (i < lines.length && (isBlank(lines[i]) || lines[i].trim().startsWith('#'))) i++;
    lines = lines.slice(i);

    const rowIdx = lines.findIndex((l) => /^\s+-\s+id:\s*persona\s*$/.test(l));
    if (rowIdx < 0) throw new Error('bundle 骨架里没有 persona 行');
    const rowIndent = indentOf(lines[rowIdx]);
    let rowEnd = lines.length;
    for (let j = rowIdx + 1; j < lines.length; j++) {
        if (isBlank(lines[j])) continue;
        if (indentOf(lines[j]) <= rowIndent) { rowEnd = j; break; }
    }
    let pIdx = -1;
    for (let j = rowIdx; j < rowEnd; j++) {
        if (/^\s+prefix:/.test(lines[j])) { pIdx = j; break; }
    }
    if (pIdx < 0) throw new Error('bundle 骨架的 persona 行没有 prefix');
    const pIndent = indentOf(lines[pIdx]);
    const after = lines[pIdx].replace(/^\s+prefix:\s*/, '').trim();
    let cutEnd = pIdx + 1;
    if (after.startsWith('|') || after.startsWith('>')) {
        while (cutEnd < rowEnd) {
            const l = lines[cutEnd];
            if (isBlank(l)) { cutEnd++; continue; }
            if (indentOf(l) <= pIndent) break;
            cutEnd++;
        }
    }
    const pad = ' '.repeat(pIndent + 2);
    const body = prefix.replace(/\s+$/, '').split('\n')
        .map((l) => (l.length ? pad + l : '')).join('\n');
    lines.splice(pIdx, cutEnd - pIdx, ' '.repeat(pIndent) + 'prefix: |-', body);

    let text = lines.join('\n');
    // 顶层项 id：preset-standard → preset-pj-mode-v5n
    text = text.replace(/^(\s*-\s+)id:\s*preset-standard\s*$/m, '$1id: ' + ENTRY_ID);
    // config 里的 id/name/description
    text = text.replace(/^(\s*)id:\s*standard\s*$/m,
        '$1id: ' + PRESET_ID + '\n$1name: ' + PRESET_NAME +
        '\n$1description: ' + PRESET_DESC);
    // order 统一改成 90（排在官方三个之后，不抢位）
    text = text.replace(/^(\s*)order:\s*\d+\s*$/m, '$1order: 90');
    if (text.indexOf(ENTRY_ID) < 0) throw new Error('骨架改写失败：没生成 ' + ENTRY_ID);
    text = text.replace(/\s+$/, '');
    return MARK_BEGIN + '  由 SeagullKit 写入，卸载时整段删除\n' + MARK_TAG + '\n' + text + '\n' + MARK_END + '\n';
}

/** 检查 patch 层里本工具的条目是否完整可用 */
function inspectPreset(text) {
    const empty = { found: false, pluginRows: 0, hasPrefix: false };
    let doc;
    try { doc = parseDoc(text); } catch (e) { return empty; }
    const row = findPresetRow(doc, ENTRY_ID);
    if (!row) return empty;
    const cfg = row.config;
    const plugins = cfg && Array.isArray(cfg.plugins) ? cfg.plugins : [];
    let hasPrefix = false;
    for (const p of plugins) {
        if (!p || p.id !== 'persona') continue;
        const pc = p.config;
        const pre = pc && pc.prefix;
        if (typeof pre === 'string' && pre.indexOf('操作者运行基线 v5N') >= 0) hasPrefix = true;
    }
    return { found: true, pluginRows: plugins.length, hasPrefix: hasPrefix };
}

// ══════════════════════════════════════════════════════════════
// 三个动作
// ══════════════════════════════════════════════════════════════

function doScan() {
    const patchText = readOr(PATCH, '');
    const info = patchText ? inspectPreset(patchText) : { found: false, pluginRows: 0, hasPrefix: false };

    let bundleOk = false, bundlePluginRows = 0, bundleErr = '';
    try {
        const bd = assertParses(fs.readFileSync(BUNDLE, 'utf8'), 'standard.patch.yml');
        bundleOk = true;
        for (const row of insertRows(bd)) {
            const cfg = row && row.config;
            const plugins = cfg && Array.isArray(cfg.plugins) ? cfg.plugins : null;
            if (plugins) bundlePluginRows = plugins.length;
        }
    } catch (e) { bundleErr = e.message; }

    let compoOk = false, prefixLen = 0, compoErr = '';
    try {
        const pre = extractPersonaPrefix(fs.readFileSync(COMPO, 'utf8'));
        compoOk = true; prefixLen = pre.length;
    } catch (e) { compoErr = e.message; }

    let patchParses = true;
    try { parseDoc(patchText || '[]'); } catch (e) { patchParses = false; }

    emit({
        ok: true,
        mode: 'scan',
        layout: 'harness',
        presetId: PRESET_ID,
        presetName: PRESET_NAME,
        entryId: ENTRY_ID,
        home: HOME,
        patch: PATCH,
        patchBytes: patchText.length,
        patchParses: patchParses,
        installed: !!info.found,
        pluginRows: info.pluginRows || 0,
        prefixOk: !!info.hasPrefix,
        bundle: BUNDLE,
        bundleOk: bundleOk,
        bundlePluginRows: bundlePluginRows,
        bundleError: bundleErr,
        compositionOk: compoOk,
        prefixChars: prefixLen,
        compositionError: compoErr
    });
}

function doInstall() {
    if (!PATCH) throw new Error('缺少 patch 层路径');
    if (!fs.existsSync(BUNDLE)) throw new Error('找不到版本骨架：' + BUNDLE);
    const patchRaw = readOr(PATCH, '');
    const bundleText = fs.readFileSync(BUNDLE, 'utf8');
    const compoText = fs.readFileSync(COMPO, 'utf8');

    const prefix = extractPersonaPrefix(compoText);
    const block = buildPresetBlock(bundleText, prefix);

    // 先摘掉上一次的整段，再摘掉可能被手改漏的裸条目，最后追加
    let base = stripMarked(patchRaw).text;
    const rm = removeTopEntry(base, ENTRY_ID);
    base = rm.text;
    let out = base.replace(/\s+$/, '');
    if (out) out += '\n';
    out += block;

    assertParses(out, 'cordis.patch.yml');
    const info = inspectPreset(out);
    if (!info.found) throw new Error('写入后找不到 preset 条目');
    if (!info.hasPrefix) throw new Error('写入后的 persona 缺少 v5N 基线');
    if (info.pluginRows < 5) throw new Error('写入后的 plugins 数量异常：' + info.pluginRows);

    const bak = backupFiles([PATCH]);
    writeAtomic(PATCH, out, PATCH);

    emit({
        ok: true,
        patch: PATCH,
        backup: bak,
        bytes: out.length,
        pluginRows: info.pluginRows,
        prefixChars: prefix.length,
        removedOld: rm.removed,
        sha: require('crypto').createHash('sha256').update(out, 'utf8').digest('hex')
    });
}

function doUninstall() {
    const patchRaw = readOr(PATCH, '');
    if (!patchRaw.trim()) { emit({ ok: true, removed: 0, note: 'patch 层为空，无需卸载' }); return; }
    let out = stripMarked(patchRaw).text;
    const rm = removeTopEntry(out, ENTRY_ID);
    out = rm.text;
    if (out.indexOf(ENTRY_ID) >= 0) {
        throw new Error('条目 ' + ENTRY_ID + ' 未能完全移除，已中止');
    }
    assertParses(out || '[]', 'cordis.patch.yml');
    const bak = backupFiles([PATCH]);
    writeAtomic(PATCH, out.replace(/\s+$/, '') + '\n', PATCH);
    emit({ ok: true, patch: PATCH, backup: bak, bytes: out.length, removed: rm.removed });
}

// ══════════════════════════════════════════════════════════════

try {
    switch (cmd.mode) {
        case 'scan': emit(doScan()); break;
        case 'install': doInstall(); break;
        case 'uninstall': doUninstall(); break;
        default: fail('未知 mode：' + cmd.mode);
    }
} catch (e) {
    fail(e.message || String(e));
}