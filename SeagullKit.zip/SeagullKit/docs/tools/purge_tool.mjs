// dsh-purge × DSHA 源码补丁工具：backup / apply / restore / status
import fs from 'node:fs';
import path from 'node:path';
const PURGE='/storage/emulated/0/Download/dsh-purge';
const ROOTFS='/data/data/com.dsh.client/files/linux/ubuntu';
const AI_BASE=path.join(ROOTFS,'usr/local/lib/node_modules/@deepseek-ai/dsh/node_modules/@deepseek-ai');
const DSH_HOME=path.join(ROOTFS,'root/.dsh');
const BK_ROOT=path.join(ROOTFS,'root/.dsh/backups/purge-src');
process.env.DSH_HOME=DSH_HOME;
const core=await import('file://'+PURGE+'/lib/core.js');

const [,,cmd,arg]=process.argv;

function filesMap(){
  return core.targetFiles(AI_BASE, DSFHOME_());
}
function DSFHOME_(){ return DSH_HOME; }
function allFps(){
  const files=core.targetFiles(AI_BASE, DSH_HOME);
  const set=new Set();
  for(const v of Object.values(files)){
    if(!v) continue;
    for(const f of (Array.isArray(v)?v:[v])) if(f) set.add(f);
  }
  return [...set];
}

if(cmd==='backup'){
  const ts=new Date().toISOString().replace(/[:.]/g,'-');
  const dir=path.join(BK_ROOT,ts);
  const manifest=[];
  for(const fp of allFps()){
    if(!fs.existsSync(fp)) continue;
    const rel=path.relative(AI_BASE, fp);
    const dst=path.join(dir,'files',rel);
    fs.mkdirSync(path.dirname(dst),{recursive:true});
    fs.copyFileSync(fp,dst);
    manifest.push({file:fp, rel, size:fs.statSync(fp).size});
  }
  fs.writeFileSync(path.join(dir,'manifest.json'),JSON.stringify({aiBase:AI_BASE,created:ts,files:manifest},null,1));
  console.log('备份完成:',dir,'文件数:',manifest.length);
  console.log(dir);
} else if(cmd==='restore'){
  const dir=arg|| (fs.existsSync(BK_ROOT)? path.join(BK_ROOT, fs.readdirSync(BK_ROOT).sort().pop()):null);
  if(!dir||!fs.existsSync(dir)){ console.error('没有可用备份'); process.exit(1); }
  const man=JSON.parse(fs.readFileSync(path.join(dir,'manifest.json'),'utf8'));
  let n=0;
  for(const it of man.files){
    const src=path.join(dir,'files',it.rel);
    if(!fs.existsSync(src)) continue;
    fs.copyFileSync(src,it.file); n++;
  }
  console.log('已还原',n,'个文件，来自',dir);
} else if(cmd==='apply'){
  const ids=(arg||'').split(',').map(s=>+s.trim()).filter(n=>n>0);
  const selected=ids.length? core.ALL_PATCHES.filter(p=>ids.includes(p.id)) : core.ALL_PATCHES;
  console.log('应用',selected.length,'条:',selected.map(p=>p.id).join(','));
  const report=await core.applyPatches(AI_BASE, selected, {});
  const rows=Array.isArray(report)?report:report.rows||[];
  const byStatus={};
  for(const r of rows){ byStatus[r.status]=(byStatus[r.status]||0)+1; }
  console.log('状态分布:',JSON.stringify(byStatus));
  for(const r of rows) if(r.status!=='applied') console.log(`  #${r.patch_id} ${r.name} ${r.status} applied=${r.applied||0} already=${r.already||0} missing=${r.missing||0} notFound=${r.notFound||0}${r.error?' ERR='+r.error:''}`);
  fs.writeFileSync('/data/user/0/com.deepseek.harness/files/dsh/tmp/sess/last_apply.json',JSON.stringify(rows,null,1));
} else if(cmd==='status'){
  const files=core.targetFiles(AI_BASE, DSH_HOME);
  const rows=[];
  for(const p of core.ALL_PATCHES){
    const keys=Array.isArray(p.file)?p.file:[p.file];
    let marked=0, plain=0;
    for(const key of keys){
      const raw=files[key]; const fps=raw?(Array.isArray(raw)?raw:[raw]):[];
      for(const fp of fps){
        let text; try{text=fs.readFileSync(fp,'utf8');}catch{continue;}
        const marks=(p.markers||[]).filter(m=>text.includes(m));
        if(marks.length) marked++; else plain++;
      }
    }
    rows.push({id:p.id,name:p.name,marked,plain});
  }
  const m=rows.filter(r=>r.marked>0);
  console.log('已打标记的条目:',m.length,'/',rows.length);
  for(const r of m) console.log(` #${r.id} ${r.name}`);
} else {
  console.log('用法: backup | apply <ids,...> | restore [dir] | status');
}
