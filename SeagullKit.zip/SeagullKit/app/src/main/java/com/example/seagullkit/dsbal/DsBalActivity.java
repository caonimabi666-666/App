package com.example.seagullkit.dsbal;

import android.Manifest;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsetsController;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * 赛博紫单屏：一个开关管开合，其余为即时生效的设置字段。
 * 所有内容的左边缘统一在 24dp，控件内部水平内边距统一 16dp。
 */
public class DsBalActivity extends AppCompatActivity {

    private static final int PAGE_PAD = 24;
    private static final int INNER_PAD = 16;   // 行与输入框统一内部内边距

    private DsBalSwitch toggle;
    private TextView pillPreview;
    private TextView status;
    private TextView statusDot;
    private EditText etKey;
    private EditText etInterval;
    private TextView alphaVal;

    private boolean pendingEnable;

    private int dp(float v) { return DsBalUi.dp(this, v); }

    private TextView label(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(11.5f);
        t.setTextColor(DsBalUi.TEXT_FAINT);
        t.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        t.setLetterSpacing(0.06f);
        // 与输入框内文字同一条左侧基线
        t.setPadding(dp(INNER_PAD), 0, 0, 0);
        return t;
    }

    private LinearLayout.LayoutParams lp(int w, int h, int top) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.topMargin = dp(top);
        return p;
    }

    /** 赛博胶囊：内容内边距 = 发光预留 + 视觉内边距。 */
    private TextView buildPill() {
        final int glow = Math.round(dp(7));
        TextView t = new TextView(this);
        t.setTextSize(15);
        t.setTextColor(DsBalUi.PILL_TXT);
        t.setGravity(Gravity.CENTER);
        t.setIncludeFontPadding(false);
        DsBalUi.tabular(t);
        t.setBackground(new DsBalPill(this, 16f, 7f));
        t.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        t.setPadding(glow + Math.round(dp(13)), glow + Math.round(dp(5)),
                glow + Math.round(dp(13)), glow + Math.round(dp(5)));
        return t;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackground(new DsBalBackdrop());

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(PAGE_PAD), dp(34), dp(PAGE_PAD), dp(36));
        scroll.addView(root);

        // 标题 + 一条紫色渐变细线（全页唯一的装饰性线条）
        TextView title = new TextView(this);
        title.setText("DeepSeek 余额");
        title.setTextSize(25);
        title.setTextColor(DsBalUi.TEXT);
        title.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        title.setLetterSpacing(-0.01f);
        root.addView(title);

        View rule = new View(this);
        rule.setBackground(DsBalUi.grad(this, new int[]{DsBalUi.VIOLET, 0x00F48FB1}, 2f));
        root.addView(rule, lp(dp(46), dp(3), 10));

        // 悬浮窗本体预览
        pillPreview = buildPill();
        // 发光在 View 内部预留了 7dp，这里负边距抵消，让胶囊可见边缘与页面左基线对齐
        LinearLayout.LayoutParams pillLp = lp(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, 20);
        pillLp.leftMargin = -Math.round(dp(7));
        pillLp.topMargin = Math.round(dp(20) - dp(7));
        root.addView(pillPreview, pillLp);

        // 唯一控件
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(INNER_PAD), dp(15), dp(INNER_PAD), dp(15));
        row.setBackground(DsBalUi.stroked(this, DsBalUi.SURFACE, 16f, DsBalUi.OUTLINE, 0.8f));
        row.setClickable(true);
        row.setFocusable(true);
        row.setContentDescription("开关悬浮窗");

        TextView rowLabel = new TextView(this);
        rowLabel.setText("在屏幕上层显示");
        rowLabel.setTextSize(15.5f);
        rowLabel.setTextColor(DsBalUi.TEXT);
        rowLabel.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        row.addView(rowLabel, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        toggle = new DsBalSwitch(this);
        row.addView(toggle);
        root.addView(row, lp(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, 26));

        row.setOnTouchListener((v, e) -> {
            if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
                v.animate().scaleX(0.985f).scaleY(0.985f).setDuration(80).start();
            } else if (e.getActionMasked() == MotionEvent.ACTION_UP
                    || e.getActionMasked() == MotionEvent.ACTION_CANCEL) {
                v.animate().scaleX(1f).scaleY(1f).setDuration(120).start();
            }
            return false;
        });
        row.setOnClickListener(v -> onToggle());

        // 状态行：信号点 + 文案
        LinearLayout statusRow = new LinearLayout(this);
        statusRow.setOrientation(LinearLayout.HORIZONTAL);
        statusRow.setGravity(Gravity.CENTER_VERTICAL);

        statusDot = new TextView(this);
        statusDot.setText("\u25cf");
        statusDot.setTextSize(9);
        statusDot.setPadding(0, 0, dp(7), 0);
        statusRow.addView(statusDot);

        status = new TextView(this);
        status.setTextSize(12);
        status.setLineSpacing(dp(2), 1f);
        statusRow.addView(status);
        root.addView(statusRow, lp(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, 13));

        // 分隔
        View divider = new View(this);
        divider.setBackgroundColor(0x1FF48FB1);
        root.addView(divider, lp(ViewGroup.LayoutParams.MATCH_PARENT, 1, 26));

        root.addView(label("API KEY"), lp(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, 20));
        etKey = field("sk-...", InputType.TYPE_CLASS_TEXT
                | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        etKey.setText(DsBalPrefs.apiKey(this));
        root.addView(etKey, lp(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, 8));

        root.addView(label("刷新间隔 · 秒"), lp(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, 18));
        etInterval = field("30", InputType.TYPE_CLASS_NUMBER);
        etInterval.setText(String.valueOf(DsBalPrefs.intervalSec(this)));
        root.addView(etInterval, lp(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, 8));

        root.addView(label("悬浮窗文字浓度"), lp(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, 18));

        LinearLayout alphaRow = new LinearLayout(this);
        alphaRow.setOrientation(LinearLayout.HORIZONTAL);
        alphaRow.setGravity(Gravity.CENTER_VERTICAL);

        android.widget.SeekBar sb = new android.widget.SeekBar(this);
        sb.setMax(75);
        sb.setProgress(Math.round((DsBalPrefs.alpha(this) - 0.25f) * 100f));
        if (sb.getProgressDrawable() != null) sb.getProgressDrawable().setTint(DsBalUi.VIOLET);
        if (sb.getThumb() != null) sb.getThumb().setTint(DsBalUi.VIOLET_SOFT);

        alphaVal = new TextView(this);
        alphaVal.setTextSize(12);
        alphaVal.setTextColor(DsBalUi.VIOLET_SOFT);
        alphaVal.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        alphaVal.setMinWidth(dp(44));
        alphaVal.setGravity(Gravity.END);

        alphaRow.addView(sb, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        alphaRow.addView(alphaVal);
        root.addView(alphaRow, lp(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, 2));

        sb.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(android.widget.SeekBar s, int p, boolean u) {
                int pct = 25 + p;
                alphaVal.setText(pct + "%");
                DsBalPrefs.setAlpha(DsBalActivity.this, pct / 100f);
                pillPreview.setAlpha(pct / 100f);
            }
            @Override public void onStartTrackingTouch(android.widget.SeekBar s) {}
            @Override public void onStopTrackingTouch(android.widget.SeekBar s) {}
        });
        alphaVal.setText((25 + sb.getProgress()) + "%");

        etInterval.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable s) {
                try {
                    DsBalPrefs.setIntervalSec(DsBalActivity.this,
                            Integer.parseInt(s.toString().trim()));
                } catch (Exception ignored) {}
            }
        });

        TextView foot = new TextView(this);
        foot.setText("长按悬浮窗看赠金与充值明细，拖动可换位置。");
        foot.setTextSize(11.5f);
        foot.setTextColor(DsBalUi.TEXT_FAINT);
        foot.setLineSpacing(dp(2), 1f);
        // 与上方的标签列同一条基线
        foot.setPadding(dp(INNER_PAD), 0, 0, 0);
        root.addView(foot, lp(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, 30));

        setContentView(scroll);
        applySystemBars(scroll);

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 91);
        }
    }

    private EditText field(String hint, int inputType) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setTextSize(15);
        e.setTextColor(DsBalUi.TEXT);
        e.setHintTextColor(DsBalUi.TEXT_FAINT);
        e.setInputType(inputType);
        e.setTypeface(Typeface.MONOSPACE);
        e.setBackground(DsBalUi.stroked(this, DsBalUi.SURFACE_ALT, 16f, DsBalUi.OUTLINE, 0.8f));
        e.setPadding(dp(INNER_PAD), dp(13), dp(INNER_PAD), dp(13));
        return e;
    }

    /**
     * 系统栏适配 v13：主界面换成白玻璃后，这个页面也要跟。
     *
     * <p>原来写死「深色底 + 白色图标」，在白主题下会出现
     * 白底上挂着白图标的状态栏 —— 什么都看不见。
     *
     * <p>现在统一走浅色：状态栏透明 + **深色图标**
     * （APPEARANCE_LIGHT_STATUS_BARS 是「用浅色背景」的意思，
     *   打开了系统才会把图标变深，名字容易看反）。
     */
    private void applySystemBars(View content) {
        Window w = getWindow();
        if (Build.VERSION.SDK_INT >= 35) {
            w.setDecorFitsSystemWindows(false);
            w.setStatusBarColor(0x00000000);
            w.setNavigationBarColor(0x00000000);
            content.setOnApplyWindowInsetsListener((v, ins) -> {
                android.graphics.Insets bars = ins.getInsets(
                        android.view.WindowInsets.Type.systemBars()
                                | android.view.WindowInsets.Type.displayCutout());
                v.setPadding(0, bars.top, 0, bars.bottom);
                return ins;
            });
        } else {
            // 浅色主题：系统栏跟随页面底色，不要留深色条
            w.setStatusBarColor(0xFFF7F5F8);
            w.setNavigationBarColor(0xFFF7F5F8);
        }
        int mask = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
        if (Build.VERSION.SDK_INT >= 30) {
            // 浅色背景 -> 打开 LIGHT_*，系统把图标渲染成深色
            w.getInsetsController().setSystemBarsAppearance(mask, mask);
        } else if (Build.VERSION.SDK_INT >= 23) {
            View dv = w.getDecorView();
            dv.setSystemUiVisibility(dv.getSystemUiVisibility()
                    | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }
    }

    // ---------- 状态 ----------

    private boolean canDraw() {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this);
    }

    private void onToggle() {
        boolean target = !toggle.isOn();
        if (target) {
            if (!canDraw()) {
                pendingEnable = true;
                openOverlaySettings();
                return;
            }
            if (DsBalPrefs.apiKey(this).trim().isEmpty()) {
                etKey.requestFocus();
                refreshStatus("先填入 API Key，再开启悬浮窗。");
                return;
            }
            startOverlay();
        } else {
            stopOverlay();
        }
    }

    private void startOverlay() {
        DsBalPrefs.setApiKey(this, etKey.getText().toString());
        DsBalPrefs.setWantRunning(this, true);
        Intent i = new Intent(this, DsBalService.class);
        i.setAction(DsBalService.ACTION_REFRESH);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i);
        else startService(i);
        toggle.setOn(true, true);
        refreshStatus(null);
    }

    private void stopOverlay() {
        DsBalPrefs.setWantRunning(this, false);
        stopService(new Intent(this, DsBalService.class));
        toggle.setOn(false, true);
        refreshStatus(null);
    }

    private void openOverlaySettings() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            } catch (Exception e) {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION));
            }
        }
    }

    /** 直接问系统此刻服务在不在，避免两个真相来源打架。 */
    private boolean isOverlayRunning() {
        try {
            android.app.ActivityManager am =
                    (android.app.ActivityManager) getSystemService(ACTIVITY_SERVICE);
            if (am != null) {
                for (android.app.ActivityManager.RunningServiceInfo info
                        : am.getRunningServices(Integer.MAX_VALUE)) {
                    if (DsBalService.class.getName().equals(info.service.getClassName())) {
                        return true;
                    }
                }
            }
        } catch (Exception ignored) {
        }
        return DsBalService.isAlive();
    }

    private void refreshStatus(String override) {
        String s;
        int dot;
        if (override != null) {
            s = override;
            dot = DsBalUi.DANGER;
        } else if (!canDraw()) {
            s = "还没拿到「显示在其他应用上层」权限，点开关会引导授权。";
            dot = DsBalUi.DANGER;
        } else if (DsBalPrefs.apiKey(this).trim().isEmpty()) {
            s = "填入 API Key 后即可开启。";
            dot = DsBalUi.TEXT_FAINT;
        } else if (toggle.isOn() && isOverlayRunning()) {
            long ts = DsBalPrefs.lastTs(this);
            String when = ts == 0 ? "等待首次数据"
                    : android.text.format.DateFormat.format("HH:mm:ss", ts) + " 更新";
            s = "运行中 · 每 " + DsBalPrefs.intervalSec(this) + " 秒刷新 · " + when;
            dot = DsBalUi.SIGNAL;
        } else if (toggle.isOn()) {
            s = "已开启，正在启动…";
            dot = DsBalUi.VIOLET_SOFT;
        } else {
            s = "已关闭。开启后只在屏幕上留一个数字。";
            dot = DsBalUi.VIOLET_DIM;
        }
        status.setText(s);
        status.setTextColor(DsBalUi.TEXT_DIM);
        statusDot.setTextColor(dot);
    }

    private void refreshPreview() {
        String last = DsBalPrefs.lastDisplay(this);
        if (last == null) {
            pillPreview.setText("\u2014");
            pillPreview.setTextColor(DsBalUi.PILL_TXT_DIM);
        } else if (DsBalPrefs.lastOk(this)) {
            pillPreview.setText(last.split("\n")[0]);
            pillPreview.setTextColor(DsBalUi.PILL_TXT);
        } else {
            pillPreview.setText("\u2014");
            pillPreview.setTextColor(DsBalUi.PILL_TXT_ERR);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (isOverlayRunning()) sendToService(DsBalService.ACTION_HIDE);
        syncState();
        status.postDelayed(this::syncState, 900);
        if (pendingEnable && canDraw()) {
            pendingEnable = false;
            onToggle();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (DsBalPrefs.wantRunning(this) && isOverlayRunning()) {
            sendToService(DsBalService.ACTION_SHOW);
        }
    }

    private void sendToService(String action) {
        try {
            Intent i = new Intent(this, DsBalService.class);
            i.setAction(action);
            startService(i);
        } catch (Exception ignored) {
        }
    }

    private void syncState() {
        boolean alive = isOverlayRunning();
        if (DsBalPrefs.wantRunning(this) != alive) DsBalPrefs.setWantRunning(this, alive);

        toggle.setColors(DsBalUi.SURFACE_ALT, DsBalUi.VIOLET_DEEP, DsBalUi.VIOLET,
                0xFF9C7E8C, 0xFFFFF0F5);
        toggle.setOn(alive, false);

        pillPreview.setAlpha(DsBalPrefs.alpha(this));
        refreshPreview();
        refreshStatus(null);
    }
}
