#!/usr/bin/env python3
"""Java 源码结构检查 —— 抓「括号配平但语法断裂」这类 javac 才会发现的问题。

检查项：
  1. 花括号/圆括号/方括号配平（剥离注释与字符串后）
  2. 类体顶层语句的起始关键字是否合法（能抓到"字段声明被切断"）
  3. 缺 import 的常见类型（JSONArray/JSONObject/File 等）

用法: python3 check_java.py [项目根]
"""
import os, re, sys

root = sys.argv[1] if len(sys.argv) > 1 else '.'
fail = 0

def strip_noise(src):
    out = []; i = 0; n = len(src)
    while i < n:
        c = src[i]
        if src.startswith('//', i):
            j = src.find('\n', i); i = n if j < 0 else j
        elif src.startswith('/*', i):
            j = src.find('*/', i + 2); i = n if j < 0 else j + 2
        elif c == '"':
            i += 1
            while i < n:
                if src[i] == '\\': i += 2; continue
                if src[i] == '"': i += 1; break
                i += 1
        elif c == "'":
            i += 1
            while i < n:
                if src[i] == '\\': i += 2; continue
                if src[i] == "'": i += 1; break
                i += 1
        else:
            out.append(c); i += 1
    return ''.join(out)

VALID_STARTS = (
    'private','public','protected','static','final','transient','volatile',
    'int','long','short','byte','char','double','float','boolean','void',
    'String','Object','@','class','interface','enum','abstract','synchronized',
    'return','if','for','while','do','switch','case','default','try','catch',
    'finally','throw','break','continue','else','new','super','this','import',
    'package','}',')','{','instanceof','yield','record',
    '+','-','.','"',"'",'0','1','2','3','4','5','6','7','8','9','null','true','false',
)

files = []
for d, _, fs in os.walk(os.path.join(root, 'app/src/main/java')):
    for f in fs:
        if f.endswith('.java'):
            files.append(os.path.join(d, f))

for p in sorted(files):
    raw = open(p, encoding='utf-8').read()
    src = strip_noise(raw)
    name = os.path.basename(p)

    # 1. 括号配平
    st = []
    pairs = {')': '(', ']': '[', '}': '{'}
    ok = True
    for ch in src:
        if ch in '([{':
            st.append(ch)
        elif ch in ')]}':
            if not st or st.pop() != pairs[ch]:
                ok = False; break
    if not ok or st:
        print(f"❌ {name}: 括号不配平"); fail += 1; continue

    # 2. 类体顶层语句起始合法性
    lines = raw.split('\n')
    depth = 0
    for i, l in enumerate(lines, 1):
        s = l.strip()
        if not s or s.startswith(('//', '*', '/*')): continue
        if depth == 1 and s.endswith(';'):
            if not any(s.startswith(v) for v in VALID_STARTS):
                prev = lines[i - 2].strip() if i > 1 else ''
                # 续行判断：上一行以这些符号结尾就是正常的拼接/换行
                if not prev.endswith((',', '+', '&&', '||', '(', '=', '-', '?', ':', '|', '&')):
                    print(f"❌ {name}:{i}: 可疑语句开头 → {s[:60]}"); fail += 1
        depth += l.count('{') - l.count('}')

    # 3. 缺失 import
    need = {'JSONArray': 'org.json.JSONArray', 'JSONObject': 'org.json.JSONObject',
            'File': 'java.io.File', 'AlarmManager': 'android.app.AlarmManager',
            'PendingIntent': 'android.app.PendingIntent', 'Intent': 'android.content.Intent',
            'Handler': 'android.os.Handler', 'Toast': 'android.widget.Toast'}
    imports = set(re.findall(r'^import\s+([\w.]+);', raw, re.M))
    body = strip_noise(re.sub(r'^import .*$', '', raw, flags=re.M))
    for cls, fq in need.items():
        if re.search(rf'(?<![.\w]){cls}\b', body) and fq not in imports:
            if not re.search(rf'\b{re.escape(fq.split(".")[0])}\.{cls}\b', body):
                print(f"❌ {name}: 用到 {cls} 但没 import {fq}"); fail += 1

if fail == 0:
    print(f"✅ 检查 {len(files)} 个 Java 文件，全部通过")
sys.exit(1 if fail else 0)
