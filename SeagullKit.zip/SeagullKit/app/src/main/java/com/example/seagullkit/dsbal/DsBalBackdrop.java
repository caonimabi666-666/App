package com.example.seagullkit.dsbal;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;

/**
 * 页面底色：近黑紫纵向渐变 + 顶部一团紫光。
 * 用纯绘制做纵深，不用图片，任何分辨率都不糊。
 */
class DsBalBackdrop extends Drawable {

    private final Paint base = new Paint();
    private final Paint bloom = new Paint(Paint.ANTI_ALIAS_FLAG);

    @Override
    protected void onBoundsChange(Rect b) {
        base.setShader(new LinearGradient(0, b.top, 0, b.bottom,
                new int[]{DsBalUi.BG_TOP, 0xFF33202B, DsBalUi.BG_BOTTOM},
                new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));

        // 顶部偏左的紫光，给标题区一点"点亮"的感觉
        float cx = b.width() * 0.28f;
        float cy = -b.height() * 0.06f;
        float r = Math.max(b.width() * 0.92f, b.height() * 0.42f);
        bloom.setShader(new RadialGradient(cx, cy, r,
                new int[]{0x4DF06A96, 0x1FF48FB1, 0x00000000},
                new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP));
    }

    @Override
    public void draw(Canvas c) {
        Rect b = getBounds();
        c.drawRect(b, base);
        c.drawRect(b, bloom);
    }

    @Override public void setAlpha(int a) {}
    @Override public void setColorFilter(ColorFilter cf) {}
    @Override public int getOpacity() { return PixelFormat.OPAQUE; }
}
