package com.example.seagullkit.dsbal;

import android.content.Context;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;

/**
 * 赛博胶囊背景：紫渐变填充 + 更亮的渐变描边 + 外发光。
 * 发光靠 BlurMaskFilter，使用方需给宿主 View 设 software layer。
 */
class DsBalPill extends Drawable {

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint edge = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint halo = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF box = new RectF();

    private final float radius;
    private final float glowInset;
    private final float strokeW;
    private boolean bright = true;
    private int customAlpha = 255;

    DsBalPill(Context c, float radiusDp, float glowDp) {
        this.radius = DsBalUi.dp(c, radiusDp);
        this.glowInset = DsBalUi.dp(c, glowDp);
        this.strokeW = Math.max(1f, DsBalUi.dp(c, 0.8f));
    }

    void setBright(boolean b) {
        bright = b;
        invalidateSelf();
    }

    @Override
    public void setAlpha(int a) {
        customAlpha = a;
        invalidateSelf();
    }

    @Override
    public int getAlpha() { return customAlpha; }

    @Override
    public void setColorFilter(ColorFilter cf) {}

    @Override
    public int getOpacity() { return PixelFormat.TRANSLUCENT; }

    @Override
    protected boolean onStateChange(int[] state) { return false; }

    @Override
    protected void onBoundsChange(Rect b) {
        box.set(b.left + glowInset, b.top + glowInset,
                b.right - glowInset, b.bottom - glowInset);

        int solid = bright ? 0xFF77506A : 0xFF6A4460;
        fill.setShader(new LinearGradient(box.left, box.top, box.right, box.bottom,
                new int[]{bright ? 0xFF77506A : 0xFF6A4460,
                          bright ? 0xFF80566E : 0xFF77506A},
                null, Shader.TileMode.CLAMP));

        int e1 = bright ? 0xFFF48FB1 : 0xFFA06C88;
        int e2 = bright ? 0xFFF06A96 : 0xFFA06C88;
        edge.setShader(new LinearGradient(box.left, box.top, box.right, box.bottom,
                new int[]{e1, e2, e1}, null, Shader.TileMode.CLAMP));
        edge.setStyle(Paint.Style.STROKE);
        edge.setStrokeWidth(strokeW);

        halo.setColor(bright ? 0x55F48FB1 : 0x33F2779B);
        halo.setMaskFilter(new BlurMaskFilter(Math.max(1f, glowInset * 0.85f),
                BlurMaskFilter.Blur.NORMAL));
    }

    @Override
    public void draw(Canvas canvas) {
        if (box.isEmpty()) return;

        // 外发光
        canvas.drawRoundRect(box, radius, radius, halo);

        // 主体
        fill.setAlpha(customAlpha);
        canvas.drawRoundRect(box, radius, radius, fill);

        // 渐变描边
        edge.setAlpha(customAlpha);
        canvas.drawRoundRect(box, radius, radius, edge);
    }

    /** 供 View 计算额外内边距用。 */
    float inset() { return glowInset; }
}
