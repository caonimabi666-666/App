package com.example.seagullkit;

import android.app.Application;

/**
 * 全局 Application。
 *
 * <p>目前没有全局初始化动作 —— 原来的「打开 App 自动签到」已经跟着
 * WorkBuddy 模块一起删掉了。保留这个空壳是为了：
 * <ul>
 *   <li>以后要挂全局初始化（崩溃上报、日志目录、预加载 assets）时有地方放</li>
 *   <li>Manifest 里的 {@code android:name=".SeagullApp"} 不必反复改</li>
 * </ul>
 */
public class SeagullApp extends Application {
}