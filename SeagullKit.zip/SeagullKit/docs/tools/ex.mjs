import fs from 'node:fs';
import zlib from 'node:zlib';
const MAGIC=0xFD2FB528;
function scan(buf){
  const frames=[];let off=0;
  while(off<buf.length){
    const start=off;
    if(buf.length-off<4) break;
    if(buf.readUInt32LE(off)!==MAGIC) throw new Error('bad magic at '+off);
    off+=4;
    if(off===buf.length) break;
    const d=buf.readUInt8(off);off+=1;
    const csf=d>>>6, single=(d&32)!==0, chk=(d&4)!==0, dict=d&3;
    const dictBytes=dict===3?4:dict;
    const csBytes=csf===0?(single?1:0):(1<<csf);
    off+=(single?0:1)+dictBytes+csBytes;
    for(;;){
      if(buf.length-off<3) return {frames,torn:start};
      const bh=buf.readUIntLE(off,3);off+=3;
      const last=(bh&1)!==0, bt=(bh>>>1)&3, bs=bh>>>3;
      off+= bt===1?1:bs;
      if(last)break;
    }
    if(chk) off+=4;
    frames.push({start,end:off});
  }
  return {frames};
}
const src=process.argv[2], dst=process.argv[3];
const buf=fs.readFileSync(src);
const {frames,torn}=scan(buf);
const lines=[];
let bad=0;
for(const f of frames){
  try{
    const t=zlib.zstdDecompressSync(buf.subarray(f.start,f.end)).toString('utf8');
    for(const l of t.split('\n')) if(l.trim()) lines.push(l);
  }catch(e){bad++;}
}
fs.writeFileSync(dst, lines.join('\n')+'\n');
console.log(JSON.stringify({file:src,frames:frames.length,badLines:bad,tornAt:torn??null,bytes:buf.length,outBytes:fs.statSync(dst).size,records:lines.length}));
