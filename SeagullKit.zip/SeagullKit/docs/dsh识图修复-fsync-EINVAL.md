# dsh 识图修复：Android 目录 fsync EINVAL

> 2026-09-22 · 症状：`read_image` 读任何图片都报 `EINVAL: invalid argument, fsync`

## 一、两个独立故障，别混为一谈

修这个问题会先后撞到**两道关卡**，报错完全不同，容易误判成"同一个 bug 没修好"：

| 顺序 | 报错 | 位置 | 原因 |
|------|------|------|------|
| ① | `model "xxx" does not declare image input` | `dsh-tool-fs` 的能力闸 | 模型目录里没声明 `image` |
| ② | `EINVAL: invalid argument, fsync` | `dsh-attachment-local` 的落盘路径 | Android 上 `fsync("/")` 返回 EINVAL |

①修好之后才会暴露②。看到报错变了，说明上一关**已经过了**，不是"没生效"。

## 二、关卡①：模型能力声明

能力闸在 `dsh-tool-fs/lib/index.js` 的 `assertImageCapableRoute()`：

```js
const active = await llm.resolveModelInfo(provider, model, exec.signal);
if (active.inputModalities === void 0 || !active.inputModalities.includes("image"))
    throw new Error(`... model "${model}" does not declare image input ...`);
```

它**每次调用都实时解析**，所以改完配置不用重启引擎，下一次调用即生效。

声明来自模型目录。dsh 内置的 `deepseek-flash`（`name: DeepSeek-V41-Flash`）本身就声明了图片：

```js
{ id: "deepseek-flash", name: "DeepSeek-V41-Flash",
  inputModalities: ["text", "image"],
  imagePixelBudget: DEFAULT_REQUEST_IMAGE_PIXEL_BUDGET,   // 640000
  imageMaxBytes:    DEFAULT_REQUEST_IMAGE_MAX_BYTES }     // 1 MiB
```

但**自定义模型**（本机 `settings.yaml` 里 `id: deepseek-v4.1-flash`）只写了 `text`：

```yaml
llm-deepseek:
  models:
    - id: deepseek-v4.1-flash
      name: DeepSeek-V4.1-Flash
      contextWindow: 1000000
      maxTokens: 131072
      inputModalities:
        - text          # ← 缺 image
```

补一行即可（`imagePixelBudget` / `imageMaxBytes` 不写就是上面那组默认值）：

```yaml
      inputModalities:
        - text
        - image
```

> 注意：`llm-deepseek` 的 catalog 校验规定 **text-only 模型不能声明** `imagePixelBudget` / `imageMaxBytes`
> （`text-only catalog model "x" cannot declare image request limits`）。所以要么两个都加，要么都不加。

## 三、关卡②：fsync("/") 在 Android 上返回 EINVAL

### 定位过程（关键是别猜，用 node 实测）

`read_image` 会把图片存成附件，链路是：

```
saveImageFile → commitPreparedImageFile → publishImmutableObject
  → stageImmutableObject → ensureDurableHome → ensureDurableDirectory → syncDirectory
```

`ensureDurableDirectory(path, boundary)` 会**逐级向上** fsync 父目录：

```js
async function ensureDurableDirectory(path, boundary) {
    const stop = resolve(boundary);          // = parse(DSH_HOME).root = "/"
    let level = target;
    while (level !== stop) {
        const parent = dirname(level);
        await syncDirectory(parent);         // ← 一路 fsync 到 /
        level = parent;
    }
}
```

实测各目录的 `fsync` 行为（node 直接开目录 fd 再 `handle.sync()`）：

```
DIR-SYNC-OK    /data/user/0/com.deepseek.harness/files/payload/dshhome
DIR-SYNC-OK    /data/user/0/com.deepseek.harness/files/payload/dshhome/attachments/v1
DIR-SYNC-OK    /storage/emulated/0/AndroidIDEProjects/SeagullKit     ← fuse 也正常
DIR-OPEN-FAIL  /data/user/0   -> EACCES      ← open 就失败
DIR-OPEN-FAIL  /data          -> EACCES
DIR-SYNC-FAIL  /              -> EINVAL: invalid argument, fsync    ← 就是它
DIR-SYNC-FAIL  /system        -> EINVAL: invalid argument, fsync
```

**Android 的 rootfs 目录不支持 fsync，返回 EINVAL。**

而代码里早就有人打过 Android 补丁，但只兜住了 **open 阶段**：

```js
	try {
		handle = await open(path, constants.O_RDONLY);
	} catch (error) {
		// Android 适配：祖先目录（如 /data/user/0、/data/data）对 App 没有 open 权限
		if (error && (error.code === "EACCES" || error.code === "EPERM")) return;
		throw error;
	}
	try {
		await handle.sync();        // ← 这里没有 catch，EINVAL 直接飞出去
	} finally {
		await handle.close();
	}
```

于是 `/data`、`/data/user` 被跳过，继续向上走到 `/` → `open` 成功 → `sync()` EINVAL → **整条附件链路失败**。

### 修法

给 `sync()` 也加容错（`dsh-attachment-local/lib/index.js` 的 `syncDirectory`）：

```js
	try {
		await handle.sync();
	} catch (error) {
		// Android：rootfs 与 /system 对目录 fd 的 fsync 返回 EINVAL。
		// 目录项持久化是尽力而为，其余真实错误照旧抛出。
		if (!(error && (error.code === "EINVAL" || error.code === "ENOTSUP"
			|| error.code === "EOPNOTSUPP" || error.code === "EACCES"
			|| error.code === "EPERM" || error.code === "EBADF"))) throw error;
	} finally {
		await handle.close();
	}
```

### 验证（新旧代码对照，同一张图、同一条路径）

```
旧代码  SAVE-FAIL -> EINVAL EINVAL: invalid argument, fsync
新代码  SAVE-OK    { "attachmentId": "sha256:120f690d…", "width": 1080, "height": 2392 }
        落盘     dshhome/attachments/v1/objects/12/120f690d…
```

## 四、生效方式：必须重启引擎

node 把模块缓存在内存里，**改完磁盘上的 js 不会自动重载**（`settings.yaml` 那种热重载只对配置生效，对代码无效）。

```sh
su -c 'am force-stop com.deepseek.harness; sleep 1; am start -n com.deepseek.harness/.MainActivity'
```

## 五、补丁会被 dsh 升级覆盖

`dshroot/` 是 App 解压出来的运行时，升级/重装会整目录覆盖 → 补丁丢失，识图再次报 EINVAL。

已备好**幂等**重放脚本（已打过会跳过，打之前自动备份）：

```sh
su -c 'sh /sdcard/DeepSeekHarness/patch-dsh-fsync-einval.sh'
```

## 六、顺带确认：`session-persistence-jsonl` 不用改

同一个包里 `syncDirPosix()` 也是 `open(dir) + handle.sync()`，但它**只 fsync 会话目录本身**，不向上遍历到 `/`，所以碰不到 EINVAL。改之前先看调用链，别照着同一个模式无脑全改。

-----

## 附：把它做成 skill（让别的设备上的 AI 也会修）

skill 就是 DSH 的「技能卡片」：一个放在特定目录里的 md 文件，DSH 会自动发现，
并在遇到匹配任务时把正文加载给 AI。**不用写代码、不用注册、不用重启。**

### 放哪

扫描根按优先级（`dsh-skill-filesystem`）：

| Rank | 来源 | 路径 |
|------|------|------|
| 100 | project-dsh | `<projectRoot>/.dsh/skills` |
| 200 | project-agents | `<projectRoot>/.agents/skills` |
| 300 | custom | 插件配置的 `customSkillDirs` |
| 400 | user-dsh | `<dshHome>/skills` ← 用户级，跨项目可用 |
| 500 | user-agents | `<agentsHome>/skills` |

本机 `$DSH_HOME=/data/user/0/com.deepseek.harness/files/payload/dshhome`，
所以放 `payload/dshhome/skills/<名字>/SKILL.md`。

### 格式

目录 bundle（`<name>/SKILL.md`）或扁平文件（`<name>.md`），**只扫顶层**，
嵌套的 `**/SKILL.md` 不会被发现。frontmatter 必需 `name` + `description`，可选 `whenToUse`。

### 踩到的坑：frontmatter 里的 `: ` 会静默丢卡

第一版 `description` 直接写成未加引号的标量，里面含 `"EINVAL: invalid argument, fsync"` ——
**YAML 的未加引号标量里出现「冒号+空格」是非法语法**，整个 skill 被解析器丢弃，
表现是 `skill "xxx" is unknown or no longer available`，没有任何报错提示。

改法：用折叠块标量 `>-`（或给整个值加引号）：

```yaml
---
name: dsh-image-fsync-einval
description: >-
  修复 DSH 在 Android 上无法识图的问题 —— read_image 报
  "EINVAL: invalid argument, fsync"，或先报 "model xxx does not declare image input"。
whenToUse: >-
  当 read_image / 图片附件报 EINVAL fsync 或 does not declare image input；
  把 DSH 部署到新 Android 设备后读不了图；dsh 升级或重装后识图又坏了。
---
```

改完**立刻生效**（provider 每次列目录都实时扫描，且 watch 根目录），不用重启引擎。

### 搬到别的设备

把整个 skill 目录拷到那台设备的 `<dshHome>/skills/` 下即可，那台设备上的 AI 就能自动发现；
或者只拷 `fix-dsh-image.sh` 过去，`su` 跑一次也行。
