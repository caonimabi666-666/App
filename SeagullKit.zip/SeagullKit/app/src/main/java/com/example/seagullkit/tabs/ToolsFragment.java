package com.example.seagullkit.tabs;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.example.seagullkit.DshPojaActivity;
import com.example.seagullkit.OperitPojaActivity;
import com.example.seagullkit.R;
import com.example.seagullkit.SmsEndpoints;
import com.example.seagullkit.SmsStressActivity;
import com.example.seagullkit.TapFeedback;

/**
 * 工具箱：App 的唯一页面。
 *
 * <p>2026-10 精简后只剩四个工具，全是 Activity 入口 ——
 * 原来的 Fragment 入口（WorkBuddy 账号切换）已经整组删除，
 * 所以 {@code FragmentHostActivity} 那条分包路径也一起去掉了。
 */
public class ToolsFragment extends Fragment {

    /** 一行放几个 */
    private static final int COLUMNS = 2;
    /** 卡片间距（dp） */
    private static final int GAP_DP = 12;

    private static class Tool {
        final int iconRes;
        final String title;
        final String desc;
        final Class<?> target;

        Tool(int iconRes, String title, String desc, Class<?> target) {
            this.iconRes = iconRes;
            this.title = title;
            this.desc = desc;
            this.target = target;
        }
    }

    private static final Tool[] TOOLS = {
            new Tool(R.drawable.ic_tool_dsbal, "DeepSeek 余额",
                    "悬浮窗实时余额 · 单开关 · 轻点刷新",
                    com.example.seagullkit.dsbal.DsBalActivity.class),
            new Tool(R.drawable.ic_tool_sms, "短信测压",
                    "脱壳接口表 · 首发滴滴 · 并发可调", SmsStressActivity.class),
            new Tool(R.drawable.ic_tool_poja, "dsh 破甲模式",
                    "写入 Harness patch 层 · 升级不丢", DshPojaActivity.class),
            new Tool(R.drawable.ic_tool_operit_poja, "Operit 破甲注入",
                    "运行基线 v5N · 打角色卡不打 APK", OperitPojaActivity.class),
    };

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_tools, container, false);
        LinearLayout box = root.findViewById(R.id.tool_container);
        LayoutInflater inf = LayoutInflater.from(requireContext());
        int gap = dp(GAP_DP);

        LinearLayout row = null;
        for (int i = 0; i < TOOLS.length; i++) {
            final Tool tool = TOOLS[i];

            if (i % COLUMNS == 0) {
                row = new LinearLayout(requireContext());
                row.setOrientation(LinearLayout.HORIZONTAL);
                LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT);
                if (i > 0) rlp.topMargin = gap;
                row.setLayoutParams(rlp);
                box.addView(row);
            }

            View card = inf.inflate(R.layout.item_tool, row, false);
            ImageView icon = card.findViewById(R.id.tool_icon);
            icon.setImageResource(tool.iconRes);
            // 图标染实心粉，压在 icon_well 浅粉白底上 —— 同粉撞同粉是旧版的老毛病
            icon.setImageTintList(requireContext()
                    .getColorStateList(R.color.accent_amber));

            ((TextView) card.findViewById(R.id.tool_title)).setText(tool.title);

            // 短信测压的条数随 assets/sms_endpoints.tsv 变化，动态取，避免硬编码过期
            String desc = tool.desc;
            if (tool.target == SmsStressActivity.class) {
                desc = "脱壳接口表 " + SmsEndpoints.count(requireContext())
                        + " 条 · 首发滴滴 · 并发可调";
            }
            ((TextView) card.findViewById(R.id.tool_desc)).setText(desc);

            LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            boolean isLeftCol = (i % COLUMNS == 0);
            boolean hasRightNeighbor = isLeftCol && (i + 1 < TOOLS.length);
            if (isLeftCol) {
                if (hasRightNeighbor) clp.rightMargin = gap / 2;
            } else {
                clp.leftMargin = gap / 2;
            }
            card.setLayoutParams(clp);

            card.setOnClickListener(v -> {
                TapFeedback.press(v);
                startActivity(new Intent(requireContext(), tool.target));
            });

            row.addView(card);
        }

        // 奇数项时补占位保持对齐
        if (row != null && TOOLS.length % COLUMNS != 0) {
            View spacer = new View(requireContext());
            LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(0, 1, 1f);
            slp.leftMargin = gap / 2;
            spacer.setLayoutParams(slp);
            row.addView(spacer);
        }
        return root;
    }

    private int dp(int v) {
        return Math.round(getResources().getDisplayMetrics().density * v);
    }
}