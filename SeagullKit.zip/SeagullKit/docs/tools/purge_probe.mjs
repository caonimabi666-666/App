import fs from 'node:fs';
import path from 'node:path';
const PURGE='/storage/emulated/0/Download/dsh-purge';
const ROOTFS='/data/data/com.dsh.client/files/linux/ubuntu';
const AI_BASE=path.join(ROOTFS,'usr/local/lib/node_modules/@deepseek-ai/dsh/node_modules/@deepseek-ai');
const DSH_HOME=path.join(ROOTFS,'root/.dsh');
process.env.DSH_HOME=DSH_HOME;
const core=await import('file://'+PURGE+'/lib/core.js');
const aiBase=AI_BASE;
console.log('aiBase 存在:',fs.existsSync(aiBase));
const files=core.targetFiles(aiBase,DSH_HOME);
const absent=Object.entries(files).filter(([,v])=>!v||(Array.isArray(v)&&!v.length));
console.log('目标键缺失:',absent.length,':',absent.map(([k])=>k).join(','));
const rows=[];
for(const p of core.ALL_PATCHES){
  const keys=Array.isArray(p.file)?p.file:[p.file];
  let applied=0,already=0,nofile=0;
  for(const key of keys){
    const raw=files[key];
    const fps=raw?(Array.isArray(raw)?raw:[raw]):[];
    if(!fps.length){nofile++;continue;}
    for(const fp of fps){
      let text; try{text=fs.readFileSync(fp,'utf8');}catch{nofile++;continue;}
      let r; try{r=core.applyReplacementsToText(text,p,fp);}catch{already++;continue;}
      if(typeof r.text==='string'&&r.text!==text)applied++;else already++;
    }
  }
  rows.push({id:p.id,name:p.name,layer:p.layer,keys:keys.join(','),applied,already,nofile});
}
const canApply=rows.filter(r=>r.applied>0);
const noChange=rows.filter(r=>r.applied===0&&r.nofile===0);
const noTarget=rows.filter(r=>r.nofile>0&&r.applied===0);
console.log('\n=== 汇总: 总',rows.length,'| 可打',canApply.length,'| 无变化',noChange.length,'| 缺文件',noTarget.length);
console.log('\n=== 可打条目 ===');
for(const r of canApply)console.log(`#${r.id} ${r.name} [${r.layer}] file=${r.keys} 替换点=${r.applied}`);
console.log('\n=== 无变化 ===');
for(const r of noChange)console.log(`#${r.id} ${r.name} [${r.layer}] file=${r.keys}`);
console.log('\n=== 目标文件缺 ===');
for(const r of noTarget)console.log(`#${r.id} ${r.name} [${r.layer}] file=${r.keys}`);
fs.writeFileSync('/data/user/0/com.deepseek.harness/files/dsh/tmp/sess/purge_probe_report.json',JSON.stringify({files,rows},null,1));
