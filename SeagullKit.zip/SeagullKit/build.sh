#!/system/bin/sh
# SeagullKit 构建脚本（AndroidIDE 自带 JDK17 + Android SDK）
RV=/data/data/com.tom.rv2ide/files
export JAVA_HOME=$RV/usr/lib/jvm/java-17-openjdk
export PATH=$JAVA_HOME/bin:$PATH
export GRADLE_USER_HOME=$RV/home/.gradle
export ANDROID_HOME=$RV/home/android-sdk
export ANDROID_SDK_ROOT=$ANDROID_HOME
export LANG=en_US.UTF-8
export LC_ALL=en_US.UTF-8
cd /storage/emulated/0/AndroidIDEProjects/SeagullKit

# ── aapt2 架构修复 ────────────────────────────────────────────────
# Google 只发布 x86_64 的 linux aapt2，AArch64 设备执行不了
# （sh 会把 ELF 当脚本解释，报 syntax error: unexpected '('）。
# AGP 8.13 起 android.aapt2FromMavenOverride 已失效，唯一可行的位置是
# transforms 缓存里 AarResourcesCompilerTransform 解压出来的那个 aapt2。
# 每次构建前检查它的 e_machine，不是 183（AArch64）就换成设备上可用的版本。
AAPT2_SRC=$RV/home/.androidide/aapt2
TRANSFORM=$RV/home/.gradle/caches/9.0.0/transforms/fa3e6a76c321b1cc41664c68cf030e93/transformed/aapt2-8.13.0-13719691-linux/aapt2

if [ -f "$TRANSFORM" ] && [ -f "$AAPT2_SRC" ]; then
    ARCH=$(od -An -tu2 -j18 -N2 "$TRANSFORM" 2>/dev/null | tr -d ' \n')
    if [ "$ARCH" != "183" ]; then
        cp -f "$AAPT2_SRC" "$TRANSFORM"
        chmod 755 "$TRANSFORM"
        echo "=== aapt2 已修正: $ARCH -> 183 (AArch64) ==="
    fi
fi
# ─────────────────────────────────────────────────────────────────

echo "=== java ==="; java -version 2>&1 | head -1
echo "=== gradle assembleDebug ==="
sh ./gradlew --no-daemon assembleDebug
echo "=== BUILD EXIT: $? ==="
