package com.example.seagullkit;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.util.Log;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;

import java.util.List;
import java.util.Locale;

/**
 * 工具：短信测压。
 *
 * <p>把脱壳产物（原 330 个"发验证码"接口，清洗后当前 317 条）做成本地一键执行：
 * 填号码 → 选循环次数 → 开始 → 逐条发送，进度/成功失败实时刷新，随时可停。
 *
 * <p><b>循环测压次数</b>：把整张接口表跑 N 遍。
 * 例如填 3，则总请求数 = 接口数 × 3，进度条按总请求数走。
 *
 * <p>停止方式：
 * <ul>
 *   <li>界面「停止测压」按钮</li>
 *   <li>通知栏的「停止」按钮</li>
 *   <li>（等价 shell 版：Ctrl+C / 按 q / touch 停止文件）</li>
 * </ul>
 */
public class SmsStressActivity extends AppCompatActivity implements SmsStressService.Listener {

    private static SmsStressActivity instance;
    private final Handler ui = new Handler(Looper.getMainLooper());

    /** 循环次数上限，防止手滑填出天文数字。与服务端保持一致（100 轮已是 3 万+ 次请求） */
    private static final int MAX_LOOPS = SmsStressService.MAX_LOOPS;

    private EditText etPhone, etLoops, etConcurrency;
    /** 首发滴滴接口开关 */
    private CheckBox cbPinned;
    private MaterialButton btnStart, btnStop;
    private TextView btnClear;
    private TextView tvState, tvProgress, tvHost, tvOk, tvFail, tvLeft, tvTotal, tvStopReason, tvPlan;
    private ProgressBar bar;
    private LinearLayout logList, delayRow;

    private long delayMs = 100;
    private static final long[] DELAYS = {100, 300, 500, 1000};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        instance = this;
        setContentView(R.layout.activity_sms_stress);

        etPhone = findViewById(R.id.sms_phone);
        cbPinned = findViewById(R.id.sms_pinned);
        etLoops = findViewById(R.id.sms_loops);
        etConcurrency = findViewById(R.id.sms_concurrency);
        btnStart = findViewById(R.id.btn_sms_start);
        btnStop = findViewById(R.id.btn_sms_stop);
        btnClear = findViewById(R.id.btn_sms_clear);
        tvState = findViewById(R.id.sms_state);
        tvProgress = findViewById(R.id.sms_progress);
        tvHost = findViewById(R.id.sms_host);
        tvOk = findViewById(R.id.sms_ok);
        tvFail = findViewById(R.id.sms_fail);
        tvLeft = findViewById(R.id.sms_left);
        tvTotal = findViewById(R.id.sms_total);
        tvStopReason = findViewById(R.id.sms_stop_reason);
        tvPlan = findViewById(R.id.sms_plan);
        bar = findViewById(R.id.sms_bar);
        logList = findViewById(R.id.sms_log);
        delayRow = findViewById(R.id.sms_delay_row);

        etLoops.setInputType(InputType.TYPE_CLASS_NUMBER);
        etConcurrency.setInputType(InputType.TYPE_CLASS_NUMBER);
        // 多号码输入：用多行文本类型，允许换行/逗号/空格分隔
        etPhone.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);

        buildDelayButtons();

        btnStart.setOnClickListener(v -> { TapFeedback.tap(v); startRun(); });
        btnStop.setOnClickListener(v -> {
            TapFeedback.tap(v);
            SmsStressService.stop(this);
            Toast.makeText(this, "已请求停止，当前这条跑完就退出", Toast.LENGTH_SHORT).show();
            ui.postDelayed(this::refreshUi, 200);
        });
        btnClear.setOnClickListener(v -> {
            TapFeedback.heavy(v);
            SmsStressService.clearLog();
            refreshUi();
        });

        tvTotal.setText(String.valueOf(safeCount()));
        refreshUi();
    }

    /**
     * 读接口表条数。
     *
     * <p>这里刻意吞掉异常：接口表是 assets 里的数据，万一读取/解析出问题，
     * 页面应该照常打开并显示 0，而不是直接闪退。
     */
    private int safeCount() {
        try {
            return SmsEndpoints.count(this);
        } catch (Throwable t) {
            Log.w("SeagullSms", "接口表加载失败", t);
            return 0;
        }
    }

    /** 读取当前设定的循环次数，非法值回落到 1 */
    private int readLoops() {
        int n = 1;
        try {
            n = Integer.parseInt(etLoops.getText().toString().trim());
        } catch (Exception ignored) {
        }
        if (n < 1) n = 1;
        if (n > MAX_LOOPS) n = MAX_LOOPS;
        return n;
    }

    /** 读取并发数，非法值回落到默认 8 */
    private int readConcurrency() {
        int n = SmsStressService.DEFAULT_CONCURRENCY;
        try {
            n = Integer.parseInt(etConcurrency.getText().toString().trim());
        } catch (Exception ignored) {
        }
        return SmsStressService.clampConcurrency(n);
    }

    // ── 启动 ─────────────────────────────────────────────────
    private void startRun() {
        String raw = etPhone.getText().toString().trim();
        List<String> phoneList = SmsEndpoints.parsePhones(raw);
        if (phoneList.isEmpty()) {
            Toast.makeText(this, "请填写至少一个手机号", Toast.LENGTH_SHORT).show();
            return;
        }
        // 逐个校验；把第一个不合法的号码回显出来，方便定位
        for (String p : phoneList) {
            if (!SmsEndpoints.isValidPhone(p)) {
                Toast.makeText(this, "号码格式错误：" + p + "（需 11 位数字）",
                        Toast.LENGTH_SHORT).show();
                return;
            }
        }
        if (SmsStressService.isRunning()) {
            Toast.makeText(this, "正在运行中", Toast.LENGTH_SHORT).show();
            return;
        }
        int loops = readLoops();
        int conc = readConcurrency();
        etLoops.setText(String.valueOf(loops));                 // 回写规范化后的值
        etConcurrency.setText(String.valueOf(conc));

        // 请求量过大时二次确认：317条 × 100轮 × 3号 ≈ 9.5万次，长时间高负载会被系统拖垮
        int perLoop = safeCount();
        int estTotal = perLoop * loops * phoneList.size();
        if (estTotal >= 20000) {
            final int fLoops = loops, fConc = conc;
            new androidx.appcompat.app.AlertDialog.Builder(this)
                    .setTitle("请求量较大")
                    .setMessage("本次预计发送 " + estTotal + " 次请求（"
                            + perLoop + " 条 × " + loops + " 轮 × " + phoneList.size() + " 个号码）。\n\n"
                            + "大量请求会长时间占用网络与系统资源，可能导致手机发热、卡顿。\n"
                            + "建议减小循环次数、或拉长发送间隔后再试。是否继续？")
                    .setPositiveButton("继续", (d, w) -> reallyStart(phoneList, fLoops, fConc))
                    .setNegativeButton("取消", null)
                    .show();
            return;
        }
        reallyStart(phoneList, loops, conc);
    }

    /** 真正启动测压 */
    private void reallyStart(List<String> phoneList, int loops, int conc) {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
        }

        boolean pinned = cbPinned == null || cbPinned.isChecked();
        SmsStressService.setListener(this);
        SmsStressService.startMulti(this, phoneList, delayMs, loops, conc, pinned);
        Toast.makeText(this, "已开始：" + phoneList.size() + " 个号码 · 循环 " + loops
                + " 次 · 并发 " + conc
                + (pinned ? " · 首发滴滴" : ""), Toast.LENGTH_SHORT).show();
        ui.postDelayed(this::refreshUi, 300);
    }

    /** 解析当前输入框里的号码数量（界面显示用，非法输入按 1 处理避免除零） */
    private int readPhoneCount() {
        try {
            List<String> l = SmsEndpoints.parsePhones(etPhone.getText().toString());
            return Math.max(1, l.size());
        } catch (Throwable t) {
            return 1;
        }
    }

    // ── 间隔按钮 ──────────────────────────────────────────────
    private void buildDelayButtons() {
        delayRow.removeAllViews();
        for (int i = 0; i < DELAYS.length; i++) {
            final long ms = DELAYS[i];
            MaterialButton b = new MaterialButton(this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(40), 1f);
            if (i > 0) lp.setMarginStart(dp(6));
            b.setLayoutParams(lp);
            b.setText((ms / 1000.0) + "s");
            b.setTextSize(11);
            b.setAllCaps(false);
            b.setCornerRadius(dp(10));
            b.setTextColor(ms == delayMs
                    ? resolveColor(R.color.on_chip_on)
                    : resolveColor(R.color.on_chip_off));
            b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(
                    ms == delayMs ? resolveColor(R.color.chip_on) : resolveColor(R.color.chip_off)));
            b.setOnClickListener(v -> {
            TapFeedback.tap(v);
                delayMs = ms;
                buildDelayButtons();
            });
            delayRow.addView(b);
        }
    }

    /** 已用时长 mm:ss */
    private String fmtElapsed() {
        long start = SmsStressService.getStartedAt();
        if (start <= 0) return "00:00";
        long end = SmsStressService.isRunning()
                ? System.currentTimeMillis()
                : (SmsStressService.getFinishedAt() > 0
                        ? SmsStressService.getFinishedAt() : System.currentTimeMillis());
        long s = Math.max(0, (end - start) / 1000);
        return String.format(Locale.US, "%02d:%02d", s / 60, s % 60);
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    // ── 状态回调（来自工作线程） ──────────────────────────────
    @Override
    public void onSmsState() {
        ui.post(this::refreshUi);
    }

    private void refreshUi() {
        if (tvState == null) return;

        boolean running = SmsStressService.isRunning();
        boolean stopping = running && SmsStressService.isStopRequested();

        if (stopping) {
            tvState.setText("停止中…");
            tvState.setTextColor(resolveColor(R.color.state_warn));
        } else if (running) {
            tvState.setText("测压中");
            tvState.setTextColor(resolveColor(R.color.state_ok));
        } else if (SmsStressService.getFinishedAt() > 0) {
            tvState.setText("已结束");
            tvState.setTextColor(resolveColor(R.color.state_idle));
        } else {
            tvState.setText("待机");
            tvState.setTextColor(resolveColor(R.color.state_idle));
        }

        btnStart.setEnabled(!running);
        btnStop.setEnabled(running);
        etPhone.setEnabled(!running);
        etLoops.setEnabled(!running);
        etConcurrency.setEnabled(!running);

        int perLoop = safeCount();
        int loops = running ? Math.max(1, SmsStressService.getLoops()) : readLoops();
        int phoneCount = running ? Math.max(1, SmsStressService.getPhoneCount()) : readPhoneCount();
        int total = SmsStressService.getTotal();
        int done = SmsStressService.getDone();
        int ok = SmsStressService.getOkCount();
        int fail = SmsStressService.getFailCount();
        if (total <= 0) total = perLoop * loops * phoneCount;

        tvProgress.setText(String.format(Locale.US, "%d / %d", done, total));
        tvOk.setText(String.valueOf(ok));
        tvFail.setText(String.valueOf(fail));
        tvLeft.setText(String.valueOf(Math.max(0, total - done)));
        bar.setMax(Math.max(1, total));
        bar.setProgress(done);

        tvTotal.setText(String.valueOf(perLoop));
        refreshPlan();

        // 当前进度行：第几轮 + 当前域名 + 当前号码
        String host = SmsStressService.getCurrentHost();
        String curPhone = SmsStressService.getCurrentPhone();
        String hostText = (host == null || host.isEmpty()) ? "—" : host;
        if (running && SmsStressService.getPhoneCount() > 1 && curPhone != null && !curPhone.isEmpty()) {
            hostText = hostText + "  →" + curPhone;
        }
        if (running && loops > 1) {
            tvHost.setText(String.format(Locale.US, "第 %d/%d 轮 · %s",
                    Math.max(1, SmsStressService.getLoopIndex()), loops, hostText));
        } else {
            tvHost.setText(hostText);
        }

        String reason = SmsStressService.getStopReason();
        if (running || reason == null || reason.isEmpty()) {
            tvStopReason.setText(running
                    ? String.format(Locale.US, "运行中 · 已用 %s · %.1f 条/秒 · 可随时停止",
                        fmtElapsed(), SmsStressService.getRate())
                    : "");
        } else {
            tvStopReason.setText("已停止：" + reason);
        }

        renderLog();
    }

    /** 「计划」提示：接口表条数 × N 轮 = M 次请求 */
    private void refreshPlan() {
        if (tvPlan == null) return;
        int perLoop = safeCount();
        int loops = readLoops();
        if (perLoop <= 0) {
            tvPlan.setText("接口表未加载");
            return;
        }
        // 注意：这里是独立方法，拿不到 refreshUi() 的局部变量 running，必须重新查
        int conc = SmsStressService.isRunning()
                ? SmsStressService.getConcurrency() : readConcurrency();
        int phoneCount = SmsStressService.isRunning()
                ? Math.max(1, SmsStressService.getPhoneCount()) : readPhoneCount();
        String tail = " · 并发 " + conc;
        String head = "计划：" + perLoop + " 条接口 × " + phoneCount + " 个号码";
        if (loops <= 1) {
            tvPlan.setText(head + "，跑 1 轮，共 " + (perLoop * phoneCount) + " 次请求" + tail);
        } else {
            tvPlan.setText(head + " × " + loops + " 轮 = "
                    + (perLoop * loops * phoneCount) + " 次请求" + tail);
        }
    }

    private void renderLog() {
        logList.removeAllViews();
        List<String> lines = SmsStressService.snapshotLog();
        if (lines.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("暂无记录。填好号码点「开始测压」后这里显示逐条结果。");
            empty.setTextColor(resolveColor(R.color.state_idle));
            empty.setTextSize(11);
            empty.setPadding(0, dp(6), 0, dp(6));
            logList.addView(empty);
            return;
        }
        int shown = 0;
        for (String line : lines) {
            if (shown >= 30) break;
            TextView tv = new TextView(this);
            tv.setText(line);
            tv.setTextSize(11);
            tv.setPadding(0, dp(3), 0, dp(3));
            if (line.contains("✗")) {
                tv.setTextColor(resolveColor(R.color.state_error));
            } else if (line.contains("✓")) {
                tv.setTextColor(resolveColor(R.color.state_ok));
            } else {
                tv.setTextColor(resolveColor(R.color.text_title));
            }
            logList.addView(tv);
            shown++;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        instance = this;
        SmsStressService.setListener(this);
        refreshUi();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (instance == this) {
            instance = null;
            SmsStressService.setListener(null);
        }
    }

    /** 解析 color 资源（配合 v5 主题：所有颜色收口到 colors.xml）*/
    private int resolveColor(int resId) {
        return androidx.core.content.ContextCompat.getColor(this, resId);
    }
}