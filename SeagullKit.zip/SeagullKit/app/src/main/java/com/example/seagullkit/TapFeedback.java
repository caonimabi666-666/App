package com.example.seagullkit;

import android.content.Context;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.HapticFeedbackConstants;
import android.view.View;

/**
 * 统一点击反馈：触觉（震动）+ 视觉（按压缩放）。
 *
 * <h3>为什么需要它</h3>
 * 本工程的按钮原来只有 ripple，白底按钮上 ripple 几乎不可见；
 * 卡片列表（首页工具卡片、会话列表行）连 ripple 都没有 —— 点下去毫无反应。
 * 光靠 ripple 不够，加一层触觉 + 缩放，手感才明确。
 *
 * <h3>三种强度</h3>
 * <ul>
 *   <li>{@link #tap(View)} —— 普通按钮 / 列表项。轻震 + 缩到 0.96</li>
 *   <li>{@link #press(View)} —— 卡片 / 大块区域。极轻震 + 缩到 0.98（幅度小，避免晃）</li>
 *   <li>{@link #heavy(View)} —— 破坏性操作（彻底删除）。双段震动，明确警示</li>
 * </ul>
 *
 * <h3>踩坑记录</h3>
 * <ul>
 *   <li>{@code performHapticFeedback} 依赖系统「触感反馈」开关；用户关了就没震动，
 *       所以视觉缩放是主反馈，震动是增强，不能反过来依赖震动。</li>
 *   <li>Android 12+（API 31）HapticFeedbackConstants 才有 {@code CONFIRM}；
 *       低版本回落到 {@code VIRTUAL_KEY}。</li>
 *   <li>直接调 {@code Vibrator.vibrate} 需要 VIBRATE 权限（本工程 Manifest 已有），
 *       但 {@code performHapticFeedback} 不需要 —— 优先用它，更省电也更符合系统设置。</li>
 * </ul>
 */
public final class TapFeedback {

    private TapFeedback() { }

    /** 缩放动画时长（ms）。太长会显得拖沓，100 左右最跟手 */
    private static final int DUR = 90;

    /** 普通按钮 / 列表项：轻震 + 缩到 0.96 */
    public static void tap(View v) {
        if (v == null) return;
        haptic(v, HapticFeedbackConstants.VIRTUAL_KEY);
        bounce(v, 0.96f);
    }

    /** 卡片 / 大块区域：缩到 0.98。幅度小，避免整块晃得难受 */
    public static void press(View v) {
        if (v == null) return;
        haptic(v, HapticFeedbackConstants.VIRTUAL_KEY);
        bounce(v, 0.98f);
    }

    /**
     * 破坏性操作（彻底删除 / 清空全部）：双段震动 + 缩到 0.94。
     * 明确告诉手指「这个不一样」。
     */
    public static void heavy(View v) {
        if (v == null) return;
        haptic(v, HapticFeedbackConstants.LONG_PRESS);
        bounce(v, 0.94f);
        // 第二段：80ms 后再补一下，形成「双响」
        v.postDelayed(new Runnable() {
            @Override
            public void run() {
                haptic(v, HapticFeedbackConstants.VIRTUAL_KEY);
            }
        }, 80);
    }

    /** 失败 / 拒绝（如未选中任何项就点删除）：单次长震 */
    public static void reject(View v) {
        if (v == null) return;
        haptic(v, HapticFeedbackConstants.LONG_PRESS);
    }

    // ── 内部实现 ─────────────────────────────────────────────

    /**
     * 触觉反馈。
     * 优先 {@code performHapticFeedback}（不需要权限、遵循系统设置）；
     * 系统关掉触感时它静默无效 —— 这是预期行为，视觉反馈仍然生效。
     */
    private static void haptic(View v, int constant) {
        try {
            // 不用 FLAG_IGNORE_GLOBAL_SETTING —— 那会无视用户在系统里关掉的触感开关，
            // 属于反用户行为。遵循系统设置：关了就不震，视觉反馈照常。
            v.performHapticFeedback(constant);
        } catch (Throwable ignored) {
            // 某些 ROM 会抛；不影响视觉反馈，吞掉
        }
    }

    /**
     * 按下缩放：缩下去 → 弹回来。
     *
     * <p>防快速连点：先 {@code cancel()} 掉进行中的动画并把 scale 归位，
     * 再从确定的起点开始。否则连点时两层 {@code withEndAction} 会互相取消，
     * scale 可能卡在中间值（0.97 之类）回不来。
     *
     * <p>归位带来的视觉跳变幅度 = 当前值到 1.0 的差，最大也就 0.04，察觉不到。
     */
    private static void bounce(final View v, final float scale) {
        v.animate().cancel();
        v.setScaleX(1f);
        v.setScaleY(1f);
        v.animate()
                .scaleX(scale).scaleY(scale)
                .setDuration(DUR)
                .withEndAction(new Runnable() {
                    @Override
                    public void run() {
                        v.animate()
                                .scaleX(1f).scaleY(1f)
                                .setDuration(DUR)
                                .withEndAction(null)   // 断链，防止无限嵌套
                                .start();
                    }
                })
                .start();
    }

    /** 可选：一次性震动（用于通知 / 完成提示），带 VIBRATE 权限 */
    public static void buzz(Context ctx, long ms) {
        if (ctx == null) return;
        try {
            Vibrator vb = (Vibrator) ctx.getSystemService(Context.VIBRATOR_SERVICE);
            if (vb == null || !vb.hasVibrator()) return;
            if (Build.VERSION.SDK_INT >= 26) {
                vb.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE));
            } else {
                vb.vibrate(ms);
            }
        } catch (Throwable ignored) {
        }
    }
}