# SeagullKit 海鸥工具箱

Android Code Studio（com.tom.rv2ide）工程 · Material3 白色主题 · 工具卡片式首页。

## 当前工具

| 工具 | Activity | 说明 |
|------|----------|------|
| 💰 DeepSeek 余额 | dsbal.DsBalActivity | 悬浮窗实时余额 · 单开关 · 轻点刷新（前台服务） |
| 📨 短信测压 | SmsStressActivity | 脱壳接口表 317 条 · 首发滴滴 · 逐条发送 · 进度可视 · 随时可停（前台服务） |
| 🐦 dsh 破甲模式 | DshPojaActivity | 一键写入 Preset v5N · 升级不丢（需 root） |
| 🧹 dsh 会话清除 | DshCleanActivity | 删会话 + **残留清扫**（孤儿索引/死引用/空壳/spill）· 回写验证（需 root） |
| 🗑️ dsh 会话消息删除 | DelSessionActivity | 按轮次删单条对话 · 其余保留（需 root） |
| 🗑️ Operit 会话清除 | OperitSessionActivity | 清会话 · 清摘要 · 清记忆 —— 让破甲干净生效（需 root） |
| 🐦 Operit 破甲注入 | OperitPojaActivity | 无限四代 v0.4.0 双层协同注入 · 打角色卡不打 APK（需 root） |
| 📈 科创板看板 | fund.FundBoardActivity | 我的基金 · 板块 · 散户情绪 · 日盈亏 |
| 🗓️ WorkBuddy 签到 | workbuddy.WorkBuddyActivity | 每日积分 · 打开 App 自动签到 · 连签记录 |

> 2026-10-23 移除了三个工具：**无霜**（LSPosed 防冻结模块）、**b.ai 账户余额**、
> **dsh 配置编辑**。相关源码、资源、xposed 依赖已一并删除，
> 备份在 `/sdcard/SeagullKit/backup-20261023-0051/`。


## 界面结构（v8 · 底部三导航）

2026-10-23 改版。原来首页是「全部工具的网格」，现在拆成三个 tab：

```
┌─────────────────────────┐
│                         │
│      页面内容区          │
│   (Fragment 切换)        │
│                         │
├─────────────────────────┤
│  📈主页  ▦功能  👤我的   │
│  BottomNavigationView   │
└─────────────────────────┘
```

| Tab | 内容 | 实现 |
|---|---|---|
| **主页** | 科创板看板（持仓/走势/情绪/诊断） | `fund.FundBoardActivity`（Fragment） |
| **功能** | 工具箱列表（7 个工具） | `tabs.ToolsFragment` |
| **我的** | WorkBuddy 签到 | `workbuddy.WorkBuddyActivity`（Fragment） |

### 为什么用 show/hide 而不是 replace

科创板看板一次拉数据要 **15~30 秒**（5 只基金净值 + 7 个板块代理 + 5 个基金吧）。
用 `replace` 的话，每次从「功能」切回「主页」都会重建 Fragment、重新拉一遍，
用户会看到空白页和转圈的标题。

所以三个 Fragment 都用 `add` 建好，切换时 `hide`/`show`：

```java
for (Fragment f : getSupportFragmentManager().getFragments()) {
    if (f == target) continue;
    if (!f.isHidden()) tx.hide(f);
}
if (target.isHidden()) tx.show(target);
```

代价是三个页面同时驻留内存，但都是轻量 View，可接受。

### Fragment 化踩的坑

1. **`findViewById` 没有无参版本**
   Activity 里可以直接调，Fragment 必须 `root.findViewById`。
   全文件替换时注意别把 `R.id.xxx` 里的也换了。

2. **异步回调必须查存活状态**
   数据要拉 15~30 秒，用户很可能中途切到别的 tab。
   此时 Fragment 的 View 已销毁，直接 `setText` 会 NPE，
   `requireContext()` 会抛 `IllegalStateException`。

   ```java
   ui.post(() -> {
       if (!isAdded() || getView() == null) return;   // ← 必须
       ...
   });
   ```

3. **`this` 当 Context 的地方全要换**
   `WbApi.getToken(this)` → `WbApi.getToken(requireContext())`，
   `Toast.makeText(this, ...)` → `Toast.makeText(requireContext(), ...)`。

4. **类名保留了 Activity 后缀**
   `FundBoardActivity` / `WorkBuddyActivity` 现在实际是 Fragment，
   类名没改是为了不牵动 `SeagullApp`、文档、备份里的路径引用。
   看代码时别被名字误导。

### Manifest 变化

两个类从 Activity 变成 Fragment，对应的 `<activity>` 声明已删除
（Fragment 不注册进 Manifest）。



### 主题（v13 · 白玻璃）

三版才定下来。前两版的失败都记在这里，免得以后再走一遍。

#### v10 → v12 为什么都不行

| 版本 | 做法 | 失败原因 |
|---|---|---|
| v10 樱粉 | 只把紫色值换成粉色值 | 深底上粉色仍是点缀，成不了主体 |
| v11 明快粉 | 底压到 `#241420` 做层次 | 接近纯黑，整体暗沉 |
| v12 透光粉 | 底色提亮 + 三个径向光斑 | **光斑是三个 400dp 椭圆，像鸡蛋，开屏也显示** |

v12 那个「鸡蛋」的本质：`bg_main.xml` 里用

```xml
<shape android:shape="oval">
    <gradient android:gradientRadius="480dp" android:type="radial" />
```

做了三团椭圆径向渐变当「光斑」。半径 480dp 在竖屏上就是覆盖半屏的大椭圆，
三团叠加 → 看着像鸡蛋。而且 `windowBackground = @drawable/bg_main`，
所以**开屏显示的就是这三个椭圆**。

#### v13 的改法：换方向，不调参数

```
深色主题  →  浅色主题（Material3.Light）
背景光斑  →  一层线性渐变，零 shape 图形
半透明深色卡片  →  半透明白卡片 + 描边
```

**为什么这才叫玻璃**
真正的毛玻璃 = 白色半透明 + 边缘描边 + 底下有东西可透。
v12 用椭圆光斑去「制造」底下那点东西，结果光斑本身成了视觉噪音。
浅灰白渐变就够 —— 它提供明暗变化，但**不成形**。

#### 关键色值

| 用途 | 值 | 说明 |
|---|---|---|
| 页面底 | `#F7F5F8 → #EFEDF3` | 极淡灰白渐变，左上略暖 |
| 卡片填充 | `#CCFFFFFF` | 80% 白 |
| 卡片描边 | `#E2DCE8` | 淡紫灰，1dp |
| 卡片反光 | `#99FFFFFF` 渐变 | 上沿白到透明 |
| 主文字 | `#2E2430` | 对白卡 14.88:1 |
| 樱粉 | `#E8628F` | 对白卡 3.19:1 |

#### 换 Light 主题必须改的地方

| 项 | Dark | Light |
|---|---|---|
| theme parent | `Theme.Material3.Dark` | `Theme.Material3.Light` |
| `windowLightStatusBar` | `false` | **`true`** |
| `windowLightNavigationBar` | `false` | **`true`** |
| `DsBalActivity` 系统栏 | 深色底 + 白图标 | 浅底 + 深图标 |
| `MiniChart` 网格线 | `#3A2033` | `#E5E0EC` |
| `MiniChart` 调色板 | 浅粉/青绿 | 全部加深一档 |

**最容易漏的是系统栏图标**：`windowLightStatusBar=true` 的意思是
"我用浅色背景，请把图标画深"——名字容易看反，漏了就是白底上看不见状态栏图标。

#### 对比度校验

白底上所有文字都过 WCAG 标准：

```
主文字 #2E2430  对白卡 14.88:1  ✅
正文   #4A3D4F  对白卡 10.14:1  ✅
次要   #7A6B80  对白卡  4.95:1  ✅
琥珀   #9E5F0A  对白卡  5.13:1  ✅  (原 #CC8A2E 只有 2.90，调深过)
```

#### 悬浮窗保持深色

`dsbal`（DeepSeek 余额悬浮窗）**没有跟着换浅色**。
它浮在别人 App 上面，深色在任意背景下都更稳；
浅色悬浮窗在浅色壁纸上会糊成一片。

## 工程结构

```
SeagullKit/
├── build.gradle                     # 根构建：插件声明
├── settings.gradle                  # 仓库 + include(":app")
├── gradle.properties                # UTF-8 / daemon / 内存参数
├── gradle/libs.versions.toml        # 版本目录
└── app/
    ├── build.gradle                 # SDK / 包名 / Java17 / viewBinding
    └── src/main/
        ├── AndroidManifest.xml
        ├── assets/
        │   ├── sms_endpoints.tsv          # 短信测压接口表（脱壳产物，清洗后 317 行 × 6 列）
        │   └── poja_payload.txt           # 破甲载荷（无限四代 v0.4.0 · Operit 适配版）
        ├── java/com/example/seagullkit/
        │   ├── MainActivity.java           # 首页（工具卡片列表）
        │   ├── BalanceChecker.java         # 余额查询核心（GET /v1/balance）
        │   ├── BalanceActivity.java        # 余额界面
        │   ├── BalanceService.java         # 前台服务 + 低额预警通知
        │   ├── NetworkChecker.java         # 三态检测：ONLINE / PROXY_DOWN / OFFLINE
        │   ├── NetMonitorService.java      # 前台服务 + 通知
        │   ├── NetMonitorActivity.java
        │   ├── SmsEndpoints.java           # 短信测压：接口表加载 + 占位符展开
        │   ├── SmsStressSender.java        # 短信测压：单次请求（HttpURLConnection）
        │   ├── SmsStressService.java       # 短信测压：前台服务主循环 + 通知停止按钮
        │   ├── SmsStressActivity.java      # 短信测压界面
        │   ├── DshCleaner.java             # dsh 会话清除核心（列出会话 + su 执行脚本）
        │   ├── DshCleanActivity.java       # dsh 会话清除界面（勾选列表）
        │   ├── DshConfigActivity.java
        │   ├── OperitSessionCleaner.java    # Operit 会话清除核心（Room 库改写 + 记忆/画像转存）
        │   ├── OperitSessionActivity.java   # Operit 会话清除界面（勾选列表）
        │   ├── OperitPojaEditor.java        # Operit 破甲注入核心（protobuf 手写读写 + su -M）
        │   ├── OperitPojaActivity.java      # Operit 破甲注入界面
        │   └── BootReceiver.java           # 开机自启监测
        └── res/
            ├── drawable/    # 渐变背景 / 卡片 / 圆角 / 图标
            ├── layout/      # activity_main + item_tool + item_session + 七个工具页
            └── values/      # strings / colors / themes
```

## 关键配置

| 项 | 值 |
|----|-----|
| AGP | 8.13.0 |
| Gradle | 9.0.0 (wrapper) |
| Java | 17（compileOptions source/target 17，用了 lambda） |
| compileSdk / minSdk / targetSdk | 36 / 24 / 34 |
| 主题 | Theme.Material3.Light.NoActionBar |

## 新增工具的方法

1. 写 `XxxActivity.java`
2. 写 `res/layout/activity_xxx.xml`
3. Manifest 里注册 `<activity android:name=".XxxActivity" android:exported="false" />`
4. `MainActivity.TOOLS` 数组加一项：
   ```java
   new Tool("🔧", "工具名", "描述", XxxActivity.class),
   ```

---

## 工具 1：网络连通性检测 —— 工作原理

**三态判定**，核心是区分"本地网络问题"和"代理问题"：

| 状态 | 国外探测 | 国内探测 | 含义 |
|------|---------|---------|------|
| `ONLINE` | 通 | 通 | 一切正常 |
| `PROXY_DOWN` | 不通 | 通 | **本地网正常，代理挂了** |
| `OFFLINE` | 不通 | 不通 | 完全断网 |

- **国外探测点**：google/gstatic/cloudflare/youtube 的 `generate_204`
- **国内探测点**：baidu/qq/taobao + MIUI 连通性检测
- **出口IP**：ipify / ifconfig.me / ip.sb / 3322
- **VPN 检测**：`ConnectivityManager.getAllNetworks()` 查 `TRANSPORT_VPN`

异常时通过前台服务发通知（`IMPORTANCE_HIGH` + 震动），状态恢复时发恢复通知。

---

## 工具 2：dsh 会话清除 + 残留清扫 —— 工作原理

目标：把 DeepSeek Harness（`com.dshmobile.shell`）的聊天会话**连残留一起清干净**。

会话日志删掉 ≠ 干净。元数据会留在别处，UI 上表现为「点不开的空壳会话」。
四个动作：

| 动作 | 做什么 | 碰不碰会话 |
|------|--------|-----------|
| **残留扫描** | 只读。列出孤儿条目/死引用/空壳/spill/宿主是否在跑 | 不碰 |
| **只清残留** | 停机 + 清索引 + 清空壳 + 清 spill | **不碰** |
| 删除所选 / 一键清除全部 / 彻底删除全部 | 删会话 + 顺带清残留 | 碰 |
| **回写验证** | 等 30 秒复查孤儿是否复活 | 不碰 |

### 存储布局

```
<dsh-home>/
├── sessions/
│   └── <cwd-slug>/                    # 工作目录，"/" 全换成 "-"
│       └── session-<uuid>/
│           └── session.jsonl[.zstd]   # ← 只有存在它，才算「活会话」
├── storages/
│   ├── session_projcache.json         # 会话索引（UI 列表读这里，含标题/轮次/词元）
│   └── workspace.json                 # 工作区索引（sessionIds / archivedSessionIds）
└── tmp/dsh-spill-*/                   # 工具输出溢出目录（可再生）
```

`<dsh-home>` 常见位置：
- `/data/data/com.dshmobile.shell/files/home/.dsh`
- `/data/data/<pkg>/files/linux/ubuntu/root/.dsh`（proot 版）

### 四个残留污染源

| # | 位置 | 症状 |
|---|------|------|
| 1 | `session_projcache.json` 里无日志的孤儿条目 | UI 列表残留「点不开的空壳会话」 |
| 2 | `workspace.json` 的 `sessionIds` / `archivedSessionIds` 死引用 | 工作区侧栏引用已死会话 |
| 3 | 无 `session.jsonl` 的空壳会话目录 | 占着缓存条目，被误判成活会话 |
| 4 | `tmp/dsh-spill-*` | 工具输出转存残留，白占空间 |

**「活会话」的判定标准**：目录里有 `session.jsonl*` 才算。
没有日志的目录一律不算活 —— 这正是旧版把空壳当成活会话、
导致缓存条目永远清不掉的原因。

### 会话列表（勾选删除）

界面上的列表来自 `DshCleaner.listSessions()`：

1. su 里探测 `<dsh-home>`，对 `sessions/*/session-*/session.jsonl*` 跑
   `stat -c '%Y|%s|%n'` 拿到 修改时间 | 大小 | 路径
2. 顺带 `cat storages/session_projcache.json`，把 `tables.sessions.<id>.rows.title.val`
   取出来当标题（取不到就显示 `session-<uuid>`）
3. 列表按修改时间倒序，**最新一条标 `▶ …（当前）`** —— 它是正在写的会话
4. 每行一个 CheckBox；全选 / 全不选 / 刷新列表
5. 「删除所选」→ 弹转存 / 彻底删除二选一 → 只处理勾中的目录

**作用域校验（双保险）**：Java 侧只允许路径里含 `/sessions/`、目录名以 `session-` 开头、
不含 `..`/引号/换行；shell 侧 `remove_one()` 再 `case "$s" in "$SESS"/*/session-*)`
兜一道，越界路径直接跳过并打 `[!] skip (out of scope)`。
选中的目录通过 heredoc（`<<'DSHTARGETS'`）传入脚本，不走命令行拼接。

**保护当前会话**：默认勾选。开启后 `remove_one()` 会比对 `$PROTECT`（活动会话 id），
命中就跳过并打 `[!] skip (protected active session)`。清全部时不会把自己正在聊的会话删掉。

### 执行流程（8 步）

1. **停机** —— 见下节，这是最容易翻车的一步
2. **删会话** —— 只动选中目录（或全部）：`mv` 转存到
   `/data/local/tmp/dsh-trash-<时间戳>`（"彻底删除"模式则 `rm -r -f`）
3. **清空壳** —— 无 `session.jsonl` 的会话目录 `rm -rf`
4. **索引处理** —— 两种模式（见下节）
5. **清 spill** —— `find "$DSH" -maxdepth 3 -type d -name 'dsh-spill-*'` 后 `rm -rf`
6. **chown 还原属主** —— root 建/删文件后属主会变成 root:root，
   dsh 以 `u0_aXXX` 跑会权限拒绝。脚本自动从 `settings.yaml` 取原属主还原
7. **全盘残留引用扫描** —— `grep -rlE` 在 `$DSH` 下找孤儿 id，只报告不改
8. **重启 dsh** —— 然后建议用「回写验证」等 30s 复查

> **本工具不产生任何备份文件。** 早期版本会在 `/sdcard/SeagullKit/dsh-backup/`
> 和 `/data/local/tmp` 各写一份 projcache/workspace 备份，已彻底移除。
> 理由：projcache 是可再生的投影缓存（删了宿主按现存日志重建，只丢标题等派生数据），
> 会话正文在 `session.jsonl` 里，只有「彻底删除」模式才会动它 —— 备份这两个文件
> 没有实际保护价值，只是垃圾。

### 停机：为什么必须扫 /proc（本工具最关键的一处修正）

`session_projcache.json` 由**正在运行的 dsh 宿主进程**持有。它启动时把整个文件
读进内存，之后**每次落盘都从内存全量写回**。所以：

> **宿主运行期间，对该文件的任何修改都会在数十秒内被覆盖。**

而且宿主**不是** Android App 主进程本身，而是它拉起的 node 子进程：

```
/system/bin/linker64 \
  /data/user/0/com.dshmobile.shell/files/usr/bin/node \
  --expose-internals \
  /data/user/0/com.dshmobile.shell/files/usr/lib/node_modules/@deepseek-ai/dsh/lib/bin.js \
  web --port 3080
```

实测数据（本机）：

```
pidof com.dshmobile.shell          → 21482     ← App 主进程
扫 /proc/*/cmdline 找 dsh/lib/bin.js → 2010      ← 真正持有缓存的 node 宿主
```

**只杀 21482，2010 还活着 → 几十秒后全量回写，孤儿复活。**

所以 `host_pids()` 两条路一起走：

```sh
host_pids() {
  {
    pidof "$PKG" 2>/dev/null
    for d in /proc/[0-9]*; do
      [ -r "$d/cmdline" ] || continue
      c=$(tr '\0' ' ' < "$d/cmdline" 2>/dev/null)
      case "$c" in
        *dsh/lib/bin.js*) echo "${d#/proc/}" ;;
      esac
    done
  } | tr ' ' '\n' | grep -E '^[0-9]+$' | sort -u
}
```

`stop_host()` 的流程：`am force-stop` → `sleep 1` → `kill -9` 全部 pid →
**最多等 15 秒**每秒复查 → 仍有残留就置 `HOST_ALIVE=1`，
Java 侧据此把结果标为「不可信」，界面直接提示「请重跑」。

> ⚠️ **检测串不要写成 `grep "[d]sh web"`**。`dsh` 和 `web` 之间隔着 `lib/bin.js`，
> 那样会**永远误报为「未运行」**，导致你在宿主运行期间动手、白做一场。实测已验证。

### 索引处理的两种模式

| 模式 | 做法 | 适用 |
|------|------|------|
| **整删**（默认） | `rm -f session_projcache.json`，宿主下次启动按现存日志重建 | 最彻底，不丢对话内容（缓存全是可再生的派生数据） |
| **精修** | node 脚本递归摘掉孤儿条目 + workspace 死引用，保留其他条目 | 想保住其他会话的标题等缓存 |

两种模式都**顺带摘 `workspace.json` 的死引用**（整删模式除外 —— 它不动 workspace，
但精修会处理）。

**精修模式的安全闸**：如果扫磁盘得到的「活会话」集合为空、而缓存里还有条目，
脚本会输出 `@@ABORT|alive-empty` 并**放弃改写**。因为这种情况几乎一定是
`sessions` 路径/权限读失败，不是会话真被全删 —— 没有这道闸，一次读失败就会把整份缓存误清。
shell 侧识别 `@@ABORT` 后置 `SWEEP_ABORT=1`，界面提示「索引未改」。

**精修器兼容的存法**：
- 键是 session id（对象 key）
- 值是 session id（数组元素 / `sessionId` 字段）

写回用**原子操作**（先写 `.tmp` 再 `chmod` + `rename`），避免写坏索引。
JSON 解析失败时不动原文件。

### node 必须带 LD_LIBRARY_PATH（旧版从没成功过的原因）

dsh 自带的 node 是动态链接 dsh 私有 lib 的二进制：

```
$ /data/data/com.dshmobile.shell/files/usr/bin/node -e "1"
CANNOT LINK EXECUTABLE ".../node": library "libz.so.1" not found: needed by main executable
```

`libz.so.1` 就在 `/data/data/com.dshmobile.shell/files/usr/lib/` 下，加上就通：

```sh
LD_LIBRARY_PATH=/data/data/com.dshmobile.shell/files/usr/lib \
  /data/data/com.dshmobile.shell/files/usr/bin/node -e "console.log(1+1)"   # → 2
```

所以 `PROBE_HOME` 会同时探测 `NODE` 和 `NODELIB`，三处 node 调用
（扫描 / 精修 / 回写验证）全部包成 `LD_LIBRARY_PATH="$NODELIB" "$NODE" …`。

> 不加这一步，node 直接链接失败 → 索引清理静默跳过 → 孤儿永远留着。
> **这是旧版「清完还有残留」的直接原因之一。**

### 回写验证（为什么必须有）

清完立刻看，是干净的。几十秒后宿主周期性落盘，孤儿可能又回来了 ——
所以「清完看着成功」不等于成功。`recheck()` 的做法：

1. 把本次摘掉的孤儿 id 写进 `/data/local/tmp/dsh-orphan-ids.txt`
2. `sleep 30`（默认，`VERIFY_WAIT_SEC`）
3. node 复查：这些 id 有没有重新出现在 `session_projcache.json` / `workspace.json` 里
4. 输出 `@@RECHECK|<复活数>|<缓存条目>|<活会话>` 和 `@@WSBACK|…`

判定：**复活数 = 0 且 workspace 无回写 → 通过**。否则说明宿主没真正停机。

### 幂等

精修模式天然幂等：对已清干净的索引再跑一次，输出 `@@CACHE|1|1`、`@@ORPHANS|0`，
不产生任何变化。

### 备份与回滚

**本工具不做任何备份。** 这是一次刻意的删减，理由：

| 文件 | 删了会怎样 |
|------|-----------|
| `storages/session_projcache.json` | 可再生的投影缓存。宿主下次启动按现存 `session.jsonl` 重建，只丢标题/预览等派生数据 |
| `storages/workspace.json` | 工作区索引，同样可重建 |
| `sessions/*/session.jsonl` | **真正的对话正文**。只有「彻底删除」模式才会动它 |

早期版本每次运行都往 `/sdcard/SeagullKit/dsh-backup/` 和 `/data/local/tmp`
各写一份前两个文件的备份，结果是：4 天攒了 4 组目录、从不回收、
`/data/local/tmp` 侧还成了隐形垃圾（系统会定期清，看起来像"删了又出现"）。
而这两个文件本来就没有备份价值 —— 备份垃圾只是生产更多垃圾。

唯一的可恢复路径是「转存」模式：会话目录 `mv` 到
`/data/local/tmp/dsh-trash-<时间戳>/`，保留最近 `KEEP_TMP`（默认 2）次，
更早的自动清掉（`rotate` 函数，带前缀过滤，不会误删 tmp 下其他目录）。

### 实测验证记录（2026-09-20）

从**编译产物**（`javap -v` 提取常量池里的 JS）跑真机 dsh 环境，用副本验证：

```
初始状态    projcache 5 条（1 活 + 4 孤儿）· workspace 1 条活会话
            alive=1  orphans=4  ws_dead=0

精修模式    @@CACHE|5|1        ← 缓存 5 条 → 1 条
            @@ORPHANS|4|…      ← 精准命中交接文档里的 4 条
            副本结果 ["session-aca49a72-…"]   ✓
            WS 死引用 3 条被摘（脏副本测试）   ✓

安全闸      @@ABORT|alive-empty|5
            @@ABORT|alive-empty|ws
            副本仍 5 条 —— 未被误清              ✓

dropcache   副本仍 5 条（该模式下 JS 不动缓存）  ✓
幂等        再跑一次 @@CACHE|1|1  @@ORPHANS|0    ✓
真文件      未被触碰，仍 5 条                     ✓
```

> 注：本机当前 `workspace.json` 本来就只剩 1 条活会话、0 条死引用，
> 所以正常跑显示 `@@WS|0` 是正确结果，不是 bug。

### 编译期的两个坑（本次踩到）

**① `{@code}` 不保护 `*/`，Javadoc 会提前闭合**

```java
// ❌ 第 43 行把注释闭合了，后面整段变成代码 → 报一堆 illegal character
* 因此停机检测必须扫 {@code /proc/*/cmdline} 找 …
// ✅ 去掉星号，或写成 /proc/ 下每个进程的 cmdline
```

`/*` 与 `*/` 在 Javadoc 里**照常生效**，`{@code}` 只影响 HTML 转义。

**② 中文注释需要显式 UTF-8，否则 javac 按 ASCII 解码**

源码里全是中文和全角标点，离线命令行构建时 `LANG` 未设置 → javac 报
`illegal character: '\uff08'`。已在 `app/build.gradle` 钉死：

```gradle
tasks.withType(JavaCompile).configureEach {
    options.encoding = "UTF-8"
}
```

### 三个老坑（仍然有效）

| 坑 | 现象 | 处理 |
|----|------|------|
| force-stop 杀不干净 | 清完记录又回来 | `kill -9` 全部 pid（含 node 宿主）+ 15s 二次确认 |
| 属主变化 | dsh 读不到配置/索引 | `chown -R` 还原原属主 |
| 只删目录不清索引 | UI 显示点不开的空壳 | node 脚本摘引用 + 安全闸防误清 |

---

## 工具 3：短信测压 —— 工作原理

目标：把一个**被多层壳包裹的 Python 样本**（`/data/local/tmp/锻炼/短信测压.py`）
还原成"填个号码就能在手机上跑"的本地工具。

### 一、脱壳链（6 层）

| 层 | 体积 | 变换 |
|----|------|------|
| L0→L1 | 2,256,314 B | `base64.b64decode(s[::-1])` |
| L1→L2 | 1,692,223 B | 同上 |
| L2→L4 | — | `base64.b85decode` → `gzip.decompress`（×3） |
| L4→L5 | 1,614,356 B | 同上 |
| L5→**L6** | 3,435,734 B | **`XOR(SHA256-CTR 密钥流)` → `gzip.decompress`** |

L5 的密钥流：

```python
keystream = sha256(key1(32B) + key2(16B) + ctr.to_bytes(8, 'big')) 反复拼接
key1 = b85decode(b'jWjo~{2pI_VWO*xV${ZId{weE<(nT+>AdBAUjfdV')
```

**踩坑**：CPython 的 `base64.b85decode` 尾部不足 5 字符要用 `~` 补齐，
输出 4 字节后**从最后一组尾部**截掉 padding 个字节；直接少算字节会导致
gunzip 报 `incorrect length check`。

### 二、L6 里的反分析

1. **反调试**：每个函数体内插 `sys.gettrace() is not None → os._exit(...)`，被 pdb 附加即静默退出
2. **字符串表加密**：6546 条字符串走 `b85 → XOR(BIG >> ((i%64)*8) & 0xFF) → b85 → zlib`
3. **垃圾代码**：`if <大数> * (<大数>+1) & 1 == 1:` 死分支（相邻整数之积必为偶数，恒不成立）
4. **标识符随机化**：变量名统一 20~90 字符随机串

### 三、从 L6 到本工程的接口表

L6 是 330 个"发验证码"函数 + 一个主循环：

```python
for i, fn in enumerate(SENDERS, 1):
    print(f'[{i}/330] 发送中...')
    try: fn(手机号); print("✓")
    except: print("✗")
    time.sleep(0.1)
```

把这 330 个函数编译成 `assets/sms_endpoints.tsv`，每行 6 列（TAB 分隔）。
后续又补进了 `滴滴电话.py`（多层壳）解出的 1 条接口 —— **滴滴出行 `codeMT`**（表末行），原始共 **331** 行；
**2026-09-22 清洗掉 14 条跑不出短信的条目，现 317 行**（判据见下方「接口表清洗」）。

> `双次电话呼叫.py` 里的西南证券 / 慧农云两条实测**打不通**，已移除（备份在 `assets/sms_endpoints.tsv.bak2-*`）。

```
序号  方法  URL  头部(0x1f 分隔)  形态  载荷
```

形态 = `json` / `form` / `query` / `none`（对应原 `requests.post(json=)`、
`requests.post(data=)`、`requests.get(params=)`、无载荷）。

### 四、动态值 → 占位符

原样本里靠 Python 运行时算出来的值，静态还原不了，用占位符代替，
由 `SmsEndpoints.expand()` 在发送前展开：

| 原写法 | 占位符 | 工程里的实现 |
|--------|--------|--------------|
| 手机号变量 | `{PHONE}` | 输入框，校验 11 位纯数字 |
| `base64.b64encode(phone.encode())` | `{PHONE_B64}` | `android.util.Base64` |
| `random.choice(4 个 UA)` | `{UA}` | 4 个 UA 随机取一 |
| `str(int(time.time()*1000))` | `{TS_MS}` | `System.currentTimeMillis()` |
| `str(int(time.time()))` | `{TS_S}` | 同上 /1000 |
| `''.join(random.choices("abcdef0123456789", k=n))` | `{RANDHEX:n}` | `Random` 取字符 |
| 大写版 / 带 `-` 版 | `{RANDHEXU:n}` / `{RANDHEXD:n}` | 同上 |
| `uuid.uuid4().hex.upper()` | `{UUID}` | 32 位大写 hex |
| 签名类动态值（2 条） | `{UNKNOWN}` | 展开为空串 |

> 注意：`expand()` 只替换已知 token，JSON 体里的 `{"k":"v"}` 不会被误伤；
> 另有兜底正则清掉残留的 `{?xxx}`。

### 五、成功判定

和原版一致：**只要请求跑完没抛异常就算成功**（等价 curl 退出码 0），
HTTP 状态码单独显示在日志里 —— 原样本本身就是"发出去就完事"，不看返回值。

### 六、停止测压

| 方式 | 入口 |
|------|------|
| 界面按钮 | 本页「停止测压」 |
| 通知栏按钮 | 常驻通知上的「停止」 |
| 硬停 | 划掉任务卡片（服务随之结束） |

停止是**优雅**的：`stopRequested` 置位后，当前这条跑完就跳出循环，
然后写统计、发结束通知、`stopSelf()`。间隔等待被切成 100ms 小片，
所以按停的响应 ≤100ms；被中断的那一条不计入成功/失败。

### 七、界面

- 目标号码（11 位）
- **循环测压次数**：数字输入框 + 快捷按钮 1 / 2 / 3 / 5 / 10 次，上限 999
- 计划提示：`计划：317 条接口，跑 1 轮，共 317 次请求 · 并发 8`
- 接口总数
- 进度 `已完成/总请求数` + 进度条 + `第 n/N 轮 · 当前域名`
- 成功 / 失败 / 未发送 三色统计
- 发送间隔 0.1s / 0.3s / 0.5s / 1.0s
- 运行日志（最近 30 条，✓ 绿 / ✗ 红，多轮时带 `轮2/3` 前缀）

### 八、首发接口（滴滴出行）

每次点「开始测压」，会**先单独打一发滴滴出行**，再进入正常的接口表扫描。

为什么单独拎出来：滴滴 `codeMT` 是实测**唯一稳定可用**的接口，其他大部分接口要么签名失效、
要么风控拦掉。把它放在最前面，保证「按下开始」这一下就有一发有效命中，
不用等整轮扫完才知道有没有打出去。

实现要点：

| 项 | 做法 |
|----|------|
| 数据来源 | `SmsEndpoints.pinned(ctx)` 按 URL 特征从**接口表里查**，不硬编码，改表即改行为 |
| 执行位置 | `SmsStressService.runLoop()` 里，进轮次循环**之前**，串行跑完 |
| 计数 | 并入 `done / okCount / failCount`，`total` 里预留这 1 次 |
| 日志 | 带 `★首发` 标记，和普通条目区分 |
| 开关 | 界面「首发滴滴接口」勾选框，默认开；关掉则 `total` 相应减 1 |

总数公式：

```
total = 接口数 × 循环次数 + (首发开 ? 1 : 0)

例：317 条 × 1 轮 + 首发 1 = 318
    317 条 × 3 轮 + 首发 1 = 952
```

### 九、循环测压次数

「循环 N 次」= 把整张接口表**整体跑 N 遍**，不是重复发同一条。

```
循环 1 次  →  317 次请求，进度 0/317
循环 3 次  →  951 次请求，进度 0/951，每轮之间写一条 "── 第 n/3 轮开始 ──"
```

- 总请求数 `total = 接口数 × 循环次数`，进度条 / 未发送统计都按它算
- 常驻通知标题会显示 `轮 2/3 · 345/951`
- 中途停止时，统计里会写明「中断于第 n 轮」
- 上限 999 轮（`SmsStressService.MAX_LOOPS`），输入非法值自动回落到 1

> 干跑开关已从界面移除，但 `SmsStressService.EXTRA_DRY_RUN` 仍在（默认 false），
> 需要时可用 `adb shell am startservice` 或代码里传 true 来只构造请求不发送。

### 十、为什么慢 & 怎么提速

原版（Python / shell）是**纯串行**：整张表排队一条条发，实测一轮要十几分钟。
原因五条，按影响从大到小：

| # | 原因 | 说明 |
|---|------|------|
| 1 | **串行** | 一次只发一条，整表排队 —— 这是大头 |
| 2 | **313 个不同域名** | 每条都要 DNS 解析 + TCP 建连 + TLS 握手三次往返（约 300~800ms），连接池无法复用 |
| 3 | **超时 8 秒** | 连不上的死接口（约 30~50 条）每条干等 8s，最坏连接+读取各算一次 = 16s |
| 4 | **读整个响应体** | `drain()` 把 body 读干净，慢接口白拖时间 |
| 5 | **跟随 302** | 重定向的接口多走一次往返 |

对应优化（都在 `SmsStressSender` / `SmsStressService` 里）：

| 优化 | 做法 |
|------|------|
| **并发发送** | 固定大小线程池，默认 **8 并发**；本轮所有任务共用一个 `AtomicInteger` 游标，谁空谁取，天然负载均衡 |
| **缩短超时** | 建连 3s / 读取 4s（原 8s/8s），死接口不再拖住整轮 |
| **不读响应体** | 拿到 `getResponseCode()` 直接 `disconnect()`。本工具"发出去就完事"，body 没意义 |
| **不跟随重定向** | `setInstanceFollowRedirects(false)`，302 也照样算这条跑通 |
| **DNS 并行** | 8 个线程各自解析，313 个域名的首次解析被摊开，不再是串行阻塞 |

> 并发顺带把 DNS 解析也并行化了 —— 这是仅次于"串行改并发"的第二大收益。

**并发数怎么选**：

```
1   = 完全复刻原版行为（最稳，也最慢）
4   = 保守，不容易被对端限流
8   = 默认，速度 / 风控平衡点
16  = 快，个别站点可能返回 429 或风控页
32  = 上限，很多站点会直接拒绝
```

界面上的「并发数」输入框就是这个值，运行中不可改；
进度卡实时显示 `运行中 · 已用 01:23 · 4.2 条/秒 · 可随时停止`，方便对比调参。

### 十一、并发实现里的两个坑

1. **`SimpleDateFormat` 不是线程安全的** —— 多个工作线程共用一个实例会串格式，
   甚至抛 `NumberFormatException`。现在每个工作线程各持一个实例。
2. **计数器必须用 `AtomicInteger`** —— `done` / `okCount` / `failCount` 被多线程同时写，
   普通 `int++` 会丢计数。

> 日志 `appendLog()` 是 `synchronized` 的，多线程写不会串。

### 十二、接口表清洗（2026-09-22）

脱壳产物里混着一批**在当前实现下永远发不出短信**的条目 —— 它们照样占一轮的时间、
照样进 `total` 分母，却 100% 计入失败。清洗掉 14 条，另修复 1 条，**331 → 317**。

#### 判据（全部是可复现的静态检查，不靠"实测打不通"这种主观判断）

| # | 判据 | 条数 | 为什么必然失败 |
|---|------|------|----------------|
| 1 | **完全重复**：方法+URL+头部+形态+载荷 五列全同 | 7 | 同一条接口录了两遍，跑一轮白发一次 |
| 2 | **手机号被逐字符拆成表单序号** | 3 | 脱壳时 f-string 没求值，`{PHONE}` 变成 `0=%7B&1=P&2=H&3=O&4=N&5=E&6=%7D`，服务端收到一堆无意义字段 |
| 3 | **手机号字段被解析成 `{UNKNOWN}`** | 1 | `expand()` 把 `{UNKNOWN}` 展开为空串，body 变成 `{"phone":""}` |
| 4 | **body 为空 `{}`** | 2 | 没有任何手机号字段 |
| 5 | **整行不含 `{PHONE}` / `{PHONE_B64}`** | 1 | 只有 templateCode/signName，手机号无处可放 |

> 判据 2/5 覆盖到的条目是同一批：一条"发验证码"接口的 URL、头部、body 里
> **必须**至少有一处 `{PHONE}` 或 `{PHONE_B64}`，否则它在物理上就没有目标号码。

> **保留但存疑的一条**：`iyanan.yanan.gov.cn`（原 159 行）的 `deviceId` 和
> `X-Toon-User-Agent` 里各有一个 `{UNKNOWN}`，展开后为空串。但它的手机号字段是完整的
> （`"mobile":"{PHONE}"`），deviceId 为空未必被服务端拒绝 —— 故**保留**，
> 没有把它算进那 14 条。全表现存 `{UNKNOWN}` 占位符 2 个，都在这一条里。

#### 删除的 14 条（原表行号）

```
9    support.mikecrm.com          body 是 Python 源码片段 `{?"d=" + urlib.parse.quote` 被逐字符拆成表单字段
48   www.hzbzh.com                完全重复（与 24 同）
94   mallapipreview.qibingdaojia  只有 templateCode/signName，无手机号
96   user.daojia.com              完全重复（与 64 同）
99   iot-app.supor.com            完全重复（与 75 同）
111  wappass.baidu.com            完全重复（与 20 同）
140  iot-api.loncinindustries.com {PHONE} 被拆成 0=%7B&1=P&2=H&3=O&4=N&5=E&6=%7D
164  a.wdwlb.com                 完全重复（与 153 同）
171  guahao.wchscu.cn            authKey=&authCode=&phone={PHONE} 被逐字符拆开
250  api.youshiwenwen.com         body = {}
256  health.xuanhuangzaizao.com   body = {}
292  www.liangdawang.com          完全重复（与 124 同）
293  xyl.xinyunla.com            完全重复（与 104 同）
330  home.bojem.com               body 里 phone="{UNKNOWN}" → 展开为空
```

#### 修复的 1 条

```
28  https://ziyue.中国/index/sendcode   →   https://ziyue.xn--fiqs8s/index/sendcode
```

非 ASCII 域名在 `new URL(...)` 阶段就会抛异常，**请求根本构造不出来**。
头部里本来就写着 `Host: ziyue.xn--fiqs8s`（punycode），按它改回 ASCII 即可，
不用删 —— 这条接口本身是好的。

#### 复现清洗结果

```sh
cd app/src/main/assets
awk -F'\t' '{print NF}' sms_endpoints.tsv | sort -u          # 列数应只有 6
awk -F'\t' '{print $1}' sms_endpoints.tsv | tail -1          # 末行序号应等于总行数
awk -F'\t' '{k=$2"|"$3"|"$4"|"$5"|"$6; if(s[k]++) c++} END{print "完全重复:", c+0}' sms_endpoints.tsv
awk -F'\t' '{if ($0 !~ /\{PHONE\}/ && $0 !~ /\{PHONE_B64\}/) c++} END{print "无手机号:", c+0}' sms_endpoints.tsv
# 两条都应输出 0
```

#### 踩坑：别用本机 curl 去"实测哪些接口打不通"

第一版清洗想按"实测可达性"删，结果这个思路在本机行不通，两个坑：

**① 流量全走代理，TCP 探测测的是代理不是接口。** 本机 DNS 返回的是 fake-ip 段：

```sh
ping -c 1 a.wdwlb.com      # → 198.18.0.154    ← Clash/Surge 的 fake-ip，不是真实 IP
ping -c 1 api.wuhanjijin.com  # → 198.18.0.49
```

于是"连不上"只说明**代理节点没连上**，跟接口本身活不活没关系。
同一批域名换一次探测就有 293 条结论翻转 —— 全是被代理和网络抖动带偏的假死。

**② DSH 自带的 curl 没有 CA 证书包**，不加 `-k` 会整片报退出码 77
（`SSL CA cert (path? access rights?)`），看起来像"全部 TLS 失败"，其实是探测环境自己的问题。

**③ 请求根路径会被 WAF 拦**，例如 `https://www.qq.com/` 返回
`501 Method Not Implemented / Server: stgw` —— 但这恰恰证明服务器是活的。
"有没有响应"和"响应是不是 200"是两件事。

结论：可达性探测在**装了代理的手机**上做不出可信结论。要么走不带代理的通道
（另一个 uid / 蜂窝直连），要么就老实做静态判据 —— 后者才是这份表能复现的清理依据。

---

## 避坑清单（编译/运行报错排查）


> **本次踩到的坑（新增工具时最容易中招）**
>
> **Android 的 ICU 正则比 JS 严格**。下面这种写法在 JS / PCRE 里没问题，
> 在 Android 上会在 **类初始化时** 直接抛异常，表现为「点开页面就闪退」：
>
> ```java
> // ❌ 闪退：末尾的 } 不是合法量词，ICU 要求转义
> Pattern.compile("\\{RAND(HEXU|HEXD|HEX)?:(\\d+)}");
> ```
>
> ```
> Caused by: java.util.regex.PatternSyntaxException: Syntax error in regexp pattern near index 29
> \{RAND(HEXU|HEXD|HEX)?:(\d+)}
>     at com.example.seagullkit.SmsEndpoints.<clinit>(SmsEndpoints.java:153)
> ```
>
> 修法：`\}` 转义，或者干脆**不用正则**（`SmsEndpoints` 已改成手写扫描）。
> 同理 `String.replaceAll("\\{\\?[^}]*}")` 也有一样的问题。
>
> 排查手段（本机实测有效）：
>
> ```sh
> su -c "logcat -d -b crash | tail -60"     # FATAL EXCEPTION + Caused by 一目了然
> ```
>
> **导入遮蔽（本次踩到的第二个坑）**
>
> `import android.os.Process;` 会把同名的 `java.lang.Process` **挡住**。
> 于是 `Process p = new ProcessBuilder(...).start();` 里的 `p` 变成了 `android.os.Process`，
> 报一堆莫名其妙的错：
>
> ```
> incompatible types: java.lang.Process cannot be converted to android.os.Process
> cannot find symbol  symbol: method getInputStream()  location: variable p of type android.os.Process
> cannot find symbol  symbol: method waitFor()        location: variable p of type android.os.Process
> ```
>
> 修法二选一：
>
> ```java
> // A. 别 import，用全限定名（本工程采用）
> String uid = String.valueOf(android.os.Process.myUid());
>
> // B. 保留 import，但把 java.lang 那边写全
> java.lang.Process p = new ProcessBuilder(v).start();
> ```
>
> **AlertDialog 的 `setItems` 和 `setMessage` 互斥（第三个坑）**
>
> 同时调用会出现「对话框里只有一个取消按钮」的怪现象：
>
> ```java
> // ❌ 列表根本不显示，只剩「取消」
> new AlertDialog.Builder(this)
>         .setTitle("选择恢复方式")
>         .setMessage(fileName)
>         .setItems(modes, listener)
>         .setNegativeButton("取消", null)
>         .show();
> ```
>
> 原因在 `AlertController.setupContent()`：
>
> ```java
> if (mMessage != null) {
>     mMessageView.setText(mMessage);
> } else {
>     // 只有走到这里才会把 ListView 装进对话框
> }
> ```
>
> 传了 message 就永远进不去 `else`，列表不会安装；而 `setItems` 又**不产生确定按钮**，
> 所以整个对话框只剩负按钮。
>
> 修法：文件名之类放 `setTitle`，别调 `setMessage`。
> 同理互斥的还有 `setView` vs `setItems`、`setView` vs `setMessage`。
>
> 同类陷阱：`android.os.Handler` vs `java.util.logging.Handler`、
> `android.graphics.Color` vs `java.awt.Color`、`android.util.Log` vs 其他 Log。
> 凡是和 `java.lang.*` 同名的 Android 类都要留意。
>
> 另外：`findViewById` 的字段类型必须和布局里的控件标签一致，
> 否则是 `ClassCastException`（同样是点开就闪退）。
>

> **本机两个环境坑（2026-09-23 改 dsh 配置编辑时踩到）**
>
> **① 源文件 mtime 不更新，Gradle 会"看起来没编译"。**
> 编辑工具写盘后，源文件 mtime 有时**停在旧时间**（实测：改完 `DshConfigEditor.java`，
> mtime 仍是前一天的 18:25，而当前已是次日 20:30）。Gradle 据此判定源文件比 class 旧，
> 直接输出 `36 actionable tasks: 36 up-to-date` —— 看着像完全没编。
>
> **别信那行 up-to-date，去查产物**：
>
> ```sh
> C=app/build/intermediates/javac/debug/compileDebugJavaWithJavac/classes/com/example/seagullkit
> strings "$C/DshConfigEditor.class" | grep -E "toDisplayName|DISPLAY_TERMS"
> ```
>
> 有输出就是编进去了（本次就是"显示 up-to-date、实际已编入"）。真需要强制重编：
> `touch` 源文件后再编，或给 gradle 加 `--rerun-tasks`。
>
> **② 这环境的 `grep` 不支持 BRE 的 `\|`。**
> `grep -n 'a\|b' file` **恒无输出且不报错**（看着像"文件里没有"），
> 多模式匹配一律写 `grep -E 'a|b'`。排查时被这条坑过一次，白找半天。
>

1. **Java 语法**：用了 lambda，`compileOptions` 必须是 `JavaVersion.VERSION_17`
2. **版本目录**：依赖写在 `gradle/libs.versions.toml`，用 `libs.xxx` 引用
3. **UTF-8**：`gradle.properties` 必须有 `systemProp.file.encoding=UTF-8`
4. **SDK 版本**：`compileSdk` 不能超过设备上已装的 SDK
5. **资源命名**：小写字母/数字/下划线，`@drawable/xxx` 必须真实存在
6. **Manifest**：带 LAUNCHER 的 Activity 必须显式 `android:exported="true"`
7. **前台服务**：targetSdk 34+ 要 `FOREGROUND_SERVICE_SPECIAL_USE` +
   service 的 `foregroundServiceType`；通知要 API 33+ 动态申请 `POST_NOTIFICATIONS`
8. **时间 API**：minSdk 24 别直接用 `java.time`，用 `SimpleDateFormat` + `Date`
9. **Clean 重试**：改配置后先 Clean Project 再 Build

### 离线编译（本机，免开 IDE）

**前提**：`gradle.properties` 里要有这一行，否则 Gradle 会去 Maven 拉 aapt2
（离线环境下失败）：

```properties
android.aapt2FromMavenOverride=/data/data/com.tom.rv2ide/files/home/.androidide/aapt2
```

```sh
export PATH=/system/bin:/system/xbin
J=/data/data/com.tom.rv2ide/files/usr/lib/jvm/java-17-openjdk
H=/data/data/com.tom.rv2ide/files/home
P=/sdcard/AndroidIDEProjects/SeagullKit
G=$H/.gradle/wrapper/dists/gradle-9.0.0-bin/*/gradle-9.0.0
export JAVA_HOME=$J ANDROID_HOME=$H/android-sdk ANDROID_SDK_ROOT=$H/android-sdk
export GRADLE_USER_HOME=$H/.gradle

cd $P && $J/bin/java -Xmx2048m -classpath "$G/lib/gradle-launcher-9.0.0.jar" \
  org.gradle.launcher.GradleMain --offline assembleDebug --console=plain
```

**为什么不能直接跑 `gradlew`**：wrapper 脚本用 `-Xmx64m` 传参给 `java`，
但 AndroidIDE 的 java 是 NDK 编译的定制二进制，参数解析行为不同，
报 `Could not find or load main class "-Xmx64m"`。用 `java -classpath
gradle-launcher.jar org.gradle.launcher.GradleMain` 直接调用即可。

### 安装（SELinux 限制）

`/sdcard` 是 `fuse` 上下文，system_server 读不到，直接 `pm install` 报
`avc: denied { read } ... tcontext=u:object_r:fuse:s0`。先复制到 `/data/local/tmp`：

```sh
cp $P/app/build/outputs/apk/debug/app-debug.apk /data/local/tmp/app.apk
chmod 644 /data/local/tmp/app.apk
pm install -r -d /data/local/tmp/app.apk
```

### 代理白名单（余额/网络类工具必看）

代理 App 用「分应用代理」时，新装的应用**默认不在白名单**，
流量走蜂窝直连 → 撞 DNS 污染 → 报「连接超时」。

**现象**：`failed to connect to api.b.ai/<污染IP> from /<蜂窝IP>`

**解决**：在代理 App 里把「海鸥工具箱」勾上。

**排查**（需 root）：
```sh
ip rule show | grep uidrange          # 哪些 uid 走了 tun0
stat -c %u /data/data/com.example.seagullkit   # 本 App 的 uid
```

---

## 工具 4：Operit 破甲注入 —— 工作原理

把「无限四代 v0.4.0」内核载荷注入 Operit 的 system 提示词。
完整可移植方法论见 [`docs/破甲注入-可移植操作手册.md`](docs/破甲注入-可移植操作手册.md)。

### 为什么打角色卡，不打 APK

Operit 的 system 消息不是硬编码的，是每次发请求前现场拼的。实测拼装顺序：

```
messages[0].content =
      [槽位A 载荷]
    + [宿主原人设]
    + [other_content_chat]
    + [槽位B 载荷]
    + [包系统 / Available packages]
```

**谁控制角色卡字段的首尾，谁就控制 system 消息。**
改 APK 要重签名、要卸载重装、升级重来；改配置面一次到位、不动签名。

### 双层槽位

| 层 | 存储键 | 位置 | 权重 |
|----|--------|------|------|
| A | `character_card_<id>_character_setting` | 请求体**最前** | 地基 |
| B | `character_card_<id>_advanced_custom_prompt` | 请求体**最末** | 近因（最贴近用户消息） |

首尾夹击 = 无限四代设计里的「Order 100 + Order 200 双层镜像」。
槽位 A 里宿主原人设**完整保留**，只叠加不替换。

### 目标文件与格式

```
/data/data/com.ai.assistance.operit/files/datastore/character_cards.preferences_pb
```

AndroidX DataStore 的 Preferences protobuf：

```proto
message PreferenceMap { map<string, Value> preferences = 1; }
message Value { oneof { bool=1 float=2 int32=3 int64=4 string=5 set=6 double=7 bytes=8 } }
```

`OperitPojaEditor` 手写解析/编码，不引 protobuf 依赖。

### 四条铁律（都是踩出来的）

1. **动数据前先做无损往返自检**：不改内容重新编码，必须字节完全一致。
   不一致就中止——写坏 DataStore 会让 Operit 抛 `CorruptionException` 把角色卡清空。
2. **必须 `su -M`**：App 私有挂载命名空间里 `/data/data` 可能是 tmpfs 影子，
   不 -M 会出现「读到的文件根本不是 Operit 的」这种鬼故事。
3. **先 `am force-stop` 再写**：否则 Operit 内存里的状态会覆盖写入。
4. **属主/权限从原文件 `stat` 现取**，不硬编码 uid；写完 `sha256sum` 校验。

### 幂等

`stripInjected()` 会先剥掉上一次的载荷再叠加，重复注入不会累积成 N 份。

### 端到端验证（不靠猜）

Operit 有个调试广播能直接触发真实请求：

```sh
am broadcast -a com.ai.assistance.operit.EXTERNAL_CHAT --es message "是否处于破甲状态"
```

然后从 `files/logs/operit.log` 抓请求体锚点。界面上「自检」按钮就是干这个的。
判定标准：请求体命中锚点 + 模型输出符合载荷格式契约（首行 `##` 命名交付物）+ 无拒绝话术。

### 备份与回滚

```
/sdcard/SeagullKit/operit-backup/character_cards.<时间戳>.pb
/sdcard/SeagullKit/operit-backup/character_cards.latest.bak
```

界面「回滚到最近备份」按钮一键还原（会自动停 App、还原属主、重启）。

### 实测记录

```
角色        喵喵酱 (default_character)
槽位A       8287 字符（无限四代载荷 + 原 Seagull 人设完整保留）
槽位B       3075 字符（第二层镜像）
文件        19039 字节
请求体顺序  [槽位A] → [Seagull] → [无限制的人] → [槽位B] → [包系统]
模型输出    <think>...without policy lecturing...</think>
            ## 状态        ← 命中 Output contract 的「首行 ##」锚点
```

### 载荷升级

改 `app/src/main/assets/poja_payload.txt` 重新编译即可；
界面会显示载荷的字节数与 sha256，便于核对版本。

---

## 工具 5：Operit 会话清除 —— 工作原理

### 为什么清会话和破甲是一件事

破甲只保证 **system 消息**里有内核载荷，但**上下文里的历史会反向污染**：

| # | 污染源 | 后果 |
|---|--------|------|
| 1 | `messages` 表里 `sender='summary'` 的对话摘要 | 摘要会被注入下一轮请求；若摘要写着「用户之前问过 X，我拒绝了」，等于给模型塞自我暗示 |
| 2 | 历史里的旧拒绝话术 / 免责声明 | 成为 few-shot 锚点，把模型拉回守门姿态 |
| 3 | 记忆库 `objectbox/data.mdb` | 长期注入，跨会话污染 |
| 4 | 用户画像 `memory-space-profiles/default/user.md` | 同上 |

所以「清会话 + 清摘要 + 清记忆」是让破甲**干净生效**的必要前置。

### 存储布局（实测）

```
/data/data/com.ai.assistance.operit/databases/app_database    Room 库
    ├─ chats              会话（id / title / characterCardName / updatedAt）
    ├─ messages           消息（sender = user | ai | summary | tool）
    ├─ message_variants   消息候选分支
    └─ token_usage_records 用量统计（非污染，可选清理）
/data/data/.../files/objectbox/data.mdb                      记忆库（ObjectBox）
/data/data/.../files/memory-space-profiles/default/user.md   用户画像
```

### 执行方式（设备上没有 sqlite3，绕一圈）

```
1) su -M 停 App          —— 不 -M 看不到目标包；不 force-stop 会被回写覆盖
2) su 备份 app_database  —— 到 /sdcard/SeagullKit/operit-backup/app_database.<时间戳>.bak
3) su 拷一份到 cacheDir  —— 属主改成本 App，否则打不开
4) App 用 SQLiteDatabase 打开副本 → DELETE → close（自动 checkpoint WAL）
5) su 拷回 + 还原属主权限 + 删残留 -wal/-shm + 重启 Operit
```

用 Android 自带的 SQLite，不依赖任何外部二进制。

### 关键坑：su 的挂载命名空间（实测数据）

```
su -c "ls /data/data/com.ai.assistance.operit"   → No such file or directory   mnt:[4026537011]
su -M -c "ls /data/data/com.ai.assistance.operit" → 存在                        mnt:[4026534619]
```

App 调 su 默认继承自己的私有挂载命名空间，`/data/data` 被 tmpfs 影子盖住。
**必须 `su -M`（KernelSU --mount-master）**，否则所有路径判断全部失败。
代码里的 su 变体顺序：`su -M` → `su --mount-master` → `su` → `/system/bin/su -M` → `/system/bin/su`。

### 安全性设计

- **会话 id 白名单**：`^[0-9a-fA-F\-]{8,64}$`，非 UUID 直接丢弃（防 SQL 注入）
- **先备份后修改**：每次写入前自动落一份带时间戳的 `.bak`
- **记忆库 / 画像走转存不删**：`mv` 到备份目录，随时可恢复
- **只删子表再删父表**：`message_variants` → `messages` → `chats`，不留孤儿
- **写回后 `PRAGMA integrity_check`** 应为 `ok`

### 实机验证记录（2026-09-18 19:24）

```
清理前  chats: 3 | messages: 73 | 摘要: 1
删除目标会话 3eb97278-8e38-41f6-9772-900dd62ea874
清理后  chats: 2 | messages: 71 | 摘要: 0
        integrity_check = ok | 外键孤儿 = 0
        写回 sha256 一致 | Operit 重启正常（无 FATAL / SQLiteException）
```

### 备份与回滚

```
/sdcard/SeagullKit/operit-backup/app_database.<时间戳>.bak
/sdcard/SeagullKit/operit-backup/app_database.latest.bak
/sdcard/SeagullKit/operit-backup/objectbox.<时间戳>.bak/     # 记忆库转存
/sdcard/SeagullKit/operit-backup/user.md.<时间戳>.bak        # 画像原文
```

界面「回滚数据库」按钮一键还原。


## 下一步
- 工具卡片化：每个新工具 = Activity + 布局 + Manifest 注册 + TOOLS 数组一项
- 可扩展：文件哈希校验、批量重命名、剪贴板历史