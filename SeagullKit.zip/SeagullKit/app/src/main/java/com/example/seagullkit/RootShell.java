package com.example.seagullkit;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

/**
 * 最小的 root 脚本执行器。
 *
 * <p>从原来的 DshCleaner 里抽出来的通用部分 —— DshCleaner 是「会话清除」功能
 * 的宿主（1311 行，绝大部分是会话扫描/投影缓存回写/校验），删掉那个功能后
 * 只剩这一个能力还被 WorkBuddy 账号切换用到，所以单独留一份，不要把
 * 整个会话清除模块拖回来。
 *
 * <p>两个必须踩对的点（沿用 DshCleaner 的实测结论）：
 * <ol>
 *   <li><b>脚本走 stdin 管道</b>，不用 {@code su -c "超长命令"} ——
 *       后者会被多层 shell 转义吃掉引号和变量。</li>
 *   <li><b>优先 {@code su -M}</b>（KernelSU --mount-master），
 *       否则 App 私有挂载命名空间里 /data/data 可能是 tmpfs 影子。</li>
 * </ol>
 */
public final class RootShell {

    private RootShell() {
    }

    /** root 是否可用 */
    public static boolean hasRoot() {
        String out = run("id -u");
        if (out == null) return false;
        for (String line : out.split("\n")) {
            if (line.trim().equals("0")) return true;
        }
        return false;
    }

    /**
     * 以 root 跑一段脚本，返回 stdout（stderr 已合并）。
     *
     * @return 输出；所有 su 变体都启动失败时返回 null
     */
    public static String run(String script) {
        String[][] variants = {
                {"su", "-M"},
                {"su", "--mount-master"},
                {"su"},
                {"/system/bin/su", "-M"},
                {"/system/bin/su"},
        };
        for (String[] v : variants) {
            Process p = null;
            try {
                p = new ProcessBuilder(v).redirectErrorStream(true).start();
                OutputStream os = p.getOutputStream();
                OutputStreamWriter w = new OutputStreamWriter(os, "UTF-8");
                w.write(script);
                w.write("\nexit\n");
                w.flush();
                w.close();

                StringBuilder sb = new StringBuilder();
                BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream(), "UTF-8"));
                String line;
                while ((line = br.readLine()) != null) sb.append(line).append("\n");
                p.waitFor();
                // 拿到输出就算成功（su 变体探测阶段失败的那个会返回空）
                if (sb.length() > 0) return sb.toString();
            } catch (Exception e) {
                if (p != null) try { p.destroy(); } catch (Exception ignored) { }
            }
        }
        return null;
    }
}