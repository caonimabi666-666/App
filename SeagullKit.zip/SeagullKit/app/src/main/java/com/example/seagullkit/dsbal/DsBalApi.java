package com.example.seagullkit.dsbal;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * DeepSeek 余额查询。
 * GET https://api.deepseek.com/user/balance
 * 响应形如 {"is_available":true,"balance_infos":[{"currency":"CNY","total_balance":"17.90",...}]}
 * 这里只依赖 org.json（Android 平台自带），不引第三方 JSON 库。
 */
public final class DsBalApi {

    public static final String ENDPOINT = "https://api.deepseek.com/user/balance";

    /** 查询结果。ok=false 时 message 为可读错误原因。 */
    public static final class Result {
        public final boolean ok;
        public final String total;
        public final String currency;
        public final String granted;
        public final String toppedUp;
        public final boolean available;
        public final String message;

        private Result(boolean ok, String total, String currency, String granted,
                       String toppedUp, boolean available, String message) {
            this.ok = ok;
            this.total = total;
            this.currency = currency;
            this.granted = granted;
            this.toppedUp = toppedUp;
            this.available = available;
            this.message = message;
        }

        static Result ok(String total, String currency, String granted, String toppedUp, boolean available) {
            return new Result(true, total, currency, granted, toppedUp, available, null);
        }

        static Result err(String message) {
            return new Result(false, null, null, null, null, false, message);
        }

        public String symbol() {
            if (currency == null) return "";
            if ("CNY".equalsIgnoreCase(currency)) return "\u00a5";
            if ("USD".equalsIgnoreCase(currency)) return "$";
            return currency + " ";
        }

        public String display() {
            return symbol() + total;
        }
    }

    private DsBalApi() {}

    /** 同步查询，务必在子线程调用。 */
    public static Result fetch(String apiKey) {
        if (apiKey == null || apiKey.trim().isEmpty()) {
            return Result.err("未配置 API Key");
        }
        HttpURLConnection conn = null;
        try {
            URL url = new URL(ENDPOINT);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(12000);
            conn.setReadTimeout(12000);
            conn.setRequestProperty("Authorization", "Bearer " + apiKey.trim());
            conn.setRequestProperty("Accept", "application/json");

            int code = conn.getResponseCode();
            String body;
            if (code >= 200 && code < 300) {
                body = readAll(conn.getInputStream());
            } else {
                InputStream es = conn.getErrorStream();
                String detail = es == null ? "" : readAll(es);
                if (code == 401) return Result.err("Key 无效 (401)");
                if (code == 402) return Result.err("余额不足 (402)");
                if (code == 429) return Result.err("请求过频 (429)");
                return Result.err("HTTP " + code + (detail.isEmpty() ? "" : " " + trim(detail)));
            }

            org.json.JSONObject root = new org.json.JSONObject(body);
            boolean available = root.optBoolean("is_available", true);
            org.json.JSONArray infos = root.optJSONArray("balance_infos");
            if (infos == null || infos.length() == 0) {
                return Result.err("响应无余额字段");
            }
            org.json.JSONObject b = infos.getJSONObject(0);
            return Result.ok(
                    b.optString("total_balance", "?"),
                    b.optString("currency", "CNY"),
                    b.optString("granted_balance", "0"),
                    b.optString("topped_up_balance", "0"),
                    available);
        } catch (java.net.SocketTimeoutException e) {
            return Result.err("请求超时");
        } catch (javax.net.ssl.SSLException e) {
            return Result.err("TLS 失败");
        } catch (Exception e) {
            String m = e.getMessage();
            return Result.err(m == null ? e.getClass().getSimpleName() : trim(m));
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private static String readAll(InputStream in) throws Exception {
        try (InputStream is = in; ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
            byte[] buf = new byte[4096];
            int n;
            while ((n = is.read(buf)) > 0) {
                bos.write(buf, 0, n);
                if (bos.size() > 65536) break;
            }
            return bos.toString(StandardCharsets.UTF_8.name());
        }
    }

    private static String trim(String s) {
        String t = s.replace('\n', ' ').replace('\r', ' ').trim();
        return t.length() > 48 ? t.substring(0, 48) + "\u2026" : t;
    }
}
