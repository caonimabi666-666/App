package com.example.seagullkit;

import android.content.Context;
import android.content.pm.PackageManager;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

/**
 * 本机 dsh 安装目标探测。
 *
 * <p><b>只认 DeepSeek Harness（com.deepseek.harness）。</b>
 *
 * <p>历史上这里是个「多壳探测 + 弹窗选目标」的通用层（DSHA / Harness / 旧壳）。
 * 2026-10 精简：DSHA（com.dsh.client）已经从本机卸载，旧壳（com.dshmobile.shell）
 * 更是早就不在，只留一个目标就不需要选择流程了。
 *
 * <p><b>一个必须踩对的坑</b>：卸载 App 不会删 /data/data/&lt;pkg&gt;，
 * 所以 DSHA 卸载后 {@code /data/data/com.dsh.client/files/linux/ubuntu/root/.dsh}
 * 这个空壳目录还在。老代码按「dsh home 存在就算装了」判定，于是把它当成合法目标，
 * 并且排在探测顺序第一位 —— 结果所有操作都打到那个已死目录上。
 * 现在判据换成人包是否真的装着（PackageManager 查询），目录存在只是次要条件。
 */
public final class DshTargets {

    private DshTargets() {
    }

    /** 唯一的受支持目标 */
    public static final String PKG = "com.deepseek.harness";

    /** 包是否真的装着（卸载后残留的 /data/data 目录不算） */
    public static boolean isInstalled(Context ctx) {
        try {
            ctx.getPackageManager().getPackageInfo(PKG, 0);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    /**
     * 定位 dsh home 绝对路径，找不到返回空串。
     *
     * <p>Harness 的布局：files/payload/dshhome（Termux 式壳）。
     * /data/user/0 与 /data/data 是同一处的两个入口，两个都试。
     */
    public static String locateHome() {
        String[] candidates = {
                "/data/data/" + PKG + "/files/payload/dshhome",
                "/data/user/0/" + PKG + "/files/payload/dshhome",
        };
        StringBuilder sh = new StringBuilder();
        for (String c : candidates) {
            sh.append("[ -d \"").append(c).append("\" ] && { echo \"H=").append(c).append("\"; exit 0; }\n");
        }
        String out = exec(sh.toString());
        if (out == null) return "";
        for (String line : out.split("\n")) {
            String t = line.trim();
            if (t.startsWith("H=")) return t.substring(2).trim();
        }
        return "";
    }

    /** dsh 引擎是否在跑（面板上提示「需重启才生效」） */
    public static boolean isRunning() {
        StringBuilder sh = new StringBuilder();
        sh.append("for d in /proc/[0-9]*; do\n");
        sh.append("  [ -r \"$d/cmdline\" ] || continue\n");
        sh.append("  c=$(tr '\\0' ' ' < \"$d/cmdline\" 2>/dev/null)\n");
        sh.append("  case \"$c\" in *dsh/lib/bin.js*|*usr/local/bin/dsh*) echo RUN=1; exit 0 ;; esac\n");
        sh.append("done\n");
        String out = exec(sh.toString());
        return out != null && out.contains("RUN=1");
    }

    /** 以 root 跑一段 shell，返回 stdout（stderr 合并） */
    public static String exec(String script) {
        return RootShell.run(script);
    }
}