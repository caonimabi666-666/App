# WorkBuddy 自动签到

SeagullKit 新增模块。每日积分自动领取，App 内一键手动签，后台定时自动签。

---

## 一、参考的开源实现

| 仓库 | 说明 |
|---|---|
| [tars1230/workbuddy-checkin](https://github.com/tars1230/workbuddy-checkin) | MIT。零凭据：走桌面端本地服务代理。**本模块按它实现** |
| [L0NE-6/WorkBuddy-Daily](https://github.com/L0NE-6/WorkBuddy-Daily) | 青龙/Actions 版，33 项自动化 |
| [shyss1292-afk/workbuddy-checkin](https://github.com/shyss1292-afk/workbuddy-checkin) | 多账号 + 积分看板 |

原仓库是给桌面端（Python/Bash）用的，本模块是**Android 原生 Java 重写**，
去掉了桌面端依赖，改成直连 + Bearer token。

---

## 二、接口（实测 2026-10-23）

```
POST https://copilot.tencent.com/billing/meter/checkin-activity-status
POST https://copilot.tencent.com/billing/meter/daily-checkin
Header: Authorization: Bearer <accessToken>
Body: {}
```

### 两个必须知道的坑

**坑 1：`checkin-status` 是废弃接口**

```
POST /billing/meter/checkin-status
→ data.active = false, data.today_checked_in = false   ← 恒为 false
```

实测即使已经签到，这个接口依然返回 `today_checked_in: false`。
用它判断会导致**每天重复签到请求**。必须用 `checkin-activity-status`。

**坑 2：HTTP 状态码 ≠ 业务 code**

今天已签到时，`daily-checkin` 返回：

```
HTTP 400
{"code":10001,"msg":"今天已签到，请明天再来","requestId":"..."}
```

**HTTP 400 但这是正常结果。** 按 `r.code != 200` 判断会误报为失败。
代码里改成：先取 body 解析 `code`，`code=10001` 视为成功。

这个坑是实测踩出来的——第一版代码写的是 `if (r.code != 200) return 失败`，
跑验证时发现「已签到」被当成服务器错误。

### 状态响应字段

```json
{
  "code": 0, "msg": "OK",
  "data": {
    "active": true,
    "today_checked_in": false,
    "streak_days": 0,
    "daily_credit": 100,
    "today_credit": 100,
    "total_credits": 100,
    "week_checkin_days": 1,
    "week_progress": [true,false,false,false,false,false,false],
    "theme_name": "Buddy加油站",
    "season": 10,
    "start_time": "2026-09-30 00:00:00",
    "end_time": "2026-11-30 23:59:59"
  }
}
```

签到成功：

```json
{"code": 0, "msg": "OK", "data": {"credit": 100, "streak_days": 1, "is_streak_day": false}}
```

---

## 三、令牌从哪来

### ⚠️ 为什么不能直读 DSH 的凭据文件

DSH 的凭据在：

```
/data/data/com.dsh.client/files/linux/ubuntu/root/.dsh/.workbuddy-auth.json
```

这是 `com.dsh.client`（uid `u0_a293`）的私有目录：

```
drwx------ u0_a293 u0_a293  .../root/.dsh
-rw------- u0_a293 u0_a293  .../.workbuddy-auth.json
```

SeagullKit 是**另一个 uid**，`drwx------` 直接拒绝，改路径没用。
第一版写成 `/root/.dsh/`（容器内视角），App 里必然找不到 —— 这就是
「找不到 DSH 凭据文件」的原因。

### 解决办法：走共享存储

DSH 侧把凭据复制到 `/sdcard/SeagullKit/wb_token.json`，App 从那里读。

已经提供一键脚本 `/sdcard/SeagullKit/sync_wb_token.sh`：

```bash
sh /sdcard/SeagullKit/sync_wb_token.sh
```

或手动一条：

```bash
cp /data/data/com.dsh.client/files/linux/ubuntu/root/.dsh/.workbuddy-auth.json \
   /sdcard/SeagullKit/wb_token.json
```

**权限要求**：`targetSdk 34` 下读 `/sdcard` 需要
`MANAGE_EXTERNAL_STORAGE`（Android 11+，需手动授权）
或 `READ_EXTERNAL_STORAGE`（Android 12 及以下）。
首次点「从 DSH 导入」若没授权，App 会自动跳系统设置。

### 令牌本身

桌面端有「本地服务代理」模式（`CODEBUDDY_SERVICE_PROXY_URL`，零凭据，
由 App 代发请求，免疫令牌加密变更）。

**手机上跑不了桌面 App**，所以走直连 + token：

1. **从 DSH 导入**（推荐）：DSH 的 `dsh-workbuddy-connect` 插件把凭据存在
   `~/.dsh/.workbuddy-auth.json`：

   ```json
   {"credential": {"accessToken": "...", "refreshToken": "...", "expiresAtMs": ...}}
   ```

   App 里点「从 DSH 导入」直接读这个文件，省得手抄 1400+ 字符。

2. **手动粘贴**：`accessToken` 是一串 1400+ 字符的 JWT-like 字符串。

有效期约 **1 个月**（实测 2026-10-23 拿到的 token 到 2026-11-17）。
过期后页面会显示「登录已失效」，需要重新获取。

---

## 四、自动签到怎么跑

两条触发路径，共用同一个幂等执行函数 `WorkBuddyAuto.runOnce()`：

1. **打开 App 就签到**（见第八节）——`SeagullApp` 监听进程回到前台
2. **每天定时**——下面的 AlarmManager

用 **AlarmManager**，不是 WorkManager——项目里没引入 androidx.work，
加依赖要改 gradle，而这个任务「每天几次、到点触发」用闹钟完全够。

| 项 | 值 |
|---|---|
| 时间点 | 08:10 / 12:10 / 20:10 |
| API | `setExactAndAllowWhileIdle`（Android 6+，穿透 Doze） |
| 权限 | `SCHEDULE_EXACT_ALARM` + `USE_EXACT_ALARM` |
| 开机重排 | `WorkBuddyReceiver` 监听 `BOOT_COMPLETED` |
| 精确闹钟被拒 | 自动降级 `set()` 非精确 |

### 幂等

三层保护，不会重复请求：

```
1. 本地记录：今天签过 → 直接 return（不联网）
2. 服务端查询：status().todayCheckedIn == true → return
3. code=10001：兜底，视为成功
```

---

## 五、文件

```
app/src/main/java/com/example/seagullkit/workbuddy/
├── WbApi.java              数据层：状态查询 / 签到 / 本地持久化
├── WorkBuddyActivity.java  界面：状态卡 / 签到按钮 / 开关 / token
├── WorkBuddyAuto.java      调度：AlarmManager 排程 + 执行
└── WorkBuddyReceiver.java  广播：闹钟触发 + 开机重排

app/src/main/res/layout/activity_workbuddy.xml
app/src/main/res/drawable/bg_input.xml
app/src/main/res/drawable/ic_tool_workbuddy.xml
```

改动：
- `AndroidManifest.xml` 注册 `android:name=".SeagullApp"`、Activity、Receiver，
  加精确闹钟权限 + 存储权限（读 /sdcard token）
- `MainActivity.java` 工具箱加一张卡

---

## 六、验证过的内容

| 项 | 结果 |
|---|---|
| `checkin-activity-status` 实调 | ✅ `active=true, today_checked_in=true` |
| `daily-checkin` 首次签到 | ✅ `+100 积分, 连签 1 天` |
| `daily-checkin` 重复签到 | ✅ HTTP 400 + `code=10001`，代码判定为成功 |
| `checkin-status`（废弃接口） | ✅ 确认恒返回 false |
| 无效 token | ✅ HTTP 401 → `tokenExpired=true` |
| Java 括号配平 | ✅ 全项目通过 |
| 类名 / 文件名一致 | ✅ |
| R.id / drawable / color 引用 | ✅ 全部存在 |
| Manifest 登记的类 | ✅ 全部存在 |
| `get-user-resource-summary` | ✅ `TotalCredits=2525.45`，与签到活动的 100 区分开 |
| 403 限流 | ✅ 实测触发，已区分于 401 和「0 积分」 |

**未验证**：实际编译与运行时行为（容器内无 JDK）。
需要在 AndroidIDE 里跑 `sh build_fund.sh`。

---

## 七、积分为什么是 100 而不是全部（2026-10-23 修正）

### 坑 3：两个字段是两个概念

第一版显示「累计积分 100」，用户会以为积分少算了。实际：

| 接口 | 字段 | 实测值 | 含义 |
|---|---|---|---|
| `checkin-activity-status` | `total_credits` | **100** | 本季**签到活动**攒的分 |
| `get-user-resource-summary` | `TotalCredits` | **2525.45** | 账户**真实可用总量** |

`total_credits` 只是签到活动那部分，不是账户总积分。
要显示全部积分必须调 `get-user-resource-summary`。

### 接口

```
POST https://copilot.tencent.com/billing/meter/get-user-resource-summary
Body: {}
```

响应（**数值是字符串，不是 JSON number**）：

```json
{
  "code": 0,
  "data": {
    "TotalCredits": "2525.45",
    "SubscriptionPackageName": "体验版",
    "IsPaidUser": false,
    "CreditGroups": [
      {"Name": "套餐基础积分", "CycleTotalCapacity": "500",  "CycleRemainCapacity": "424.75", "CycleUsedCapacity": "75.25"},
      {"Name": "套餐赠送积分", "CycleTotalCapacity": "0",    "CycleRemainCapacity": "0",      "CycleUsedCapacity": "0"},
      {"Name": "购买积分",     "CycleTotalCapacity": "0",    "CycleRemainCapacity": "0",      "CycleUsedCapacity": "0"},
      {"Name": "平台奖励积分", "CycleTotalCapacity": "2100", "CycleRemainCapacity": "2100",   "CycleUsedCapacity": "0"}
    ]
  }
}
```

### 坑 4：403 是限流，不是 0 积分

连续请求这个接口会返回 **HTTP 403**。

第一版代码把所有非 200 都当失败、`total` 保持 0，
结果页面上会显示「0 积分」——看起来像账户被清空。

现在区分处理：

| 状态 | 处理 |
|---|---|
| 401 | 登录失效 |
| 403 | 「请求太频繁，稍后再试」，**不再当成 0** |
| 其他 | HTTP 错误 |

`status()` 和 `checkin()` 里的 403 也做了同样区分（之前一律当 token 失效）。

---

## 八、打开 App 就自动签到

原来的方案只有 AlarmManager 定时（08:10 / 12:10 / 20:10）。
现在追加：**进程从后台回到前台时也检查一次**。

### 实现

新增 `SeagullApp extends Application`，用
`registerActivityLifecycleCallbacks` 监听 `onActivityResumed`。

```
resumedCount == 1 且本次前台还没试过  →  触发
```

这样只对应「冷启动」或「从后台切回来」，同一进程内来回切 Activity 不会重复触发。

### 时机

`postDelayed 1500ms` 再执行，避开启动瞬间主线程高峰。

### 静默条件（任一命中就跳过，不联网）

- 「自动签到」开关关闭
- 没配 token
- 本地记录今天已签到
- 服务端 `today_checked_in == true`

### 和闹钟的关系

| 触发源 | 时机 |
|---|---|
| `SeagullApp` | 每次打开 App（前台切换） |
| `WorkBuddyAuto` | 每天 08:10 / 12:10 / 20:10 |

两者共用 `WorkBuddyAuto.runOnce()`，幂等逻辑在同一处，
所以打开 App 和闹钟同时命中也不会重复签到。


---

## 九、按钮点了没反应（2026-10-23 修正）

用户反馈：点「立即签到」没有任何反馈。

### 根因：按钮被禁用，点击事件根本不触发

第一版的 render() 里有：

```java
checkinBtn.setEnabled(st.active && !st.todayCheckedIn);
```

今天已经签到过（`today_checked_in = true`）时，按钮 `setEnabled(false)`。
**灰掉的按钮点击不触发任何代码**，连 Toast 都不会有 —— 看起来就是「坏了」。

而且按钮文字仍然是「立即签到」，用户不知道它为什么点不动。

### 修正：按钮状态和文字必须一致

| 状态 | 文字 | 可点 |
|---|---|---|
| 无 token | 未配置令牌 | 否 |
| token 失效 | 令牌失效 | 否 |
| 查询失败（断网等） | 重试签到 | **是** |
| 无进行中活动 | 暂无活动 | 否 |
| 今日已签 | 今日已签到 | 否 |
| 可签到 | 立即签到 | 是 |
| 请求中 | 签到中… | 否 |

### 其他一并修的问题

1. **手动点击不再被本地记录拦断**。原来 `checkedInToday()` 命中就直接 return，
   本地记录可能过期（换设备、清数据），会让人以为按钮坏了。
   `daily-checkin` 本身幂等，签过返回 `code=10001`，不会重复领。

2. **点击后立刻有可见反馈**。先把状态改成「正在签到…」再发请求，
   不用等网络返回（超时 20 秒，期间界面看起来是死的）。

3. **断网不再被误报成「没有活动」**。
   `Status.active` 默认 `false`，网络异常时也是 `false`，
   原来会显示「暂无活动」。现在检查 `raw` 是否以「异常」开头来区分。

4. **Throwable 兜底**。签到线程万一抛的不是 Exception
   （如 `NoClassDefFoundError`），`busy` 会永久卡 true，
   按钮从此点不动。现在 `catch (Throwable)` 保证复位。

### 验证

| 场景 | 结果 |
|---|---|
| 今日已签 + 点签到 | `ok=True already=True` → 「今日已签到（无需重复）」 |
| 无效 token | 401 → 「令牌失效」 |
| 断网 | 「查询失败」+ 可点「重试签到」 |


---

## 十、已知限制

- **token 一个月过期**，需要手动更新。自动刷新需要 `refreshToken`
  调 `/login/refresh-token`，但该接口的参数格式（`clientType`）未实测，暂未实现。
- **没有通知**。签到结果只写日志，不弹通知（避免每天三条打扰）。
- **活动有期限**。当前活动 `2026-09-30 ~ 2026-11-30`，到期后接口返回
  `active=false`，自动签到会跳过并在页面显示「无进行中的活动」。

---

---

## 十一、多账号切换（2026-10-23 新增）

一个账号的额度只有 5 小时，用完了得等 5 小时。这个模块把多个账号存起来一键切换。

### 界面

工具箱 → 「WorkBuddy 账号切换」

```
账号切换                                    [刷新]
当前账号：191****8213

账号池
┌─────────────────────────────────┐
│ 191-新账号          使用中        │
│ 191-新账号.json · 令牌至 11-17    │
│ [使用中]              [删除]      │
└─────────────────────────────────┘
┌─────────────────────────────────┐
│ Piwris-旧号                       │
│ Piwris-旧号.json · 令牌至 11-17   │
│ [切换]                [删除]      │
└─────────────────────────────────┘

[把当前账号存入池子]

怎么用
1. 先在 DSH 里正常登录一个 WorkBuddy 账号
2. 回到这里点「把当前账号存入池子」，给它起个名
3. 换号：在列表里点另一个账号 → 确认切换
4. 切完 DSH 会被强制关闭，自己重新打开就生效
```

### 关键：凭据到底在哪

**血的教训**，记牢：

| 路径 | 谁在用 | 说明 |
|---|---|---|
| `/data/data/com.dsh.client/files/linux/ubuntu/root/.dsh/.workbuddy-auth.json` | **DSH App 插件** | 这才是真的。proot 容器的 root home |
| `/root/.dsh/.workbuddy-auth.json` | Ubuntu 终端 / wb-proxy | 容器内视角的另一份，**改它 DSH 不认** |
| `/sdcard/SeagullKit/wb_accounts/*.json` | 本模块 | 账号池 |

第一版把新 token 写进 `/root/.dsh/`，DSH 纹丝不动、429 报的还是旧账号的限额窗口——
因为它读的是 `files/linux/ubuntu/root/.dsh/` 那份，proot 里的 `/root` 是**另一个 mount namespace**。

### 切换时做什么

```
1. 记下 DST 目录的属主（cp 之后新文件属主是 root，拿它 chown 是错的）
2. cp 池里的 json → DSH 真实路径
3. chown 回 u0_a293:u0_a293 + chmod 600
4. grep accessToken 校验真的写进去了
5. 尝试同步 wb-proxy 那份（/root/.dsh/...）
6. am force-stop com.dsh.client
```

### 坑

**坑 1：改文件必须重启 App**

凭据是插件启动时读进内存的。光 `cp` 不重启，请求还是用旧 token。
`am force-stop` 是唯一可靠的方式（点 home 退出不算）。

**坑 2：wb-proxy 那份同步不上**

`/root/.dsh/` 是 proot 容器内的路径，Android shell 里 `cp` 到那儿会失败
（实测 `cp` 返回错误）。所以切换结果会明确告诉你 `WB_PROXY_SKIP`，
并给出要手动跑的命令。**不做静默失败**——静默失败会让人以为已经同步了。

手动补：
```bash
# 在 Ubuntu 终端（不是 Android shell）
cp '/sdcard/SeagullKit/wb_accounts/你的账号.json' /root/.dsh/.workbuddy-auth.json
# 然后重启 wb-proxy
bash /root/wb-proxy/wb-proxy-ctl.sh restart
```

**坑 3：chown 的对象**

```sh
# ❌ 错的：cp 之后文件属主已经是 root，取它再 chown 等于没改
cp "$SRC" "$DST"
OWNER=$(stat -c '%u:%g' "$DST")
chown "$OWNER" "$DST"

# ✅ 对的：从父目录取
OWNER=$(stat -c '%u:%g' "$(dirname "$DST")")
cp "$SRC" "$DST"
chown "$OWNER" "$DST"
```

DSH 私有目录里文件属主不对，App 读不到，表现是「账号没换」。

### 文件

```
app/src/main/java/com/example/seagullkit/workbuddy/
├── WbAccountSwitcher.java   数据层：账号池读写 / 切号脚本 / root 执行
└── WbAccountActivity.java   界面：列表 / 切换 / 保存 / 删除

app/src/main/java/com/example/seagullkit/
└── FragmentHostActivity.java  通用 Fragment 宿主（工具卡打开 Fragment 用）

app/src/main/res/layout/
├── activity_wb_account.xml  主界面
└── item_wb_account.xml      账号行
```

改动：
- `DshCleaner.java` 新增 `public static String runSuScript(String)` 公开包装
- `WbApi.java` 新增 `tokenFromAccountFile()`，切号时顺手同步签到 token
- `ToolsFragment.java` 的 `Tool` 支持 Fragment 目标（之前只支持 Activity）
- `AndroidManifest.xml` 注册 `FragmentHostActivity`

### 验证过的内容（2026-10-23）

| 项 | 结果 |
|---|---|
| 切到 Piwris 旧号 | ✅ 文件内容与属主 `u0_a293:u0_a293` 都对 |
| 切回 191 新号 | ✅ 同上 |
| 切换后重启 DSH | ✅ 插件读新凭据，额度生效 |
| wb-proxy 同步 | ⚠️ `WB_PROXY_SKIP`，Android shell 写不进容器路径，需手动补 |
| 括号配平 / R 引用 / style 引用 | ✅ 全项目静态检查通过 |

**未验证**：在 AndroidIDE 里实际编译。需要 `sh build_fund.sh`。
