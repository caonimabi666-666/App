package com.example.seagullkit;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;

/**
 * 玻璃质感弹窗构建器 —— 替代系统默认 AlertDialog。
 *
 * <h3>为什么要自己写</h3>
 * 系统 {@code AlertDialog} 的观感问题（用户反馈「太丑」）：
 * <ul>
 *   <li>标题/正文/按钮三段之间没有层级差，全是一个字号一种颜色</li>
 *   <li>圆角小、边距紧，信息挤成一团</li>
 *   <li>按钮是 Material 默认样式，和本工程的玻璃卡片语言完全不搭</li>
 *   <li>长文本直接撑破弹窗，没有滚动</li>
 * </ul>
 *
 * <h3>设计要点（对齐设计规范）</h3>
 * <ol>
 *   <li><b>低透毛玻璃</b> —— 主体近白渐变 + 8% 黑描边 + 28dp 大圆角，
 *       顶部叠一条 40dp 高光带模拟玻璃受光面。不做真模糊：
 *       真模糊会「糊」，且 minSdk 24 无稳定 API。</li>
 *   <li><b>渐变光影</b> —— 卡片/按钮都走 linear gradient（270°/315°），
 *       靠明暗变化造体积，而不是加边框。</li>
 *   <li><b>信息层级</b> —— 语义图标（44dp 玻璃方块）+ 17sp 粗体标题
 *       + 12sp 灰副标题 + 14sp 正文，四级清晰。玻璃只做点缀。</li>
 *   <li><b>克制</b> —— 主按钮在右（拇指热区）、次级在左，同尺寸同圆角，
 *       只靠「填充/描边」区分主次。危险操作用红色渐变。</li>
 * </ol>
 *
 * <h3>用法</h3>
 * <pre>
 * GlassDialog.create(this)
 *     .icon("🗑")
 *     .title("彻底删除 3 个会话")
 *     .subtitle("不可恢复")
 *     .message(body)
 *     .danger()                       // 主按钮转红
 *     .positive("彻底删除", v -&gt; doIt())
 *     .negative("取消", null)
 *     .show();
 * </pre>
 *
 * <h3>实现细节</h3>
 * 用 {@link AlertDialog} 只借它的窗口管理（遮罩、返回键、生命周期），
 * 内容完全替换成 {@code dialog_glass.xml}；再清掉默认背景，
 * 否则 M3 的白色圆角底会在我们的玻璃面板外露出一圈。
 */
public final class GlassDialog {

    // ── 语义图标（一眼判断操作类型）──────────────────────────
    public static final String ICON_INFO = "ℹ";
    public static final String ICON_WARN = "⚠";
    public static final String ICON_DANGER = "🗑";
    public static final String ICON_GEAR = "⚙";
    public static final String ICON_BROOM = "🧹";
    public static final String ICON_SWEEP = "✨";

    private final Context ctx;

    private String icon = ICON_INFO;
    private String title = "";
    private String subtitle;
    private String message = "";
    private String positiveText = "确定";
    private String negativeText = "取消";
    private String neutralText;
    private boolean danger;
    private boolean cancelable = true;

    private View.OnClickListener onPositive;
    private View.OnClickListener onNegative;
    private View.OnClickListener onNeutral;

    /** 自定义主体：非 null 时替换默认的 message 文本区（用于内嵌输入框等） */
    private View customBody;

    /** 危险操作时图标底/主按钮转红 */
    private boolean tintIconDanger;

    private GlassDialog(Context ctx) {
        this.ctx = ctx;
    }

    public static GlassDialog create(Context ctx) {
        return new GlassDialog(ctx);
    }

    // ══════════════════════════════════════════════════════════
    // 链式配置
    // ══════════════════════════════════════════════════════════

    public GlassDialog icon(String emoji) {
        if (emoji != null && !emoji.isEmpty()) this.icon = emoji;
        return this;
    }

    public GlassDialog title(String t) {
        this.title = t == null ? "" : t;
        return this;
    }

    /** 标题下的灰色小字。用于「不可恢复」这类关键约束。 */
    public GlassDialog subtitle(String s) {
        this.subtitle = s;
        return this;
    }

    public GlassDialog message(String m) {
        this.message = m == null ? "" : m;
        return this;
    }

    /**
     * 自定义主体视图，替换默认的 message 文本区。
     * 用于需要内嵌输入框 / 列表的弹窗（例如余额查询配置）。
     * <p>
     * 注意：外层 ScrollView 已经给了 24dp 水平内边距，
     * 传入的 view 不要再加水平 padding，否则会双重缩进。
     */
    public GlassDialog body(View v) {
        this.customBody = v;
        return this;
    }

    /** 危险操作：主按钮用红色渐变，图标底也偏红 */
    public GlassDialog danger() {
        return danger(true);
    }

    /** 条件危险态。用于 `purge ? 危险 : 普通` 这种二选一场景。 */
    public GlassDialog danger(boolean d) {
        this.danger = d;
        this.tintIconDanger = d;
        return this;
    }

    public GlassDialog positive(String text, View.OnClickListener l) {
        if (text != null) this.positiveText = text;
        this.onPositive = l;
        return this;
    }

    public GlassDialog negative(String text, View.OnClickListener l) {
        if (text != null) this.negativeText = text;
        this.onNegative = l;
        return this;
    }

    /** 第三按钮（例如「转存」+「彻底删除」+「取消」三选一）。 */
    public GlassDialog neutral(String text, View.OnClickListener l) {
        this.neutralText = text;
        this.onNeutral = l;
        return this;
    }

    public GlassDialog cancelable(boolean c) {
        this.cancelable = c;
        return this;
    }

    // ══════════════════════════════════════════════════════════
    // 构建 / 显示
    // ══════════════════════════════════════════════════════════

    public AlertDialog build() {
        View root = LayoutInflater.from(ctx).inflate(R.layout.dialog_glass, null);

        TextView tvIcon = root.findViewById(R.id.dlg_icon);
        TextView tvTitle = root.findViewById(R.id.dlg_title);
        TextView tvSub = root.findViewById(R.id.dlg_subtitle);
        TextView tvMsg = root.findViewById(R.id.dlg_message);
        TextView btnPos = root.findViewById(R.id.dlg_btn_positive);
        TextView btnNeg = root.findViewById(R.id.dlg_btn_negative);
        TextView btnNeu = root.findViewById(R.id.dlg_btn_neutral);

        tvIcon.setText(icon);
        tvTitle.setText(title);
        tvMsg.setText(message);

        // 自定义主体：插进 ScrollView 换掉默认文本（保留滚动能力，
        // 输入框多时不会把弹窗撑破屏幕）
        if (customBody != null) {
            ViewGroup scroll = root.findViewById(R.id.dlg_scroll);
            if (scroll instanceof ViewGroup) {
                ((ViewGroup) scroll).removeAllViews();
                ((ViewGroup) scroll).addView(customBody,
                        new ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.WRAP_CONTENT));
            }
        }

        if (subtitle != null && !subtitle.isEmpty()) {
            tvSub.setText(subtitle);
            tvSub.setVisibility(View.VISIBLE);
        } else {
            tvSub.setVisibility(View.GONE);
        }

        // 危险态：图标底染红，和红色主按钮呼应
        if (tintIconDanger) {
            tvIcon.setBackgroundResource(R.drawable.bg_dialog_icon_danger);
        }

        btnPos.setText(positiveText);
        btnPos.setBackgroundResource(danger
                ? R.drawable.btn_dialog_danger
                : R.drawable.btn_dialog_primary);

        btnNeg.setText(negativeText);
        btnNeg.setVisibility(negativeText == null || negativeText.isEmpty()
                ? View.GONE : View.VISIBLE);

        if (neutralText != null && !neutralText.isEmpty()) {
            btnNeu.setText(neutralText);
            btnNeu.setVisibility(View.VISIBLE);
        } else {
            btnNeu.setVisibility(View.GONE);
        }

        AlertDialog dlg = new AlertDialog.Builder(ctx)
                .setView(root)
                .setCancelable(cancelable)
                .create();

        // 按钮点击后关闭（onClick 为 null 表示仅关闭）
        btnPos.setOnClickListener(v -> {
            dismiss(dlg);
            if (onPositive != null) onPositive.onClick(v);
        });
        btnNeg.setOnClickListener(v -> {
            dismiss(dlg);
            if (onNegative != null) onNegative.onClick(v);
        });
        btnNeu.setOnClickListener(v -> {
            dismiss(dlg);
            if (onNeutral != null) onNeutral.onClick(v);
        });

        // 去掉 M3 默认的底，否则会在玻璃面板外露一圈
        Window w = dlg.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            // 遮罩：玻璃面板本身是半透明的，遮罩要够重（60%）
            // 才能让「玻璃浮在暗背景上」的层次成立；
            // 太轻则玻璃和背景光斑混在一起，失去通透感。
            w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            WindowManager.LayoutParams lp = w.getAttributes();
            lp.dimAmount = 0.60f;
            w.setAttributes(lp);
            w.setLayout(calcWidth(), ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        return dlg;
    }

    public void show() {
        build().show();
    }

    /**
     * 弹窗宽度：屏幕宽 - 52dp（两侧各 26dp），上限 400dp。
     * 手机上几乎总是「屏幕宽-52dp」；平板/折叠屏下靠上限避免拉成一条长条。
     */
    private int calcWidth() {
        int screen = ctx.getResources().getDisplayMetrics().widthPixels;
        int dp52 = (int) (52 * ctx.getResources().getDisplayMetrics().density);
        int max = (int) (400 * ctx.getResources().getDisplayMetrics().density);
        return Math.min(screen - dp52, max);
    }

    private static void dismiss(AlertDialog d) {
        try {
            if (d.isShowing()) d.dismiss();
        } catch (Exception ignored) {
        }
    }

    // ══════════════════════════════════════════════════════════
    // 便捷入口：Toast 之外的轻提示
    // ══════════════════════════════════════════════════════════

    /** 只有「知道了」的信息弹窗。 */
    public static void info(Activity a, String title, String message) {
        create(a).icon(ICON_INFO).title(title).message(message)
                .positive("知道了", null).negative(null, null).show();
    }

    /** 危险操作二次确认。确认后执行 onConfirm。 */
    public static void confirmDanger(Activity a, String title, String message,
                                     String confirmText, Runnable onConfirm) {
        create(a).icon(ICON_DANGER).title(title).subtitle("此操作不可恢复")
                .message(message).danger()
                .positive(confirmText, v -> onConfirm.run())
                .negative("取消", null)
                .show();
    }
}