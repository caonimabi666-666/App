package com.example.seagullkit;

import android.content.Context;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.example.seagullkit.tabs.ToolsFragment;

/**
 * 主容器：只剩「工具箱」一页。
 *
 * <p>2026-10 精简后，底部导航整块删掉了 —— 只剩一个页面时，导航栏
 * 是纯装饰，还白占 56dp 高度。现在打开 App 直接就是工具列表。
 *
 * <p>保留 Fragment 容器结构（不直接把 ToolsFragment 塞成 ContentView）：
 * 以后要再加一页时，改回导航栏就行，不用动这层。
 *
 * <p>已删除的页面：
 * <ul>
 *   <li>主页 → 科创板看板（fund 包整组删除）</li>
 *   <li>我的 → WorkBuddy 账号切换 / 签到</li>
 * </ul>
 */
public class MainActivity extends AppCompatActivity {

    private static final String TAG_TOOLS = "tab_tools";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (getSupportFragmentManager().findFragmentByTag(TAG_TOOLS) == null) {
            getSupportFragmentManager().beginTransaction()
                    .add(R.id.fragment_container, new ToolsFragment(), TAG_TOOLS)
                    .commitNow();
        }
    }

    /** 便捷提示（保留原静态方法，别处可能在用） */
    public static void toast(Context ctx, String msg) {
        Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show();
    }
}