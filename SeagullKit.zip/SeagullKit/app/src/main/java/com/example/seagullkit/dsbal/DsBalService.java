package com.example.seagullkit.dsbal;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 悬浮窗前台服务。只显示余额一个数字，尽量不占画面。
 * 轻点刷新，长按看明细，拖动换位置。
 */
public class DsBalService extends Service {

    public static final String ACTION_REFRESH = "com.example.seagullkit.dsbal.REFRESH";
    /** 设置页在前台时收起悬浮窗，避免压在界面内容上。 */
    public static final String ACTION_HIDE = "com.example.seagullkit.dsbal.HIDE";
    public static final String ACTION_SHOW = "com.example.seagullkit.dsbal.SHOW";

    private static final String CHANNEL_ID = "dsbal_overlay";
    private static final int NOTI_ID = 5301;

    /** 同进程存活标记，供设置页判断真实状态。 */
    private static volatile boolean alive = false;

    public static boolean isAlive() { return alive; }

    private WindowManager wm;
    private TextView pill;
    private DsBalPill pillBg;
    private WindowManager.LayoutParams lp;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    private boolean running;
    private boolean dimmed;

    @Override
    public void onCreate() {
        super.onCreate();
        alive = true;
        startForegroundCompat();
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        buildPill();
        running = true;
        schedule(0);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String a = intent == null ? null : intent.getAction();
        if (ACTION_REFRESH.equals(a)) {
            schedule(0);
        } else if (ACTION_HIDE.equals(a)) {
            if (pill != null) pill.setVisibility(View.INVISIBLE);
        } else if (ACTION_SHOW.equals(a)) {
            if (pill != null) pill.setVisibility(View.VISIBLE);
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        running = false;
        alive = false;
        ui.removeCallbacksAndMessages(null);
        io.shutdownNow();
        if (pill != null && wm != null) {
            try { wm.removeView(pill); } catch (Exception ignored) {}
            pill = null;
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    /** 状态栏高度：悬浮窗不许压在时间和电量上。 */
    private int statusBarHeight() {
        int id = getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (id > 0) {
            int h = getResources().getDimensionPixelSize(id);
            if (h > 0) return h;
        }
        return DsBalUi.dp(this, 28);
    }

    // ---------- 通知 ----------

    private void startForegroundCompat() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && nm != null) {
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID, "DeepSeek 余额悬浮窗", NotificationManager.IMPORTANCE_MIN);
            ch.setShowBadge(false);
            nm.createNotificationChannel(ch);
        }
        Intent open = new Intent(this, DsBalActivity.class);
        int piFlags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) piFlags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, piFlags);

        Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        b.setContentTitle("余额悬浮窗运行中")
                .setContentText("轻点通知可调整设置")
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentIntent(pi)
                .setOngoing(true);
        startForeground(NOTI_ID, b.build());
    }

    // ---------- 悬浮窗：只有一个数字 ----------

    private void buildPill() {
        Context c = this;
        final int glow = DsBalUi.dp(c, 7);

        pill = new TextView(c);
        pill.setText("\u2014");
        pill.setTextSize(15);
        pill.setTextColor(DsBalUi.PILL_TXT);
        pill.setGravity(Gravity.CENTER);
        pill.setIncludeFontPadding(false);
        DsBalUi.tabular(pill);
        pill.setPadding(glow + DsBalUi.dp(c, 13), glow + DsBalUi.dp(c, 5),
                glow + DsBalUi.dp(c, 13), glow + DsBalUi.dp(c, 5));
        pillBg = new DsBalPill(c, 16f, 7f);
        pill.setBackground(pillBg);
        // 发光需要软件层
        pill.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        pill.setAlpha(DsBalPrefs.alpha(c));

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        // 发光内缩 7dp：默认位置减掉它，让可见边缘落在 14dp 处
        lp.x = DsBalPrefs.winX(c);
        if (lp.x < 0) lp.x = DsBalUi.dp(c, 14) - DsBalUi.dp(c, 7);
        lp.y = Math.max(DsBalPrefs.winY(c), statusBarHeight() + DsBalUi.dp(c, 6));

        attachTouch();

        try {
            wm.addView(pill, lp);
        } catch (Exception e) {
            Toast.makeText(this, "悬浮窗创建失败：" + e.getMessage(), Toast.LENGTH_LONG).show();
            stopSelf();
        }
    }

    private void attachTouch() {
        final int slop = DsBalUi.dp(this, 6);
        final int longMs = android.view.ViewConfiguration.getLongPressTimeout();
        final Runnable[] holdTask = new Runnable[1];

        pill.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY;
            int startX, startY;
            boolean moved, longFired;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN: {
                        downX = e.getRawX();
                        downY = e.getRawY();
                        startX = lp.x;
                        startY = lp.y;
                        moved = false;
                        longFired = false;
                        // 自己判定长按：本 View 消费了触摸事件，框架的
                        // setOnLongClickListener 不会被触发。
                        holdTask[0] = () -> {
                            if (!moved && !longFired) {
                                longFired = true;
                                showDetail();
                            }
                        };
                        ui.postDelayed(holdTask[0], longMs);
                        return true;
                    }
                    case MotionEvent.ACTION_MOVE: {
                        float dx = e.getRawX() - downX;
                        float dy = e.getRawY() - downY;
                        if (Math.abs(dx) > slop || Math.abs(dy) > slop) {
                            moved = true;
                            if (holdTask[0] != null) ui.removeCallbacks(holdTask[0]);
                        }
                        if (moved) {
                            lp.x = startX + (int) dx;
                            lp.y = Math.max(startY + (int) dy,
                                    statusBarHeight() + DsBalUi.dp(DsBalService.this, 2));
                            try { wm.updateViewLayout(pill, lp); } catch (Exception ignored) {}
                        }
                        return true;
                    }
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL: {
                        if (holdTask[0] != null) ui.removeCallbacks(holdTask[0]);
                        if (moved) {
                            DsBalPrefs.setWinPos(DsBalService.this, lp.x, lp.y);
                        } else if (!longFired && e.getActionMasked() == MotionEvent.ACTION_UP) {
                            schedule(0);   // 轻点 = 立即刷新
                        }
                        return true;
                    }
                    default:
                        return false;
                }
            }
        });
    }

    /** 长按明细：信息保留，但不占悬浮窗面积。 */
    private void showDetail() {
        String d = DsBalPrefs.lastDisplay(this);
        if (d == null) {
            Toast.makeText(this, "还没有数据", Toast.LENGTH_SHORT).show();
            return;
        }
        String[] parts = d.split("\n");
        String amount = parts[0];
        String tail = parts.length > 1 ? parts[1] : "";
        if (!DsBalPrefs.lastOk(this)) {
            Toast.makeText(this, amount, Toast.LENGTH_LONG).show();
            return;
        }
        long ts = DsBalPrefs.lastTs(this);
        String when = ts == 0 ? "" : "  ·  " + android.text.format.DateFormat.format("HH:mm:ss", ts);
        Toast.makeText(this, amount + "\n" + tail + when, Toast.LENGTH_LONG).show();
    }

    // ---------- 轮询 ----------

    private void schedule(int delayMs) {
        if (!running) return;
        ui.removeCallbacks(poll);
        ui.postDelayed(poll, delayMs);
    }

    private final Runnable poll = new Runnable() {
        @Override
        public void run() {
            if (!running) return;
            final String key = DsBalPrefs.apiKey(DsBalService.this);
            setDim(true);
            io.execute(() -> {
                final DsBalApi.Result r = DsBalApi.fetch(key);
                ui.post(() -> {
                    if (!running) return;
                    render(r);
                    schedule(DsBalPrefs.intervalSec(DsBalService.this) * 1000);
                });
            });
        }
    };

    private void setDim(boolean on) {
        if (dimmed == on) return;
        dimmed = on;
        pill.setTextColor(on ? DsBalUi.PILL_TXT_DIM : DsBalUi.PILL_TXT);
    }

    private void render(DsBalApi.Result r) {
        setDim(false);
        if (r.ok) {
            if (pillBg != null) pillBg.setBright(true);
            pill.setText(r.display());
            pill.setTextColor(DsBalUi.PILL_TXT);
            pill.setAlpha(DsBalPrefs.alpha(this));
            DsBalPrefs.setLast(this, r.display() + "\n赠 " + r.granted + "  ·  充 " + r.toppedUp,
                    true, System.currentTimeMillis());
        } else {
            if (pillBg != null) pillBg.setBright(false);
            pill.setText("\u2014");
            pill.setTextColor(DsBalUi.PILL_TXT_ERR);
            DsBalPrefs.setLast(this, r.message, false, System.currentTimeMillis());
        }
    }
}
