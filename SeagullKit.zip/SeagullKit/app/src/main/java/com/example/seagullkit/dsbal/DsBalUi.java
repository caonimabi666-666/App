package com.example.seagullkit.dsbal;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;

/**
 * 设计令牌：赛博紫一套色，全应用统一取用。
 *
 * 规则：
 *  - 底色近黑带紫，不用纯黑（纯黑死板，带紫才有空间感）
 *  - 紫色渐变只上表面与描边，不上文字（数字要一眼读清）
 *  - 青色仅作"信号/在线"语义，不作装饰
 *  - 圆角统一 16dp，胶囊另计
 */
final class DsBalUi {

    private DsBalUi() {}

    // 底色
    static final int BG_TOP    = 0xFF452A3A;
    static final int BG_BOTTOM = 0xFF33202B;
    static final int SURFACE   = 0xFF5E3A52;
    static final int SURFACE_ALT = 0xFF77506A;

    // 文字
    static final int TEXT      = 0xFFFFF8F5;
    static final int TEXT_DIM  = 0xFFE0C4D2;
    static final int TEXT_FAINT = 0xFFB896A8;

    // 紫
    static final int VIOLET_DEEP   = 0xFFD9537D;
    static final int VIOLET        = 0xFFF48FB1;
    static final int VIOLET_SOFT   = 0xFFF8BBD0;
    static final int VIOLET_DIM    = 0xFFA06C88;

    // 信号青（仅在线/成功）
    static final int SIGNAL     = 0xFF8FD4E8;
    static final int DANGER     = 0xFFF2779B;

    static final int OUTLINE    = 0x33F48FB1;   // 20% 紫描边
    static final int ON_ACCENT  = 0xFF452A3A;

    // 悬浮窗自有表面（压在任意画面上，恒定深色）
    static final int PILL_TXT     = 0xFFFFF0F5;
    static final int PILL_TXT_DIM = 0xB3C9BAE8;
    static final int PILL_TXT_ERR = 0xFFFF8FA8;

    static int dp(Context c, float v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
                c.getResources().getDisplayMetrics()));
    }

    /** 兼容旧调用：本应用为深色单一主题。 */
    static boolean dark(Context c) { return true; }

    // 旧接口保留，指向新令牌
    static int bg(Context c)         { return BG_TOP; }
    static int surface(Context c)    { return SURFACE; }
    static int surfaceAlt(Context c) { return SURFACE_ALT; }
    static int text(Context c)       { return TEXT; }
    static int textDim(Context c)    { return TEXT_DIM; }
    static int outline(Context c)    { return OUTLINE; }
    static int accent(Context c)     { return VIOLET; }
    static int onAccent(Context c)   { return ON_ACCENT; }
    static int danger(Context c)     { return DANGER; }

    static GradientDrawable fill(Context c, int color, float radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(c, radiusDp));
        return d;
    }

    static GradientDrawable stroked(Context c, int color, float radiusDp,
                                    int strokeColor, float strokeDp) {
        GradientDrawable d = fill(c, color, radiusDp);
        d.setStroke(dp(c, strokeDp), strokeColor);
        return d;
    }

    /** 斜向紫色渐变表面。 */
    static GradientDrawable grad(Context c, int[] colors, float radiusDp) {
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.TL_BR, colors);
        d.setCornerRadius(dp(c, radiusDp));
        d.setGradientType(GradientDrawable.LINEAR_GRADIENT);
        return d;
    }

    /** 等宽数字：金额跳动时不左右位移，也带仪表读数感。 */
    static void tabular(android.widget.TextView tv) {
        tv.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        tv.getPaint().setFontFeatureSettings("tnum");
    }
}
