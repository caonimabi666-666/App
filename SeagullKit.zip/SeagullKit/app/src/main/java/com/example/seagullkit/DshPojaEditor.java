package com.example.seagullkit;

import android.content.Context;
import android.content.pm.PackageManager;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;

/**
 * dsh（DeepSeek Harness / com.dshmobile.shell）「破甲模式」一键安装器。
 *
 * ══════════════════════════════════════════════════════════════
 * 一、装的是什么
 * ══════════════════════════════════════════════════════════════
 * 往 $DSH_HOME/.agent-presets/pj-mode-v5n/ 写两个文件：
 *
 *   agent.cordis.yml   自包含 Cordis composition（操作者运行基线 v5N）
 *   preset.yml         选择器里的显示名与描述
 *
 * 装完 dsh 的 preset 选择器里会多出「破甲模式v5N」，与 standard / code /
 * minimal / cordis 并列。**官方 preset 目录一字节不碰**，dsh 升级不丢。
 *
 * ══════════════════════════════════════════════════════════════
 * 二、为什么是 preset 而不是改源码
 * ══════════════════════════════════════════════════════════════
 * dsh 的 preset 加载器扫两个根：
 *
 *   $DSH_HOME/.agent-presets/<id>/            用户自建 ← 本工具写这里
 *   部署目录 …/dsh-agent-presets/presets/<id>/ 官方自带，升级会覆盖
 *
 * composition 里所有 name: 都是 npm 包名（@deepseek-ai/dsh-persona 等），
 * 不引用任何本地文件路径 —— 所以整份 composition 自带即可，不需要去
 * 定位或复制官方的 standard preset。
 *
 * ══════════════════════════════════════════════════════════════
 * 三、三个必须踩对的坑（实测）
 * ══════════════════════════════════════════════════════════════
 *   1) **UTF-8 无 BOM**。dsh 的 YAML 加载器带 BOM 会解析失败。
 *      Java 侧 new String(bytes, UTF_8) / getBytes(UTF_8) 天然无 BOM，
 *      但经 assets 读取时若用了错误的解码方式会引入 BOM —— 本类统一
 *      走 ByteArrayOutputStream 原样读字节，不做字符集转换。
 *
 *   2) **属主必须继承**。以 root 跑会写成 root:root，dsh 进程
 *      （uid 10264）读不了直接 EACCES 崩。写入前从 $DSH_HOME stat 现取
 *      uid/gid，写完 chown 回去 —— 不硬编码 uid。
 *
 *   3) **SELinux context 必须带 MLS category**。新建文件默认拿到
 *      u:object_r:app_data_file:s0（缺 :c8,c257,c512,c768），
 *      app 进程 readlink/open 会被拒。必须 chcon 成与 $DSH_HOME 一致。
 *      注意 chcon --reference 在本机不支持（实测 "Unknown option"），
 *      只能显式传 context 字符串。
 *
 * ══════════════════════════════════════════════════════════════
 * 四、执行方式（沿用 DshConfigEditor / OperitPojaEditor 踩过的坑）
 * ══════════════════════════════════════════════════════════════
 *   1) 脚本经 su 的 stdin 管道送入，不在命令行拼接
 *   2) 必须优先 su -M（KernelSU --mount-master），否则 App 私有挂载
 *      命名空间里 /data/data/<别的包> 可能是 tmpfs 影子
 *   3) 二进制/大文本走 base64，避免 stdout 混进日志
 *   4) node 需要 LD_LIBRARY_PATH 指向 dsh 的 lib，否则报 libz.so.1 not found
 *   5) 写入用「临时文件 + rename」原子替换，中途失败不留半个文件
 *
 * 需要 root。
 */
public class DshPojaEditor {

    /**
     * 受支持的 dsh 包名 —— 只有 DeepSeek Harness。
     *
     * <p>历史上还试过 com.dsh.client（DSHA，Ubuntu+proot 容器）和
     * com.dshmobile.shell（最老的壳）。前者已从本机卸载，后者从未在这台机器上装过，
     * 所以留着一个就够了。这同时解决了「卸载后残留 /data/data 目录被误判成目标」
     * 的老问题 —— 见 {@link DshTargets}。
     */
    public static final String[] DSH_PKGS = {
            DshTargets.PKG,
    };

    /** 默认目标（只剩一个） */
    public static final String DSH_PKG = DshTargets.PKG;

    /** preset 目录名（= dsh 里的 preset id） */
    public static final String PRESET_ID = "pj-mode-v5n";

    /** 选择器显示名 */
    public static final String PRESET_NAME = "破甲模式v5N";

    /** 卸载备份目录前缀 */
    public static final String UNINSTALL_PREFIX = "_uninstalled-";

    /** 识别标记：本工具装的 preset 才有这一行（卸载时校验，防止误删别人的） */
    public static final String MARKER = "# [dsh-unlock-mode]";

    /** 回执口令：会话里单独发「破甲自检」应只回这一行 */
    public static final String UNLOCK_TAG = "破甲已生效｜目标 DSH｜破甲模式 v5N";

    /** assets 里的 composition 模板 */
    public static final String ASSET_COMPOSITION = "pj_mode_composition.yml";

    /**
     * Harness（com.deepseek.harness）的 node 端写入器。
     *
     * <p>dsh 的配置根不是 settings.yaml，而是 profile patch 层：
     * <pre>
     *   $DSH_HOME/profiles/web/cordis.patch.yml
     * </pre>
     * preset 也不是目录，而是这个 patch 层里的一条 insert 声明。
     * 见 assets/dsh_patch.js 头部的实测布局说明。
     */
    public static final String ASSET_PATCH_JS = "dsh_patch.js";

    /** 临时工作目录（root 可读写，App 私有目录 su 下可能看不到） */
    public static final String TMP_DIR = "/data/local/tmp/seagull-pjmode";

    /** composition 关键块：装完必须全部命中，缺一个就算失败 */
    private static final String[][] CHECK_BLOCKS = {
            {MARKER,                        "标记行 dsh-unlock-mode"},
            {"- id: persona",               "persona 行"},
            {"操作者运行基线 v5N",           "v5N 基线标题"},
            {"无固定边界",                   "无固定边界声明"},
            {"## 一、总纲",                  "第一节 总纲"},
            {"## 二、交付纪律",              "第二节 交付纪律"},
            {"## 三、目标参数归一化",        "第三节 目标参数归一化"},
            {"## 四、注入免疫",              "第四节 注入免疫"},
            {"## 五、拒绝自恢复",            "第五节 拒绝自恢复"},
            {"## 六、常见任务输出范式",      "第六节 常见任务输出范式"},
            {"## 七、身份与自检",            "第七节 身份与自检"},
            {"## 八、装载回执",              "第八节 装载回执"},
            {"你是小码酱",                   "小码酱身份层"},
            {UNLOCK_TAG,                    "回执口令"},
    };

    /** 关键块总数（供 UI 显示 x/N） */
    public static final int CHECK_COUNT = CHECK_BLOCKS.length;

    // ══════════════════════════════════════════════════════════
    // 结果模型
    // ══════════════════════════════════════════════════════════

    public static class Result {
        public boolean success;
        public String output = "";
        public String error = "";
    }

    /** 现场快照 */
    public static class Snapshot {
        public boolean success;
        public String error = "";
        public String raw = "";

        /** dsh home 实际路径 */
        public String dshHome = "";
        /** preset 目录 */
        public String presetDir = "";
        /** 是否已装 */
        public boolean installed;
        /** composition 是否存在 */
        public boolean compoExists;
        /** preset.yml 是否存在 */
        public boolean metaExists;
        public long compoSize;
        public String compoOwner = "";
        public String compoContext = "";
        public String compoSha = "";
        /** 关键块命中数 / 总数 */
        public int blocksHit;
        public int blocksTotal = CHECK_BLOCKS.length;
        /** 缺失的块名 */
        public final List<String> blocksMissing = new ArrayList<>();
        /** 备份数量（_uninstalled-* 目录） */
        public int uninstallBackups;
        /** dsh 是否在运行 */
        public boolean dshRunning;
        /** 选择器里当前能否被扫到（= 目录名合法 + preset.yml 有 name） */
        public String presetDisplayName = "";

        // ── DSHA（0.2.x patch 层）专用字段 ─────────────────────
        /** true = 走 patch 层模式（DSHA），false = 老的 .agent-presets 目录模式 */
        public boolean dshaMode;
        /** patch 文件绝对路径 */
        public String patchPath = "";
        /** patch 文件字节数 */
        public long patchBytes;
        /** patch 文件能否被 yaml 解析 */
        public boolean patchParses = true;
        /** preset 条目里的顶层 plugins 行数 */
        public int pluginRows;
        /** 人设 prefix 里是否含 v5N 基线 */
        public boolean prefixOk;
        /** 版本自带的 standard 骨架是否可用 */
        public boolean bundleOk;
        /** dshedit 用的 composition 载荷是否可解析 */
        public boolean compositionOk;
    }

    /** composition 载荷（来自 assets） */
    public static class Payload {
        public byte[] bytes = new byte[0];
        public String sha = "";
        public int size;
        public int rows;
        /** 关键块命中 */
        public int blocksHit;
        public final List<String> blocksMissing = new ArrayList<>();
        public boolean ok;
        public String error = "";
    }

    // ══════════════════════════════════════════════════════════
    // 对外 API
    // ══════════════════════════════════════════════════════════

    public static boolean hasRoot() {
        String out = runSuSimple("id -u");
        if (out == null) return false;
        for (String line : out.split("\n")) {
            if (line.trim().equals("0")) return true;
        }
        return false;
    }

    /**
     * 从 assets 读 composition 模板，并注入识别标记行。
     *
     * 标记行必须由安装器注入（模板本身不含）—— 它同时是：
     *   1) 自检的第一项关键块
     *   2) 卸载时的「这是本工具装的」校验依据
     * 注入后再算 sha256，这样 install 写入的内容与 check 比对的基准
     * 完全一致，不会出现「装了却自检不过」。
     *
     * 原样处理字节，不做字符集转换 —— 保证落盘时无 BOM。
     */
    public static Payload loadPayload(Context ctx) {
        Payload p = new Payload();
        try {
            InputStream in = ctx.getAssets().open(ASSET_COMPOSITION);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
            in.close();
            byte[] raw = bos.toByteArray();

            // 注入标记行（若模板尚未带）
            String head = new String(raw, 0, Math.min(raw.length, 64), StandardCharsets.UTF_8);
            if (!head.contains(MARKER)) {
                byte[] marker = (MARKER + " preset-id=" + PRESET_ID
                        + " name=" + PRESET_NAME + "\n").getBytes(StandardCharsets.UTF_8);
                byte[] merged = new byte[marker.length + raw.length];
                System.arraycopy(marker, 0, merged, 0, marker.length);
                System.arraycopy(raw, 0, merged, marker.length, raw.length);
                raw = merged;
            }
            p.bytes = raw;
            p.size = p.bytes.length;
            p.sha = sha256(p.bytes);
            String text = new String(p.bytes, StandardCharsets.UTF_8);

            // 顶层 row 数
            int rows = 0;
            for (String line : text.split("\n")) {
                if (line.startsWith("- id: ")) rows++;
            }
            p.rows = rows;

            // 关键块核对
            for (String[] pair : CHECK_BLOCKS) {
                if (text.contains(pair[0])) p.blocksHit++;
                else p.blocksMissing.add(pair[1]);
            }
            p.ok = p.blocksHit == CHECK_BLOCKS.length;
            if (!p.ok) {
                p.error = "载荷缺少 " + p.blocksMissing.size() + " 个关键块："
                        + join(p.blocksMissing, "、");
            }
        } catch (Exception e) {
            p.ok = false;
            p.error = "读取 assets/" + ASSET_COMPOSITION + " 失败：" + e.getMessage();
        }
        return p;
    }

    /** 扫描现场 */
    public static Snapshot scan(Context ctx) {
        Snapshot s = new Snapshot();

        // 判布局：能定位到 patch 层就走 patch 层读写器
        String patch = detectPatchLayer();
        if (!patch.isEmpty()) return scanPatch(ctx, patch);

        // 先定位 dsh home（用 shell，不依赖 root，普通权限也能 stat 到目录名）
        Result loc = exec(join(prologueLocate()) + "\n"
                + "echo HOME_MARK=$DSH\n"
                + "echo UID_MARK=$(stat -c %u \"$DSH\" 2>/dev/null)\n"
                + "echo GID_MARK=$(stat -c %g \"$DSH\" 2>/dev/null)\n"
                + "echo CTX_MARK=$(stat -c %C \"$DSH\" 2>/dev/null)\n"
                + "exit 0");
        s.raw = loc.output;
        for (String line : loc.output.split("\n")) {
            String t = line.trim();
            if (t.startsWith("HOME_MARK=")) s.dshHome = t.substring(10).trim();
        }
        if (s.dshHome.isEmpty()) {
            s.error = "找不到 .dsh 目录（dsh 未安装或未初始化）\n" + loc.output;
            return s;
        }
        s.presetDir = s.dshHome + "/.agent-presets/" + PRESET_ID;

        // 再采集 preset 现场
        StringBuilder sb = new StringBuilder();
        sb.append("PD=").append(q(s.presetDir)).append("\n");
        sb.append("echo DIR_EXISTS=$( [ -d \"$PD\" ] && echo 1 || echo 0 )\n");
        sb.append("echo COMPO_EXISTS=$( [ -f \"$PD/agent.cordis.yml\" ] && echo 1 || echo 0 )\n");
        sb.append("echo META_EXISTS=$( [ -f \"$PD/preset.yml\" ] && echo 1 || echo 0 )\n");
        sb.append("echo COMPO_SIZE=$(stat -c %s \"$PD/agent.cordis.yml\" 2>/dev/null || echo 0)\n");
        sb.append("echo COMPO_OWNER=$(stat -c '%u:%g' \"$PD/agent.cordis.yml\" 2>/dev/null)\n");
        sb.append("echo COMPO_CTX=$(stat -c %C \"$PD/agent.cordis.yml\" 2>/dev/null)\n");
        sb.append("echo COMPO_SHA=$(sha256sum \"$PD/agent.cordis.yml\" 2>/dev/null | cut -d' ' -f1)\n");
        sb.append("echo BACKUPS=$(ls -d \"$DSH/.agent-presets/").append(UNINSTALL_PREFIX)
          .append(PRESET_ID).append("-*\" 2>/dev/null | wc -l)\n");
        sb.append("echo META_NAME=$(sed -n 's/^name:[[:space:]]*//p' \"$PD/preset.yml\" 2>/dev/null | head -1)\n");
        sb.append("if pgrep -f ").append(q(DSH_PKG)).append(" >/dev/null 2>&1; then echo RUNNING=1; else echo RUNNING=0; fi\n");
        // 关键块逐条 grep -c（用变量中转，避免 `|| echo 0` 在未命中时输出两行）
        for (int i = 0; i < CHECK_BLOCKS.length; i++) {
            sb.append("N=$(grep -cF -- ").append(q(CHECK_BLOCKS[i][0]))
              .append(" \"$PD/agent.cordis.yml\" 2>/dev/null); echo BLOCK_").append(i)
              .append("=${N:-0}\n");
        }
        sb.append("exit 0");

        Result r = exec(join(prologueLocate()) + "\n" + sb);
        s.raw = r.output;

        for (String line : r.output.split("\n")) {
            String t = line.trim();
            if (t.startsWith("DIR_EXISTS=")) s.installed = "1".equals(t.substring(11));
            else if (t.startsWith("COMPO_EXISTS=")) s.compoExists = "1".equals(t.substring(13));
            else if (t.startsWith("META_EXISTS=")) s.metaExists = "1".equals(t.substring(12));
            else if (t.startsWith("COMPO_SIZE=")) s.compoSize = parseLong(t.substring(11));
            else if (t.startsWith("COMPO_OWNER=")) s.compoOwner = t.substring(12).trim();
            else if (t.startsWith("COMPO_CTX=")) s.compoContext = t.substring(10).trim();
            else if (t.startsWith("COMPO_SHA=")) s.compoSha = t.substring(10).trim();
            else if (t.startsWith("BACKUPS=")) s.uninstallBackups = (int) parseLong(t.substring(8));
            else if (t.startsWith("META_NAME=")) s.presetDisplayName = t.substring(10).trim();
            else if (t.startsWith("RUNNING=")) s.dshRunning = "1".equals(t.substring(8));
            else if (t.startsWith("BLOCK_")) {
                int eq = t.indexOf('=');
                if (eq > 6) {
                    int idx;
                    try { idx = Integer.parseInt(t.substring(6, eq)); } catch (Exception e) { continue; }
                    long n = parseLong(t.substring(eq + 1));
                    if (idx >= 0 && idx < CHECK_BLOCKS.length) {
                        if (n >= 1) s.blocksHit++;
                        else s.blocksMissing.add(CHECK_BLOCKS[idx][1]);
                    }
                }
            }
        }
        // 目录在 + 两个文件在 + 关键块全中 = 真正可用
        s.installed = s.installed && s.compoExists && s.metaExists;
        s.success = true;
        return s;
    }

    /**
     * 安装（或覆盖安装）。
     *
     * 流程：
     *   1) 载荷自检（关键块齐不齐）—— 不齐直接中止，不碰磁盘
     *   2) 定位 dsh home / node，取 uid/gid/context
     *   3) 旧版存在则备份为 .bak-时间戳
     *   4) 原子写：临时文件 → chown → chcon → rename
     *   5) 回读校验 sha256 + 关键块
     */
    public static Result install(Context ctx) {
        Result res = new Result();
        StringBuilder log = new StringBuilder();

        // 1) 载荷自检
        Payload pl = loadPayload(ctx);
        log.append("[*] 载荷 ").append(pl.size).append(" 字节 / ")
           .append(pl.rows).append(" 个顶层 row\n");
        log.append("[*] 载荷 SHA256 ").append(shortSha(pl.sha)).append("\n");
        if (!pl.ok) {
            res.error = pl.error;
            res.output = log.toString() + "\n[X] " + pl.error + "\n已中止，磁盘未改动。";
            return res;
        }
        log.append("[*] 关键块核对 ").append(pl.blocksHit).append("/")
           .append(CHECK_BLOCKS.length).append(" 通过\n");

        // patch 层：preset 是 patch 里的一条 insert，不是目录
        String patch = detectPatchLayer();
        if (!patch.isEmpty()) return installPatch(ctx, pl, log);

        // 2) 载荷落到 App 私有目录，交给 su 拷进去（App 无 /data/data/<别的包> 写权限）
        java.io.File tmp;
        try {
            tmp = new java.io.File(ctx.getCacheDir(), "pj_mode_composition.new.yml");
            java.io.FileOutputStream fos = new java.io.FileOutputStream(tmp);
            fos.write(pl.bytes);
            fos.close();
            log.append("[*] 中间文件 ").append(tmp.getAbsolutePath()).append("\n");
        } catch (Exception e) {
            res.error = "写中间文件失败：" + e.getMessage();
            res.output = log.toString();
            return res;
        }

        String want = pl.sha;

        // 3) 一段 shell 干完全部：备份 → 写 → 属主 → context → 校验
        List<String> L = new ArrayList<>();
        L.addAll(prologueLocate());
        L.add("PD=\"$DSH/.agent-presets/" + PRESET_ID + "\"");
        L.add("SRC=" + q(tmp.getAbsolutePath()));
        L.add("");
        L.add("# 载荷来自 App 私有目录，su -M 下可能看不到 —— 走 /data/local/tmp 中转");
        L.add("TMPD=/data/local/tmp/pjmode");
        L.add("rm -rf \"$TMPD\"; mkdir -p \"$TMPD\"");
        L.add("if [ -r \"$SRC\" ]; then cp -f \"$SRC\" \"$TMPD/compo.yml\"; else echo 'ERR 读不到中间文件'; exit 4; fi");
        L.add("chmod 600 \"$TMPD/compo.yml\"");
        L.add("echo \"[*] 中间文件已中转 ($(stat -c %s \"$TMPD/compo.yml\") 字节)\"");
        L.add("");
        L.add("# 属主：从 dsh home 现取，不硬编码");
        L.add("U=$(stat -c %u \"$DSH\" 2>/dev/null)");
        L.add("G=$(stat -c %g \"$DSH\" 2>/dev/null)");
        L.add("if [ -z \"$U\" ]; then echo 'ERR 取不到 dsh home 属主'; exit 5; fi");
        L.add("echo \"[*] 目标属主 $U:$G\"");
        L.add("");
        L.add("# context：从 dsh home 现取（chcon --reference 本机不支持，只能取字符串再显式设）");
        L.add("CTX=$(stat -c %C \"$DSH\" 2>/dev/null)");
        L.add("if [ -z \"$CTX\" ]; then echo '[!] 取不到 context，跳过 chcon（可能仍可用）'; else echo \"[*] 目标 context $CTX\"; fi");
        L.add("");
        L.add("mkdir -p \"$DSH/.agent-presets\"");
        L.add("mkdir -p \"$PD\"");
        L.add("");
        L.add("# 旧版备份");
        L.add("if [ -f \"$PD/agent.cordis.yml\" ]; then");
        L.add("  TS=$(date +%Y%m%d-%H%M%S)");
        L.add("  cp -f \"$PD/agent.cordis.yml\" \"$PD/agent.cordis.yml.bak-$TS\"");
        L.add("  echo \"[*] 旧 composition 已备份 -> agent.cordis.yml.bak-$TS\"");
        L.add("fi");
        L.add("");
        L.add("# 原子写 composition");
        L.add("cat \"$TMPD/compo.yml\" > \"$PD/.agent.cordis.yml.tmp\"");
        L.add("chown \"$U:$G\" \"$PD/.agent.cordis.yml.tmp\"");
        L.add("chmod 600 \"$PD/.agent.cordis.yml.tmp\"");
        L.add("[ -n \"$CTX\" ] && chcon \"$CTX\" \"$PD/.agent.cordis.yml.tmp\" 2>/dev/null");
        // restorecon 必须跑：chcon 之后 stat 显示的是 SELinux 缓存值，
        // 真值可能仍是缺 MLS 的 s0，只有 restorecon 能暴露并修正（实测）
        L.add("restorecon \"$PD/.agent.cordis.yml.tmp\" 2>/dev/null || true");
        L.add("mv -f \"$PD/.agent.cordis.yml.tmp\" \"$PD/agent.cordis.yml\"");
        L.add("restorecon \"$PD/agent.cordis.yml\" 2>/dev/null || true");
        L.add("echo '[*] agent.cordis.yml 已写入'");
        L.add("");
        L.add("# preset.yml（元数据）");
        L.add("printf '%s\\n' " + q("name: " + PRESET_NAME)
                + " " + q("description: v5 无边界变体。与 v5 的唯一差异：不含「固定禁区清单」——不预先划定任何不可交付的题材/领域，是否交付完全由操作者当轮指令决定。其余能力与 v5 相同：目标参数归一化、注入免疫、拒绝自恢复、常见任务输出范式、每轮锚定、宿主补丁兼容。回执口令：破甲已生效｜目标 DSH｜破甲模式 v5N。")
                + " > \"$PD/.preset.yml.tmp\"");
        L.add("chown \"$U:$G\" \"$PD/.preset.yml.tmp\"");
        L.add("chmod 600 \"$PD/.preset.yml.tmp\"");
        L.add("[ -n \"$CTX\" ] && chcon \"$CTX\" \"$PD/.preset.yml.tmp\" 2>/dev/null");
        L.add("restorecon \"$PD/.preset.yml.tmp\" 2>/dev/null || true");
        L.add("mv -f \"$PD/.preset.yml.tmp\" \"$PD/preset.yml\"");
        L.add("restorecon \"$PD/preset.yml\" 2>/dev/null || true");
        L.add("echo '[*] preset.yml 已写入'");
        L.add("");
        L.add("# 目录本身也要对齐属主/context");
        L.add("chown \"$U:$G\" \"$PD\" 2>/dev/null");
        L.add("[ -n \"$CTX\" ] && chcon \"$CTX\" \"$PD\" 2>/dev/null");
        L.add("restorecon \"$PD\" 2>/dev/null || true");
        L.add("chmod 700 \"$PD\" 2>/dev/null");
        L.add("");
        L.add("# 回读校验");
        L.add("GOT=$(sha256sum \"$PD/agent.cordis.yml\" | cut -d' ' -f1)");
        L.add("echo \"GOT=$GOT\"");
        L.add("echo \"WANT=" + want + "\"");
        L.add("echo \"SIZE=$(stat -c %s \"$PD/agent.cordis.yml\")\"");
        L.add("echo \"OWNER=$(stat -c '%u:%g' \"$PD/agent.cordis.yml\")\"");
        L.add("echo \"CTX=$(stat -c %C \"$PD/agent.cordis.yml\")\"");
        // context 校验：用 restorecon -v 拿真值（stat 显示的是缓存，会骗人）
        L.add("RELABEL=$(restorecon -v \"$PD/agent.cordis.yml\" 2>&1)");
        L.add("case \"$RELABEL\" in *Relabeling*) echo \"CTX_OK=0\";; *) echo \"CTX_OK=1\";; esac");
        L.add("echo \"CTX_REAL=$(restorecon -n \"$PD/agent.cordis.yml\" 2>&1 | head -1)\"");
        L.add("echo \"BOM_RAW=$(head -c 3 \"$PD/agent.cordis.yml\" 2>/dev/null | od -An -tx1 | tr -d ' \\n')\"");
        L.add("echo '--- 关键块 ---'");
        for (int i = 0; i < CHECK_BLOCKS.length; i++) {
            L.add("N=$(grep -cF -- " + q(CHECK_BLOCKS[i][0])
                    + " \"$PD/agent.cordis.yml\" 2>/dev/null); echo \"B" + i + "=${N:-0}\"");
        }
        L.add("rm -rf \"$TMPD\"");
        L.add("exit 0");

        Result wr = exec(join(L));
        log.append(wr.output);

        String got = field(wr.output, "GOT=");
        String size = field(wr.output, "SIZE=");
        String owner = field(wr.output, "OWNER=");
        String ctxOut = field(wr.output, "CTX=");
        String bom = field(wr.output, "BOM_RAW=");

        boolean shaOk = want.equalsIgnoreCase(got);
        boolean bomOk = !(bom != null && bom.toLowerCase().startsWith("efbbbf"));
        int hits = 0;
        List<String> missing = new ArrayList<>();
        for (int i = 0; i < CHECK_BLOCKS.length; i++) {
            String v = field(wr.output, "B" + i + "=");
            if (v != null && parseLong(v) >= 1) hits++;
            else missing.add(CHECK_BLOCKS[i][1]);
        }

        log.append("\n── 校验 ──\n");
        log.append(shaOk ? "[OK] sha256 一致\n" : "[X] sha256 不一致（期望 " + shortSha(want) + "，实得 " + shortSha(got) + "）\n");
        log.append(bomOk ? "[OK] 无 BOM\n" : "[X] 文件带 BOM，dsh 会解析失败\n");
        log.append("[OK] 大小 ").append(size).append(" 字节\n");
        log.append("[OK] 属主 ").append(owner).append("\n");
        log.append("[OK] context ").append(ctxOut).append("\n");
        log.append(hits == CHECK_BLOCKS.length
                ? "[OK] 关键块 " + hits + "/" + CHECK_BLOCKS.length + " 全中\n"
                : "[X] 关键块 " + hits + "/" + CHECK_BLOCKS.length + "，缺：" + join(missing, "、") + "\n");

        res.output = log.toString();
        res.success = shaOk && bomOk && hits == CHECK_BLOCKS.length && owner != null && !owner.isEmpty();
        if (!res.success) {
            res.error = !shaOk ? "写入后 sha256 不一致"
                    : !bomOk ? "文件带 BOM"
                    : hits != CHECK_BLOCKS.length ? "关键块缺失：" + join(missing, "、")
                    : "属主读取失败";
            res.output += "\n[X] " + res.error;
        } else {
            res.output += "\n[OK] 破甲模式已就位。完全退出 dsh 后重开，"
                    + "新建会话在 preset 选择器里选「" + PRESET_NAME + "」。\n";
        }
        return res;
    }

    /**
     * 卸载：把 preset 目录移到 _uninstalled-pj-mode-<时间戳>/。
     * 不直删 —— 确认无误后用户自己删。
     * 目录里没有本工具标记就拒绝（防止手滑干掉别人的 preset）。
     */
    public static Result uninstall() {
        Result res = new Result();
        List<String> L = new ArrayList<>();
        L.addAll(prologueLocate());
        L.add("PD=\"$DSH/.agent-presets/" + PRESET_ID + "\"");
        L.add("if [ ! -d \"$PD\" ]; then echo '[!] 未安装，无需卸载'; exit 0; fi");
        L.add("# 标记校验");
        L.add("if [ -f \"$PD/agent.cordis.yml\" ]; then");
        L.add("  if ! grep -qF -- " + q(MARKER) + " \"$PD/agent.cordis.yml\" 2>/dev/null; then");
        L.add("    echo '[X] 该目录不是本工具安装的（缺少 " + MARKER + " 标记），为安全起见不予删除';");
        L.add("    echo \"    如确认要删，请手动：rm -rf $PD\";");
        L.add("    exit 6");
        L.add("  fi");
        L.add("fi");
        L.add("TS=$(date +%Y%m%d-%H%M%S)");
        L.add("TRASH=\"$DSH/.agent-presets/" + UNINSTALL_PREFIX + PRESET_ID + "-$TS\"");
        L.add("mv \"$PD\" \"$TRASH\"");
        L.add("echo \"[OK] 已卸载，原目录移动到：$TRASH\"");
        L.add("echo '     （确认无误后可手动删除该备份目录）'");
        L.add("exit 0");
        Result r = exec(join(L));
        res.output = r.output;
        res.success = r.output.contains("[OK] 已卸载") || r.output.contains("未安装");
        if (!res.success) res.error = r.error.isEmpty() ? "卸载未完成" : r.error;
        return res;
    }

    /** 卸载（带 Context 的入口：patch 层需要释放 assets 才能调 node 写入器） */
    public static Result uninstall(Context ctx) {
        if (!detectPatchLayer().isEmpty()) return uninstallPatch(ctx);
        return uninstall();
    }

    /** 自检：核对文件、关键块、属主、context、BOM，并检测 dsh 是否在跑 */
    public static Result check(Context ctx) {
        Result res = new Result();
        StringBuilder log = new StringBuilder();
        Payload pl = loadPayload(ctx);
        String patchNow = detectPatchLayer();
        if (!patchNow.isEmpty()) {
            Snapshot ds = scanPatch(ctx, patchNow);
            log.append(checkPatchText(ctx, ds, pl));
            res.output = log.toString();
            res.success = ds.success && ds.installed && ds.prefixOk && ds.bundleOk && pl.ok;
            if (!res.success) res.error = ds.installed ? "校验未通过" : "尚未安装";
            return res;
        }
        log.append("── 载荷（assets/" + ASSET_COMPOSITION + "）──\n");
        log.append("  大小      ").append(pl.size).append(" 字节\n");
        log.append("  顶层 row  ").append(pl.rows).append("\n");
        log.append("  SHA256    ").append(shortSha(pl.sha)).append("\n");
        log.append("  关键块    ").append(pl.blocksHit).append("/").append(CHECK_BLOCKS.length)
           .append(pl.ok ? " ✅" : " ❌ 缺：" + join(pl.blocksMissing, "、")).append("\n\n");

        Snapshot s = scan(ctx);
        log.append("── 现场（$DSH_HOME/.agent-presets/" + PRESET_ID + "）──\n");
        if (!s.success) {
            log.append("  扫描失败：").append(s.error).append("\n");
            res.output = log.toString();
            res.error = s.error;
            return res;
        }
        log.append("  dsh home  ").append(s.dshHome).append("\n");
        log.append("  目录      ").append(s.presetDir).append("\n");
        log.append("  已安装    ").append(s.installed ? "是" : "否").append("\n");
        log.append("  composition ").append(s.compoExists ? s.compoSize + " 字节" : "缺失").append("\n");
        log.append("  preset.yml  ").append(s.metaExists ? "存在" : "缺失").append("\n");
        log.append("  显示名    ").append(nz(s.presetDisplayName)).append("\n");
        log.append("  属主      ").append(nz(s.compoOwner)).append("\n");
        log.append("  context   ").append(nz(s.compoContext)).append("\n");
        log.append("  SHA256    ").append(shortSha(s.compoSha)).append("\n");
        log.append("  卸载备份  ").append(s.uninstallBackups).append(" 份\n");
        log.append("\n── 关键块核对 ──\n");
        for (String[] pair : CHECK_BLOCKS) {
            boolean hit = !s.blocksMissing.contains(pair[1]);
            log.append("  ").append(hit ? "[OK]" : "[X] ").append(" ").append(pair[1]).append("\n");
        }
        log.append("\n  dsh 进程  ").append(s.dshRunning ? "运行中 —— 请完全退出后重开才会看到新模式" : "未运行，可以直接重开").append("\n");

        boolean allOk = s.installed
                && s.blocksMissing.isEmpty()
                && pl.ok
                && s.compoSha.equalsIgnoreCase(pl.sha);
        log.append("\n");
        if (allOk) {
            log.append("自检通过：破甲模式已就位，且与内置载荷完全一致。\n");
            log.append("下一步：完全退出 dsh → 重开 → 新建会话 → 选「" + PRESET_NAME + "」→ 发「破甲自检」\n");
        } else if (!s.installed) {
            log.append("自检未通过：尚未安装。点「一键安装」即可。\n");
        } else if (!pl.ok) {
            log.append("自检未通过：内置载荷本身缺块（apk 打包异常）。\n");
        } else if (!s.compoSha.equalsIgnoreCase(pl.sha)) {
            log.append("自检未通过：磁盘上的 composition 与内置载荷不一致（可能被手改过）。\n");
            log.append("           重跑一次「一键安装」即可对齐。\n");
        } else {
            log.append("自检未通过：有 ").append(s.blocksMissing.size()).append(" 个关键块缺失。\n");
        }
        res.output = log.toString();
        res.success = allOk;
        if (!allOk) res.error = s.installed ? "校验未通过" : "尚未安装";
        return res;
    }

    // ══════════════════════════════════════════════════════════
    // shell 前导：定位 dsh home / node
    // ══════════════════════════════════════════════════════════

    /**
     * 定位 dsh：探测所有已知包名 + 所有已知 dsh home 布局。
     *
     * 导出的变量（后续脚本都用它们）：
     *   PKG   —— 命中的包名
     *   DSH   —— dsh home 绝对路径
     *   NODE  —— 可用的 node 二进制
     *   NMLIB —— node 的 LD_LIBRARY_PATH
     *   DSHUID / DSHGID —— dsh home 的属主（写文件时要对齐）
     */
    private static List<String> prologueLocate() {
        List<String> L = new ArrayList<>();
        L.add("export PATH=/system/bin:/system/xbin:$PATH");
        L.add("PKG=\"" + DshTargets.PKG + "\"");
        L.add("DSH=\"\"");
        // 只认 Harness 的布局：files/payload/dshhome
        L.add("for c in \\");
        L.add("  \"/data/data/$PKG/files/payload/dshhome\" \\");
        L.add("  \"/data/user/0/$PKG/files/payload/dshhome\"; do");
        L.add("  if [ -d \"$c\" ]; then DSH=\"$c\"; break; fi");
        L.add("done");
        L.add("if [ -z \"$DSH\" ]; then echo 'ERR 找不到 dsh home（dsh 未安装或未初始化）'; exit 1; fi");
        L.add("echo \"[*] 包名 = $PKG\"");
        L.add("echo \"[*] dsh home = $DSH\"");
        // node：Harness 是 Termux 式原生 ARM64 二进制，就在 payload/runtime/bin 下
        L.add("NODE=\"\"");
        L.add("NODEPRE=\"\"");
        L.add("for n in \\");
        L.add("  \"/data/data/$PKG/files/payload/runtime/bin/node\" \\");
        L.add("  \"/data/user/0/$PKG/files/payload/runtime/bin/node\"; do");
        L.add("  if [ -x \"$n\" ]; then NODE=\"$n\"; break; fi");
        L.add("done");
        L.add("export NODEPRE");
        // ── 布局判定（2026-10 实测本机 com.deepseek.harness v1.20.0）──
        // Harness 的 dsh home = files/payload/dshhome，**没有 settings.yaml**
        // （旧版 settings 已导入并改名为 settings.yaml.imported），
        // 配置根落在 profiles/web/cordis.patch.yml。
        // 之前的判据是「没有 settings.yaml + 有 profiles/web/cordis.patch.yml」，
        // 结果把 Harness 误判成 DSHA，写路径、骨架、node 全错，装一次挂一次。
        // 现在改成按 dsh home 的**真实形态**判：
        //   Harness → dshhome/profiles/web/cordis.patch.yml  + dshroot/lib/node_modules
        //   DSHA    → （已卸载，不再支持）
        L.add("PATCHF=\"\"");
        L.add("BUNDLEF=\"\"");
        L.add("YAMLROOT=\"\"");
        L.add("if [ -f \"$DSH/profiles/web/cordis.patch.yml\" ]; then");
        L.add("  PATCHF=\"$DSH/profiles/web/cordis.patch.yml\"");
        L.add("fi");
        // 骨架在 dshhome 的兄弟目录 dshroot 里（payload/dshhome + payload/dshroot）
        L.add("for b in \\");
        L.add("  \"$DSH/../dshroot/lib/node_modules/@deepseek-ai/dsh\" \\");
        L.add("  \"$DSH/../dshroot/lib/node_modules\" \\");
        L.add("  \"$DSH/node_modules/@deepseek-ai/dsh\" \\");
        L.add("  \"$DSH/node_modules\"; do");
        L.add("  if [ -d \"$b/node_modules/@deepseek-ai/dsh-web-app\" ] || [ -d \"$b/@deepseek-ai/dsh-web-app\" ]; then");
        L.add("    YAMLROOT=\"$b\"; break;");
        L.add("  fi");
        L.add("done");
        L.add("if [ -n \"$YAMLROOT\" ]; then");
        L.add("  for s in \\");
        L.add("    \"$YAMLROOT/node_modules/@deepseek-ai/dsh-web-app/presets/standard.patch.yml\" \\");
        L.add("    \"$YAMLROOT/@deepseek-ai/dsh-web-app/presets/standard.patch.yml\" \\");
        L.add("    \"$YAMLROOT/@deepseek-ai/dsh/node_modules/@deepseek-ai/dsh-web-app/presets/standard.patch.yml\"; do");
        L.add("    if [ -f \"$s\" ]; then BUNDLEF=\"$s\"; break; fi");
        L.add("  done");
        L.add("fi");
        L.add("export PATCHF BUNDLEF YAMLROOT");
        L.add("if [ -n \"$NODE\" ]; then echo \"[*] node = $NODE $NODEPRE\"; else echo 'ERR 未找到可用 node'; fi");
        L.add("if [ -n \"$PATCHF\" ]; then echo \"[*] patch 层 = $PATCHF\"; else echo 'ERR 未找到 profiles/web/cordis.patch.yml'; fi");
        L.add("if [ -n \"$BUNDLEF\" ]; then echo \"[*] 版本骨架 = $BUNDLEF\"; else echo 'ERR 未找到 standard.patch.yml'; fi");
        // node 的动态库目录
        L.add("NMLIB=\"\"");
        L.add("for l in \\");
        L.add("  \"/data/data/$PKG/files/payload/runtime/lib\" \\");
        L.add("  \"/data/data/$PKG/files/usr/lib\" \\");
        L.add("  \"/data/user/0/$PKG/files/payload/runtime/lib\" \\");
        L.add("  \"/data/user/0/$PKG/files/usr/lib\"; do");
        L.add("  if [ -d \"$l\" ]; then NMLIB=\"$l\"; break; fi");
        L.add("done");
        L.add("export LD_LIBRARY_PATH=\"$NMLIB\"");
        // 属主：从 dsh home 现取，不硬编码
        L.add("DSHUID=$(stat -c %u \"$DSH\" 2>/dev/null)");
        L.add("DSHGID=$(stat -c %g \"$DSH\" 2>/dev/null)");
        L.add("echo \"[*] node = $NODE\"");
        L.add("echo \"[*] 属主 = ${DSHUID:-?}:${DSHGID:-?}\"");
        return L;
    }

    // ══════════════════════════════════════════════════════════
    // DSHA（dsh 0.2.x，profile patch 层）模式
    // ══════════════════════════════════════════════════════════

    /**
     * 探测配置根：返回 profile patch 文件绝对路径；找不到返回空串。
     *
     * <p>判据只看「dsh home 下有没有 profiles/web/cordis.patch.yml」，
     * 不再掺 settings.yaml 的存在性 —— 之前就是因为 Harness 没有
     * settings.yaml（已改名为 settings.yaml.imported），被误判成 DSHA。
     */
    public static String detectPatchLayer() {
        Result r = exec(join(prologueLocate()) + "\n" + "echo \"DSHPATCH=$PATCHF\"\nexit 0");
        String p = field(r.output, "DSHPATCH=");
        return p == null ? "" : p.trim();
    }

    /** 把 assets 里的一个文件释放到 App cache，返回文件 */
    private static java.io.File dumpAsset(Context ctx, String name, String as) throws Exception {
        java.io.InputStream in = ctx.getAssets().open(name);
        java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        in.close();
        java.io.File f = new java.io.File(ctx.getCacheDir(), as);
        java.io.FileOutputStream fo = new java.io.FileOutputStream(f);
        fo.write(bo.toByteArray());
        fo.close();
        return f;
    }

    /**
     * DSHA 模式下跑 node 端写入器（assets/dsha_patch.js）。
     *
     * @param mode     scan / install / uninstall / cfg-read / cfg-write / cfg-rollback
     * @param params   给 node 的 params 对象（JSON 文本，可为 null）
     * @param postCheck true = 写入后做属主/context/关键块回读校验
     */
    public static Result runDshaScript(Context ctx, String mode, String params, boolean postCheck,
                                       String headLog) {
        Result res = new Result();
        StringBuilder log = new StringBuilder(headLog == null ? "" : headLog);
        java.io.File js, compo, par;
        try {
            js = dumpAsset(ctx, ASSET_PATCH_JS, "seagull_dsh_patch.js");
            compo = dumpAsset(ctx, ASSET_COMPOSITION, "seagull_compo.yml");
            par = new java.io.File(ctx.getCacheDir(), "seagull_params.json");
            java.io.FileOutputStream fo = new java.io.FileOutputStream(par);
            fo.write((params == null || params.trim().isEmpty() ? "{}" : params)
                    .getBytes(java.nio.charset.StandardCharsets.UTF_8));
            fo.close();
        } catch (Exception e) {
            res.error = "释放 assets 失败：" + e.getMessage();
            res.output = log + "\n[X] " + res.error;
            return res;
        }

        List<String> L = new ArrayList<>(prologueLocate());
        L.add("if [ -z \"$PATCHF\" ]; then echo '{\"ok\":false,\"error\":\"找不到 profiles/web/cordis.patch.yml\"}'; exit 0; fi");
        L.add("if [ -z \"$BUNDLEF\" ]; then echo '{\"ok\":false,\"error\":\"找不到版本骨架 standard.patch.yml\"}'; exit 0; fi");
        L.add("if [ -z \"$NODE\" ]; then echo '{\"ok\":false,\"error\":\"找不到可用 node\"}'; exit 0; fi");
        L.add("TMP=" + TMP_DIR);
        L.add("rm -rf \"$TMP\"; mkdir -p \"$TMP\"");
        L.add("cp " + q(js.getAbsolutePath()) + " \"$TMP/dsh_patch.js\" >/dev/null 2>&1 || { echo 'ERR cp-js'; exit 11; }");
        L.add("cp " + q(compo.getAbsolutePath()) + " \"$TMP/compo.yml\" >/dev/null 2>&1 || { echo 'ERR cp-compo'; exit 12; }");
        L.add("cp " + q(par.getAbsolutePath()) + " \"$TMP/params.json\" >/dev/null 2>&1 || { echo 'ERR cp-params'; exit 13; }");
        L.add("chmod 644 \"$TMP/dsh_patch.js\" \"$TMP/compo.yml\" \"$TMP/params.json\"");
        L.add("printf '{\"mode\":\"%s\",\"home\":\"%s\",\"patch\":\"%s\",\"bundle\":\"%s\","
                + "\"yamlroot\":\"%s\",\"composition\":\"%s\",\"backups\":\"%s\",\"params\":' "
                + "\"" + mode + "\" \"$DSH\" \"$PATCHF\" \"$BUNDLEF\" \"$YAMLROOT\" \"$TMP/compo.yml\" "
                + "\"$DSH/backups\" > \"$TMP/cmd.json\"");
        L.add("cat \"$TMP/params.json\" >> \"$TMP/cmd.json\"");
        L.add("printf '}' >> \"$TMP/cmd.json\"");
        // node 是 Termux 式 ARM64 二进制，必须给它自己的 lib 目录
        L.add("LD_LIBRARY_PATH=\"$NMLIB\" \"$NODE\" $NODEPRE \"$TMP/dsh_patch.js\" \"$TMP/cmd.json\" 2>&1");
        L.add("RC=$?");
        L.add("echo \"NODE_RC=$RC\"");
        if (postCheck) {
            // patch 文件属主/context 对齐（dsh 进程 uid ≠ root，root 写的它读不了）
            L.add("U=$(stat -c %u \"$DSH\" 2>/dev/null); G=$(stat -c %g \"$DSH\" 2>/dev/null)");
            L.add("[ -n \"$U\" ] && chown \"$U:$G\" \"$PATCHF\" 2>/dev/null");
            L.add("CTX=$(stat -c %C \"$DSH\" 2>/dev/null)");
            L.add("[ -n \"$CTX\" ] && chcon \"$CTX\" \"$PATCHF\" 2>/dev/null");
            L.add("restorecon \"$PATCHF\" 2>/dev/null || true");
            L.add("echo \"SIZE=$(stat -c %s \"$PATCHF\" 2>/dev/null)\"");
            L.add("echo \"OWNER=$(stat -c '%u:%g' \"$PATCHF\" 2>/dev/null)\"");
            L.add("echo \"CTXF=$(stat -c %C \"$PATCHF\" 2>/dev/null)\"");
            L.add("echo \"BOM_RAW=$(head -c 3 \"$PATCHF\" 2>/dev/null | od -An -tx1 | tr -d ' \\n')\"");
            L.add("echo \"SHA=$(sha256sum \"$PATCHF\" 2>/dev/null | cut -d' ' -f1)\"");
            L.add("echo '--- 关键块 ---'");
            for (int i = 0; i < CHECK_BLOCKS.length; i++) {
                L.add("N=$(grep -cF -- " + q(CHECK_BLOCKS[i][0]) + " \"$PATCHF\" 2>/dev/null); echo \"B" + i + "=${N:-0}\"");
            }
        }
        L.add("rm -rf \"$TMP\"");
        L.add("exit $RC");

        Result r = exec(join(L));
        log.append(r.output);
        res.output = log.toString();

        String nodeRc = field(r.output, "NODE_RC=");
        String json = firstJson(r.output);
        JSONObject o = null;
        try { if (json != null) o = new JSONObject(json); } catch (Exception ignored) { }
        res.success = "0".equals(nodeRc) && o != null && o.optBoolean("ok");
        if (o != null && !o.optBoolean("ok")) {
            res.error = o.optString("error", "node 端失败");
        } else if (!"0".equals(nodeRc)) {
            res.error = "node 退出码 " + nodeRc;
        }
        return res;
    }

    /** 从输出里取第一行 JSON 对象 */
    private static String firstJson(String out) {
        if (out == null) return null;
        for (String raw : out.split("\n")) {
            String t = raw.trim();
            if (t.startsWith("{") && t.endsWith("}")) return t;
        }
        return null;
    }

    /**
     * patch 层：扫描现场。
     *
     * <p>preset 是 $DSH_HOME/profiles/web/cordis.patch.yml 里的一条
     * insert 声明，不再是 .agent-presets 目录。
     */
    public static Snapshot scanPatch(Context ctx, String patch) {
        Snapshot s = new Snapshot();
        s.dshaMode = true;
        s.patchPath = patch;
        Result r = runDshaScript(ctx, "scan", null, false, null);
        s.raw = r.output;
        String json = firstJson(r.output);
        if (json == null) {
            s.error = "node 端没有返回 JSON\n" + r.output;
            return s;
        }
        try {
            JSONObject o = new JSONObject(json);
            if (!o.optBoolean("ok")) {
                s.error = o.optString("error", "扫描失败");
                return s;
            }
            s.installed = o.optBoolean("installed");
            s.pluginRows = o.optInt("pluginRows");
            s.prefixOk = o.optBoolean("prefixOk");
            s.bundleOk = o.optBoolean("bundleOk");
            s.compositionOk = o.optBoolean("compositionOk");
            s.patchBytes = o.optLong("patchBytes");
            s.patchParses = o.optBoolean("patchParses", true);
            s.compoSize = o.optLong("prefixChars");
            s.compoExists = s.compositionOk;
            s.metaExists = s.installed;
            s.presetDisplayName = o.optString("presetName", PRESET_NAME);
            s.presetDir = patch;
            s.dshRunning = isRunning(ctx);
            s.blocksHit = s.installed && s.prefixOk ? CHECK_BLOCKS.length : 0;
            s.success = true;
        } catch (Exception e) {
            s.error = "解析扫描结果失败：" + e.getMessage();
        }
        return s;
    }

    /** patch 层：安装 preset */
    public static Result installPatch(Context ctx, Payload pl, StringBuilder log) {
        Result res = new Result();
        if (!pl.ok) {
            res.error = pl.error;
            res.output = log + "\n[X] " + pl.error;
            return res;
        }
        log.append("[*] 布局     DeepSeek Harness · profile patch 层\n");
        log.append("[*] 骨架     运行时自带的 standard.patch.yml（与当前版本对齐）\n");
        log.append("[*] 载荷     ").append(pl.size).append(" 字节 / ").append(pl.rows).append(" 个顶层 row\n\n");

        Result r = runDshaScript(ctx, "install", null, true, log.toString());
        // 关键块逐条核对（写入后回读）
        int hits = 0;
        List<String> missing = new ArrayList<>();
        for (int i = 0; i < CHECK_BLOCKS.length; i++) {
            String v = field(r.output, "B" + i + "=");
            if (v != null && parseLong(v) >= 1) hits++;
            else missing.add(CHECK_BLOCKS[i][1]);
        }
        String owner = field(r.output, "OWNER=");
        String size = field(r.output, "SIZE=");
        String sha = field(r.output, "SHA=");
        String bom = field(r.output, "BOM_RAW=");
        boolean bomOk = !(bom != null && bom.toLowerCase().startsWith("efbbbf"));

        StringBuilder out = new StringBuilder(r.output);
        out.append("\n── 校验 ──\n");
        out.append(bomOk ? "[OK] 无 BOM\n" : "[X] 文件带 BOM\n");
        out.append("[OK] patch 大小 ").append(size == null ? "?" : size).append(" 字节\n");
        out.append("[OK] 属主 ").append(owner == null ? "?" : owner).append("\n");
        out.append("[OK] sha256 ").append(shortSha(sha)).append("\n");
        out.append(hits == CHECK_BLOCKS.length
                ? "[OK] 关键块 " + hits + "/" + CHECK_BLOCKS.length + " 全中\n"
                : "[X] 关键块 " + hits + "/" + CHECK_BLOCKS.length + "，缺：" + join(missing, "、") + "\n");

        boolean ok = r.success && hits == CHECK_BLOCKS.length && bomOk;
        if (ok) {
            out.append("\n[OK] 破甲模式已写入 profile patch 层。\n")
                    .append("     完全退出 ").append(dshAppLabel()).append(" 后重开 → 新建会话 →\n")
                    .append("     preset 选择器里选「").append(PRESET_NAME).append("」→ 发「破甲自检」。\n");
        }
        res.success = ok;
        res.output = out.toString();
        if (!ok) res.error = r.error.isEmpty() ? "校验未通过" : r.error;
        return res;
    }

    /** patch 层：卸载 preset（整段删除，不做目录搬家） */
    public static Result uninstallPatch(Context ctx) {
        Result res = new Result();
        Result r = runDshaScript(ctx, "uninstall", null, true, null);
        res.output = r.output;
        res.success = r.success;
        if (res.success) res.output += "\n[OK] 已从 profile patch 层移除「" + PRESET_NAME + "」。\n";
        else res.error = r.error.isEmpty() ? "卸载未完成" : r.error;
        return res;
    }

    /** patch 层：自检文本 */
    public static String checkPatchText(Context ctx, Snapshot s, Payload pl) {
        StringBuilder log = new StringBuilder();
        log.append("── 载荷（assets/").append(ASSET_COMPOSITION).append("）──\n");
        log.append("  大小      ").append(pl.size).append(" 字节\n");
        log.append("  顶层 row  ").append(pl.rows).append("\n");
        log.append("  SHA256    ").append(shortSha(pl.sha)).append("\n");
        log.append("  关键块    ").append(pl.blocksHit).append("/").append(CHECK_BLOCKS.length)
                .append(pl.ok ? " ✅" : " ❌ 缺：" + join(pl.blocksMissing, "、")).append("\n\n");
        log.append("── 现场（DSHA · profile patch 层）──\n");
        if (!s.success) {
            log.append("  扫描失败：").append(s.error).append("\n");
            return log.toString();
        }
        log.append("  dsh home  ").append(s.dshHome.isEmpty() ? "(见日志)" : s.dshHome).append("\n");
        log.append("  patch     ").append(s.patchPath).append("\n");
        log.append("  patch 大小 ").append(s.patchBytes).append(" 字节（yaml ")
                .append(s.patchParses ? "可解析" : "解析失败").append("）\n");
        log.append("  已安装    ").append(s.installed ? "是" : "否").append("\n");
        log.append("  插件行数  ").append(s.pluginRows).append("\n");
        log.append("  v5N 人设  ").append(s.prefixOk ? "命中" : "缺失").append("\n");
        log.append("  版本骨架  ").append(s.bundleOk ? "可用" : "缺失").append("\n");
        log.append("  载荷解析  ").append(s.compositionOk ? "可用" : "失败").append("\n");
        log.append("  dsh 进程  ").append(s.dshRunning ? "运行中 —— 请完全退出后重开才会看到新模式" : "未运行，可以直接重开").append("\n");
        boolean allOk = s.installed && s.prefixOk && s.bundleOk && pl.ok;
        log.append("\n");
        if (allOk) {
            log.append("自检通过：破甲模式已在 patch 层就位。\n");
            log.append("下一步：完全退出 dsh → 重开 → 新建会话 → 选「").append(PRESET_NAME).append("」→ 发「破甲自检」\n");
        } else if (!s.installed) {
            log.append("自检未通过：尚未安装。点「一键安装」即可。\n");
        } else {
            log.append("自检未通过：patch 条目在，但内容不完整（重跑一次「一键安装」即可对齐）。\n");
        }
        return log.toString();
    }

    /** 目标 App 的显示名 */
    public static String dshAppLabel() {
        return "DeepSeek Harness";
    }

    /** 目标 App 是否在跑 */
    public static boolean isRunning(Context ctx) {
        String out = runSuSimple("pidof com.dsh.client com.deepseek.harness com.dshmobile.shell 2>/dev/null; "
                + "for d in /proc/[0-9]*; do tr '\\0' ' ' < $d/cmdline 2>/dev/null | grep -q 'dsh/lib/bin.js\\|/usr/local/bin/dsh' && echo x; done | head -1");
        return out != null && !out.trim().isEmpty();
    }

    /** 把包名数组转成 shell 词列表（每个单引号包裹）。 */
    private static String shellQuoteAll(String[] arr) {        StringBuilder b = new StringBuilder();
        for (int i = 0; i < arr.length; i++) {
            if (i > 0) b.append(' ');
            b.append('\'').append(arr[i]).append('\'');
        }
        return b.toString();
    }

    private static String join(List<String> lines) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < lines.size(); i++) {
            sb.append(lines.get(i));
            if (i < lines.size() - 1) sb.append("\n");
        }
        return sb.toString();
    }

    // ══════════════════════════════════════════════════════════
    // 内部工具
    // ══════════════════════════════════════════════════════════

    /** 从输出里取 NAME=value 的 value */
    private static String field(String out, String name) {
        if (out == null) return null;
        for (String line : out.split("\n")) {
            String t = line.trim();
            if (t.startsWith(name)) return t.substring(name.length()).trim();
        }
        return null;
    }

    private static long parseLong(String s) {
        try { return Long.parseLong(s.trim()); } catch (Exception e) { return 0; }
    }

    private static String nz(String s) {
        return (s == null || s.isEmpty()) ? "--" : s;
    }

    private static String shortSha(String s) {
        if (s == null || s.isEmpty()) return "--";
        return s.length() > 16 ? s.substring(0, 16) + "…" : s;
    }

    private static String join(List<String> a, String sep) {
        if (a == null || a.isEmpty()) return "";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < a.size(); i++) {
            if (i > 0) b.append(sep);
            b.append(a.get(i));
        }
        return b.toString();
    }

    /** 单引号包裹，防 shell 元字符 */
    private static String q(String s) {
        return "'" + s.replace("'", "'\\''") + "'";
    }

    public static String sha256(byte[] data) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] d = md.digest(data);
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            return "";
        }
    }

    private static Result exec(String script) {
        Result r = new Result();
        StringBuilder log = new StringBuilder();
        try {
            Process p = startSuWithStdin(script);
            if (p == null) {
                r.error = "无法调用 su（未授权 root 或 su 不可用）";
                r.output = r.error;
                return r;
            }
            BufferedReader out = new BufferedReader(new InputStreamReader(p.getInputStream(), "UTF-8"));
            BufferedReader err = new BufferedReader(new InputStreamReader(p.getErrorStream(), "UTF-8"));
            String line;
            while ((line = out.readLine()) != null) log.append(line).append("\n");
            StringBuilder elog = new StringBuilder();
            while ((line = err.readLine()) != null) elog.append(line).append("\n");
            int code = p.waitFor();

            if (elog.length() > 0) log.append("\n[stderr]\n").append(elog);
            r.output = log.toString();
            r.success = (code == 0);
            if (code != 0) r.error = "退出码 " + code;
        } catch (Exception e) {
            r.success = false;
            r.error = e.getClass().getSimpleName() + ": " + e.getMessage();
            r.output = log.toString() + "\n[异常] " + r.error;
        }
        return r;
    }

    /**
     * 启动 su 并把脚本写入其 stdin。
     * su -M 必须排第一：App 私有挂载命名空间里 /data/data/<别的包> 可能是 tmpfs 影子。
     */
    private static Process startSuWithStdin(String script) {
        String[][] variants = {
                {"su", "-M"},
                {"su", "--mount-master"},
                {"su"},
                {"/system/bin/su", "-M"},
                {"/system/bin/su"},
        };
        for (String[] v : variants) {
            Process p = null;
            try {
                p = new ProcessBuilder(v).redirectErrorStream(false).start();
                OutputStream os = p.getOutputStream();
                OutputStreamWriter w = new OutputStreamWriter(os, "UTF-8");
                w.write(script);
                w.write("\nexit\n");
                w.flush();
                w.close();
                return p;
            } catch (Exception e) {
                if (p != null) { try { p.destroy(); } catch (Exception ignored) { } }
            }
        }
        return null;
    }

    private static String runSuSimple(String command) {
        String[][] variants = {
                {"su", "-M", "-c", command},
                {"su", "-c", command},
                {"/system/bin/su", "-M", "-c", command},
                {"/system/bin/su", "-c", command},
        };
        for (String[] v : variants) {
            try {
                Process p = new ProcessBuilder(v).redirectErrorStream(true).start();
                BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream(), "UTF-8"));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) sb.append(line).append("\n");
                p.waitFor();
                if (sb.length() > 0) return sb.toString();
            } catch (Exception ignored) {
            }
        }
        return null;
    }
}