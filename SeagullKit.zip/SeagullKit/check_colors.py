#!/usr/bin/env python3
"""colors.xml 四项必查：格式 / 重复 / 引用 / XML 语法
用法: python3 check_colors.py [项目根目录]
"""
import re, os, sys
from collections import Counter

root = sys.argv[1] if len(sys.argv) > 1 else '.'
cf = os.path.join(root, 'app/src/main/res/values/colors.xml')
fail = 0

src = open(cf, encoding='utf-8').read()
pairs = re.findall(r'<color name="(\w+)">([^<]+)</color>', src)

# 1. 格式
bad = [(n, v) for n, v in pairs
       if not (v.strip().startswith('#')
               and len(v.strip()) - 1 in (6, 8)
               and all(c in '0123456789abcdefABCDEF' for c in v.strip()[1:]))]
print(f"1. 颜色格式    {'✅' if not bad else '❌ ' + str(bad)}")
fail += bool(bad)

# 2. 重复
names = [n for n, _ in pairs]
dup = {k: v for k, v in Counter(names).items() if v > 1}
print(f"2. 重复定义    {'✅' if not dup else '❌ ' + str(dup)}")
fail += bool(dup)

# 3. 引用
defined = set(names) | set(os.path.splitext(x)[0]
                           for x in os.listdir(os.path.join(root, 'app/src/main/res/color'))
                           if x.endswith('.xml'))
miss = {}
for d, _, fs in os.walk(os.path.join(root, 'app/src/main')):
    for f in fs:
        if not f.endswith(('.xml', '.java')):
            continue
        t = open(os.path.join(d, f), encoding='utf-8').read()
        for c in set(re.findall(r'@color/(\w+)', t)) | set(re.findall(r'R\.color\.(\w+)', t)):
            if c not in defined:
                miss.setdefault(f, []).append(c)
print(f"3. 引用完整性  {'✅' if not miss else '❌ ' + str(miss)}")
fail += bool(miss)

# 4. XML
try:
    import xml.dom.minidom as m
    m.parse(cf)
    print("4. XML 语法    ✅")
except Exception as e:
    print(f"4. XML 语法    ❌ {e}")
    fail += 1

print(f"\n结果: {'全部通过' if not fail else f'{fail} 项失败'}")
sys.exit(1 if fail else 0)
