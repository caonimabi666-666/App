package com.example.seagullkit;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;

/**
 * Operit 破甲注入界面。
 *
 * 流程：扫描现场 → 注入（停 App + 备份 + 改写角色卡 + 写回 + 重启）→ 自检（触发真实请求验证）
 * 注入的是 assets/poja_payload.txt（操作者运行基线 v5N 双层协同注入内核）。
 */
public class OperitPojaActivity extends AppCompatActivity {

    private final Handler ui = new Handler(Looper.getMainLooper());

    private TextView statusText, detailText, logText;
    private View logBox;
    private MaterialButton btnScan, btnInject, btnVerify, btnRollback;

    private OperitPojaEditor.Snapshot snap;
    private OperitPojaEditor.Payload payload;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_operit_poja);

        statusText  = findViewById(R.id.pj_status);
        detailText  = findViewById(R.id.pj_detail);
        logText     = findViewById(R.id.pj_log);
        logBox      = findViewById(R.id.pj_log_box);
        btnScan     = findViewById(R.id.btn_pj_scan);
        btnInject   = findViewById(R.id.btn_pj_inject);
        btnVerify   = findViewById(R.id.btn_pj_verify);
        btnRollback = findViewById(R.id.btn_pj_rollback);

        payload = OperitPojaEditor.loadPayload(this);

        btnScan.setOnClickListener(v -> { TapFeedback.tap(v); load(); });
        btnInject.setOnClickListener(v -> { TapFeedback.tap(v); confirmInject(); });
        btnVerify.setOnClickListener(v -> { TapFeedback.tap(v); doVerify(); });
        btnRollback.setOnClickListener(v -> { TapFeedback.heavy(v); confirmRollback(); });

        load();
    }

    // ──────────────────────────────────────────────────────────
    // 扫描
    // ──────────────────────────────────────────────────────────
    private void load() {
        if (!OperitPojaEditor.isOperitInstalled(this)) {
            statusText.setText("未检测到 Operit（com.ai.assistance.operit）");
            statusText.setTextColor(resolveColor(R.color.state_error));
            detailText.setText("--");
            btnInject.setEnabled(false);
            btnVerify.setEnabled(false);
            btnRollback.setEnabled(false);
            return;
        }
        setBusy(true);
        statusText.setText("扫描中…");
        statusText.setTextColor(resolveColor(R.color.text_body));

        new Thread(() -> {
            final boolean root = OperitPojaEditor.hasRoot();
            final OperitPojaEditor.Snapshot s = root ? OperitPojaEditor.scan() : null;
            ui.post(() -> {
                setBusy(false);
                if (!root) {
                    statusText.setText("Operit 已安装，但未获得 root 权限");
                    statusText.setTextColor(resolveColor(R.color.state_error));
                    detailText.setText("本工具需要 root（su -M）才能读写 Operit 私有目录");
                    return;
                }
                if (s == null || !s.success) {
                    statusText.setText("扫描失败：" + (s == null ? "未知" : s.error));
                    statusText.setTextColor(resolveColor(R.color.state_error));
                    detailText.setText(s == null ? "" : s.raw);
                    return;
                }
                snap = s;
                render(s);
            });
        }).start();
    }

    private void render(OperitPojaEditor.Snapshot s) {
        boolean both = s.slotAInjected && s.slotBInjected;
        boolean any = s.slotAInjected || s.slotBInjected;

        if (both) {
            statusText.setText("已破甲 · 双层槽位均命中锚点");
            statusText.setTextColor(resolveColor(R.color.state_ok));
        } else if (any) {
            statusText.setText("半破甲 · 只有一层命中，建议重新注入");
            statusText.setTextColor(resolveColor(R.color.state_warn));
        } else {
            statusText.setText("未注入 · 角色卡为原始状态");
            statusText.setTextColor(resolveColor(R.color.text_body));
        }

        StringBuilder b = new StringBuilder();
        b.append("角色        ").append(nz(s.cardName)).append("  (").append(nz(s.cardId)).append(")\n");
        b.append("槽位A       ").append(s.slotALen < 0 ? "不存在" : s.slotALen + " 字符")
                .append("   ").append(s.slotAInjected ? "✅ 已注入" : "—").append("\n");
        b.append("槽位B       ").append(s.slotBLen < 0 ? "不存在" : s.slotBLen + " 字符")
                .append("   ").append(s.slotBInjected ? "✅ 已注入" : "—").append("\n");
        b.append("文件        ").append(s.fileSize).append(" 字节\n");
        b.append("属主        ").append(nz(s.fileOwner)).append("\n");
        b.append("SHA256      ").append(shortSha(s.fileSha)).append("\n");
        b.append("备份        ").append(s.backupCount).append(" 份\n");
        b.append("App 运行中  ").append(s.appRunning ? "是" : "否").append("\n");
        b.append("载荷        ").append(payload.bytes).append(" 字节 / ").append(payload.text.length())
                .append(" 字符\n");
        b.append("载荷 SHA    ").append(shortSha(payload.sha)).append("\n");
        b.append("日志命中    ").append(s.logHits).append(" 次");
        if (s.logHits > 0) b.append("   ✅ 注入已真的进过请求体");
        b.append("\n");
        if (s.lastResponseHead != null && !s.lastResponseHead.isEmpty()) {
            b.append("\n模型最后输出：\n").append(trim(s.lastResponseHead, 300));
        }
        detailText.setText(b.toString());
    }

    // ──────────────────────────────────────────────────────────
    // 注入
    // ──────────────────────────────────────────────────────────
    private void confirmInject() {
        if (snap != null && snap.slotAInjected && snap.slotBInjected) {
            GlassDialog.create(this)
                    .icon(GlassDialog.ICON_WARN)
                    .title("重新注入？")
                    .subtitle("当前已破甲")
                    .message("重新注入会先剥离上一次的载荷再叠加，不会累积成多份，"
                            + "宿主原人设仍完整保留。\n\n继续？")
                    .positive("继续", (v) -> doInject())
                    .negative("取消", null)
                    .show();
        } else {
            doInject();
        }
    }

    private void doInject() {
        setBusy(true);
        statusText.setText("注入中…（会先停掉 Operit，约 5~10 秒）");
        statusText.setTextColor(resolveColor(R.color.state_info));
        showLog("");

        new Thread(() -> {
            final OperitPojaEditor.Result r = OperitPojaEditor.inject(this);
            ui.post(() -> {
                setBusy(false);
                showLog(r.output);
                if (r.success) {
                    statusText.setText("注入成功 · 已重启 Operit");
                    statusText.setTextColor(resolveColor(R.color.state_ok));
                    MainActivity.toast(this, "破甲已写入，点「自检」验证");
                    load();
                } else {
                    statusText.setText("注入失败：" + r.error);
                    statusText.setTextColor(resolveColor(R.color.state_error));
                }
            });
        }).start();
    }

    // ──────────────────────────────────────────────────────────
    // 自检：触发一次真实请求，从日志抓请求体锚点
    // ──────────────────────────────────────────────────────────
    private void doVerify() {
        setBusy(true);
        statusText.setText("自检中…（向 Operit 发一条真实消息，约 15 秒）");
        statusText.setTextColor(resolveColor(R.color.state_info));
        showLog("");

        new Thread(() -> {
            final OperitPojaEditor.Result r = OperitPojaEditor.triggerSelfTest("是否处于破甲状态");
            ui.post(() -> {
                setBusy(false);
                showLog(r.output);
                if (r.success) {
                    statusText.setText("自检通过 · 请求体已含破甲载荷");
                    statusText.setTextColor(resolveColor(R.color.state_ok));
                } else {
                    statusText.setText("自检未通过：日志里没找到载荷锚点");
                    statusText.setTextColor(resolveColor(R.color.state_warn));
                }
                load();
            });
        }).start();
    }

    // ──────────────────────────────────────────────────────────
    // 回滚
    // ──────────────────────────────────────────────────────────
    private void confirmRollback() {
        GlassDialog.create(this)
                .icon(GlassDialog.ICON_WARN)
                .title("回滚角色卡")
                .subtitle("会覆盖当前角色卡")
                .message("用最近一次备份覆盖当前角色卡，并重启 Operit。\n\n"
                        + "备份目录：\n" + OperitPojaEditor.BACKUP_DIR)
                .positive("回滚", (v) -> doRollback())
                .negative("取消", null)
                .show();
    }

    private void doRollback() {
        setBusy(true);
        statusText.setText("回滚中…");
        statusText.setTextColor(resolveColor(R.color.state_error));
        showLog("");

        new Thread(() -> {
            final OperitPojaEditor.Result r = OperitPojaEditor.rollback();
            ui.post(() -> {
                setBusy(false);
                showLog(r.output);
                statusText.setText(r.success ? "已回滚到最近备份" : "回滚失败：" + r.error);
                statusText.setTextColor(r.success ? resolveColor(R.color.state_ok) : resolveColor(R.color.state_error));
                load();
            });
        }).start();
    }

    // ──────────────────────────────────────────────────────────
    // 小工具
    // ──────────────────────────────────────────────────────────
    private void setBusy(boolean busy) {
        btnScan.setEnabled(!busy);
        btnInject.setEnabled(!busy);
        btnVerify.setEnabled(!busy);
        btnRollback.setEnabled(!busy);
    }

    private void showLog(String s) {
        if (s == null || s.trim().isEmpty()) {
            logBox.setVisibility(View.GONE);
            logText.setText("");
        } else {
            logBox.setVisibility(View.VISIBLE);
            logText.setText(s);
        }
    }

    private static String nz(String s) {
        return (s == null || s.isEmpty()) ? "--" : s;
    }

    private static String shortSha(String s) {
        if (s == null || s.isEmpty()) return "--";
        return s.length() > 16 ? s.substring(0, 16) + "…" : s;
    }

    private static String trim(String s, int n) {
        return s.length() > n ? s.substring(0, n) + "…" : s;
    }

    /** 解析 color 资源（配合 v5 主题：所有颜色收口到 colors.xml）*/
    private int resolveColor(int resId) {
        return androidx.core.content.ContextCompat.getColor(this, resId);
    }
}