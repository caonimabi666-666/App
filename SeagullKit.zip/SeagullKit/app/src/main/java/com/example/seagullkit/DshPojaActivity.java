package com.example.seagullkit;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;

/**
 * dsh 破甲模式 —— 一个按钮，进来就自己检测。
 *
 * <p><b>交互约定（2026-10 简化）</b>
 * <ul>
 *   <li>进页面自动扫描，不提供「扫描现场 / 自检」按钮 —— 用户不需要为
 *       「看看现在是什么状态」额外点一次</li>
 *   <li>只留一个「一键破甲」按钮：没装就装，已装就重装（覆盖）。
 *       装完自动重新检测，状态卡自己更新</li>
 *   <li>卸载也收进这个按钮的弹窗里（只在已装时出现），不再单独占一个按钮</li>
 * </ul>
 *
 * <p>装的是 assets/pj_mode_composition.yml 里的 persona prefix，注入到
 * 当前版本自带的 standard.patch.yml 骨架上，作为一条 insert 声明写进
 * $DSH_HOME/profiles/web/cordis.patch.yml。
 */
public class DshPojaActivity extends AppCompatActivity {

    private final Handler ui = new Handler(Looper.getMainLooper());

    private TextView statusText, detailText, logText;
    private View logBox;
    private MaterialButton btnApply;

    /** 最近一次扫描结果（null = 还没扫到） */
    private DshPojaEditor.Snapshot snap;
    private DshPojaEditor.Payload payload;
    /** 正在跑操作，防止重复点 */
    private boolean busy;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dsh_poja);

        statusText = findViewById(R.id.dp_status);
        detailText = findViewById(R.id.dp_detail);
        logText    = findViewById(R.id.dp_log);
        logBox     = findViewById(R.id.dp_log_box);
        btnApply   = findViewById(R.id.btn_dp_apply);

        payload = DshPojaEditor.loadPayload(this);

        btnApply.setOnClickListener(v -> {
            TapFeedback.tap(v);
            onApplyClicked();
        });

        // 进页面直接检测
        detect(false);
    }

    // ──────────────────────────────────────────────────────────
    // 自动检测
    // ──────────────────────────────────────────────────────────

    /**
     * 扫描现场并刷新界面。
     *
     * @param silent true = 后台静默刷新（装完自动刷、不闪状态文案）
     */
    private void detect(boolean silent) {
        // 前置门槛都在主线程判：包管理器查询很快，且要立刻反映到按钮上
        if (!DshTargets.isInstalled(this)) {
            statusText.setText("未检测到 DeepSeek Harness");
            statusText.setTextColor(resolveColor(R.color.state_error));
            detailText.setText("包名：" + DshTargets.PKG + "\n请先安装 DeepSeek Harness 并至少打开一次完成初始化");
            btnApply.setEnabled(false);
            btnApply.setText("一键破甲");
            return;
        }
        if (DshTargets.locateHome().isEmpty()) {
            statusText.setText("Harness 尚未初始化");
            statusText.setTextColor(resolveColor(R.color.state_error));
            detailText.setText("找不到 dsh home：\n/data/data/" + DshTargets.PKG
                    + "/files/payload/dshhome\n\n请先完整启动一次 Harness 让它自行初始化。");
            btnApply.setEnabled(false);
            btnApply.setText("一键破甲");
            return;
        }

        if (!silent) {
            statusText.setText("检测中…");
            statusText.setTextColor(resolveColor(R.color.text_body));
        }
        setBusy(true);

        new Thread(() -> {
            final boolean root = DshPojaEditor.hasRoot();
            final DshPojaEditor.Snapshot s = root ? DshPojaEditor.scan(DshPojaActivity.this) : null;
            ui.post(() -> {
                setBusy(false);
                if (!root) {
                    statusText.setText("需要 root 权限");
                    statusText.setTextColor(resolveColor(R.color.state_error));
                    detailText.setText("写 dsh 私有目录必须 su（优先 su -M）");
                    btnApply.setEnabled(false);
                    return;
                }
                if (s == null || !s.success) {
                    statusText.setText("检测失败：" + (s == null ? "未知" : s.error));
                    statusText.setTextColor(resolveColor(R.color.state_error));
                    detailText.setText(s == null ? "" : s.raw);
                    // 检测失败也允许点一次试试（可能只是扫描脚本出错）
                    btnApply.setEnabled(true);
                    btnApply.setText("一键破甲");
                    return;
                }
                snap = s;
                render(s);
            });
        }).start();
    }

    private void render(DshPojaEditor.Snapshot s) {
        boolean installed = s.installed && s.prefixOk;

        if (installed) {
            statusText.setText("破甲已生效 · patch 层就位");
            statusText.setTextColor(resolveColor(R.color.state_ok));
        } else if (s.installed) {
            statusText.setText("条目在但人设缺失 · 请重跑一次");
            statusText.setTextColor(resolveColor(R.color.state_warn));
        } else {
            statusText.setText("未破甲 · 点下方按钮写入");
            statusText.setTextColor(resolveColor(R.color.text_body));
        }

        StringBuilder b = new StringBuilder();
        b.append("patch 文件  ").append(nz(s.patchPath)).append("\n");
        b.append("patch 大小  ").append(s.patchBytes).append(" 字节")
                .append(s.patchParses ? "（yaml 可解析）" : "（解析失败！）").append("\n");
        b.append("preset 条目 ").append(s.installed
                ? "preset-" + DshPojaEditor.PRESET_ID + " 存在" : "不存在").append("\n");
        b.append("显示名      ").append(nz(s.presetDisplayName)).append("\n");
        b.append("插件行数    ").append(s.pluginRows).append(" 行\n");
        b.append("v5N 人设    ").append(s.prefixOk ? "命中 ✅" : "缺失 ❌").append("\n");
        b.append("版本骨架    ").append(s.bundleOk
                ? "standard.patch.yml 可用 ✅" : "缺失 ❌").append("\n");
        b.append("dsh 进程    ").append(s.dshRunning ? "运行中（需重启才生效）" : "未运行").append("\n");
        b.append("\n载荷        ").append(payload.size).append(" 字节 / ")
                .append(payload.rows).append(" 个顶层 row\n");
        b.append("载荷关键块  ").append(payload.blocksHit).append("/")
                .append(DshPojaEditor.CHECK_COUNT);
        b.append(payload.ok ? "   ✅" : "   ❌ 缺 " + join(payload.blocksMissing));
        detailText.setText(b.toString());

        btnApply.setEnabled(true);
        btnApply.setText(installed ? "重新破甲（覆盖）" : "一键破甲");
    }

    // ──────────────────────────────────────────────────────────
    // 唯一入口：一键破甲
    // ──────────────────────────────────────────────────────────

    private void onApplyClicked() {
        if (busy) return;
        boolean already = snap != null && snap.installed;
        if (already) {
            // 已装过：默认动作是重装，卸载作为次要选项放在弹窗里
            GlassDialog.create(this)
                    .icon(GlassDialog.ICON_GEAR)
                    .title("重新破甲")
                    .subtitle("覆盖现有 preset")
                    .message("会先整段替换 patch 层里属于本工具的那一段，原文件备份到\n"
                            + "$DSH_HOME/backups/时间戳/。\n\n"
                            + "官方 preset 与其它 patch 条目一字节不碰。\n\n"
                            + "装完需完全退出 DeepSeek Harness 再重开，新建会话选「"
                            + DshPojaEditor.PRESET_NAME + "」。")
                    .positive("重新破甲", v -> apply())
                    .neutral("卸载破甲", v -> confirmRemove())
                    .negative("取消", null)
                    .show();
        } else {
            apply();
        }
    }

    private void apply() {
        setBusy(true);
        statusText.setText("破甲写入中…");
        statusText.setTextColor(resolveColor(R.color.state_info));
        showLog(null);

        new Thread(() -> {
            final DshPojaEditor.Result r = DshPojaEditor.install(DshPojaActivity.this);
            ui.post(() -> {
                setBusy(false);
                if (r.success) {
                    MainActivity.toast(this, "破甲已写入 · 重启 dsh 生效");
                    // 静默刷新状态卡，不打断「成功」文案
                    detect(true);
                } else {
                    statusText.setText("写入失败：" + r.error);
                    statusText.setTextColor(resolveColor(R.color.state_error));
                    showLog(r.output);
                    btnApply.setEnabled(true);
                }
            });
        }).start();
    }

    private void confirmRemove() {
        GlassDialog.create(this)
                .icon(GlassDialog.ICON_WARN)
                .title("卸载破甲")
                .subtitle("整段移除 · 先备份")
                .message("patch 层里属于本工具的那一段会被整段删掉，\n"
                        + "删之前原文件备份到 $DSH_HOME/backups/时间戳/。\n\n"
                        + "其它 patch 条目（模型、工作区等）一字节不碰。\n\n"
                        + "删完需要完全退出 DeepSeek Harness 再重开。\n\n确定？")
                .positive("卸载", v -> remove())
                .negative("取消", null)
                .show();
    }

    private void remove() {
        setBusy(true);
        statusText.setText("卸载中…");
        statusText.setTextColor(resolveColor(R.color.state_error));
        showLog(null);

        new Thread(() -> {
            final DshPojaEditor.Result r = DshPojaEditor.uninstall(DshPojaActivity.this);
            ui.post(() -> {
                setBusy(false);
                if (r.success) {
                    MainActivity.toast(this, "已卸载破甲");
                    detect(true);
                } else {
                    statusText.setText("卸载失败：" + r.error);
                    statusText.setTextColor(resolveColor(R.color.state_error));
                    showLog(r.output);
                    btnApply.setEnabled(true);
                }
            });
        }).start();
    }

    // ──────────────────────────────────────────────────────────
    // 小工具
    // ──────────────────────────────────────────────────────────
    private void setBusy(boolean b) {
        busy = b;
        btnApply.setEnabled(!b);
    }

    /** null / 空串 = 收起日志盒 */
    private void showLog(String s) {
        if (s == null || s.trim().isEmpty()) {
            logBox.setVisibility(View.GONE);
            logText.setText("");
        } else {
            logBox.setVisibility(View.VISIBLE);
            logText.setText(s);
        }
    }

    private static String nz(String s) {
        return (s == null || s.isEmpty()) ? "--" : s;
    }

    private static String join(java.util.List<String> a) {
        if (a == null || a.isEmpty()) return "";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < a.size(); i++) {
            if (i > 0) b.append("、");
            b.append(a.get(i));
        }
        return b.toString();
    }

    private int resolveColor(int resId) {
        return androidx.core.content.ContextCompat.getColor(this, resId);
    }
}