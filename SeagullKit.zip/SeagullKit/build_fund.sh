#!/system/bin/sh
# ═══════════════════════════════════════════════════════════
# 科创板看板 · 编译 + 安装（在 AndroidIDE 终端里执行）
#   sh build_fund.sh   即可，无需额外参数
# ═══════════════════════════════════════════════════════════
RV=/data/data/com.tom.rv2ide/files
export JAVA_HOME=$RV/usr/lib/jvm/java-17-openjdk
export PATH=$JAVA_HOME/bin:$PATH
export GRADLE_USER_HOME=$RV/home/.gradle
export ANDROID_HOME=$RV/home/android-sdk
export ANDROID_SDK_ROOT=$ANDROID_HOME
cd /storage/emulated/0/AndroidIDEProjects/SeagullKit

# ═══════════════════════════════════════════════════════════
# aapt2 架构修正（2026-10-23）
#
# Gradle 从 maven 拉的 aapt2 是 x86-64 ELF，设备是 arm64，
# 直接 exec 会被 shell 当脚本解析，报：
#   aapt2[62]: syntax error: unexpected '('
#
# AndroidIDE 自带 arm64 静态版，拿出来用
# android.aapt2FromMavenOverride 指过去即可。
# 不要改 Gradle 缓存的 transform 目录 —— 会被判定为
# "immutable workspace modified" 而拒绝构建。
# ═══════════════════════════════════════════════════════════
AAPT2_ARM=/data/local/tmp/aapt2-arm64/aapt2
if [ ! -x "$AAPT2_ARM" ]; then
  SRC=$(ls /data/app/*/com.tom.rv2ide*/lib/arm64/libaapt2.so 2>/dev/null | head -1)
  if [ -n "$SRC" ]; then
    mkdir -p /data/local/tmp/aapt2-arm64
    cp "$SRC" "$AAPT2_ARM" && chmod 755 "$AAPT2_ARM"
    echo "=== 已准备 arm64 aapt2: $AAPT2_ARM ==="
  else
    echo "=== 警告：找不到 AndroidIDE 自带 aapt2，构建可能失败 ==="
  fi
fi
AAPT2_ARG=""
[ -x "$AAPT2_ARM" ] && AAPT2_ARG="-Pandroid.aapt2FromMavenOverride=$AAPT2_ARM"


echo "=== 清掉 fund 包旧 class（强制重编 DayPl/Holdings）==="
find app/build -path "*seagullkit/fund*" -name "*.class" -delete 2>/dev/null
rm -rf app/build/intermediates/javac/debug/classes/com/example/seagullkit/fund 2>/dev/null

echo "=== assembleDebug ==="
sh ./gradlew --no-daemon assembleDebug $AAPT2_ARG
RC=$?
if [ $RC -eq 0 ]; then
  APK=app/build/outputs/apk/debug/app-debug.apk
  ls -la $APK
  echo "✅ 编译成功"
else
  echo "❌ 编译失败"
fi
exit $RC
