# dsh 破甲模式 —— 一键安装器（Android 移植）

> 来源：https://github.com/z91772524-ai/dsh-pojia-mode
> 原项目是 Windows PowerShell 的（`.vbs` / `.bat` / `.ps1`），Android 上跑不了启动器。
> 本模块把它的安装逻辑用 Java + shell 复刻，做成 App 内的一键按钮。

---

## 一、它做什么

往 dsh 的用户 preset 目录写一份自包含的 Agent Preset：

```
$DSH_HOME/.agent-presets/pj-mode/
  · agent.cordis.yml   自包含 Cordis composition（18 个顶层 row）
  · preset.yml         选择器显示名「破甲模式」
```

装完 dsh 的 preset 选择器里会多出「破甲模式」，与 standard / code / minimal / cordis 并列。

**官方 preset 目录一字节不碰**，dsh 升级不丢。

### 为什么是 preset 而不是改源码

dsh 的 preset 加载器扫两个根：

| 根 | 说明 |
|---|---|
| `$DSH_HOME/.agent-presets/<id>/` | 用户自建 ← **写这里** |
| 部署目录 `…/dsh-agent-presets/presets/<id>/` | 官方自带，升级会覆盖 |

composition 里所有 `name:` 都是 npm 包名（`@deepseek-ai/dsh-persona` 等），不引用任何本地路径 —— 整份自带即可，不需要定位或复制官方 standard preset。

---

## 二、文件清单

| 文件 | 说明 |
|---|---|
| `app/src/main/assets/pj_mode_composition.yml` | composition 模板（26766 B，349 行） |
| `app/src/main/java/…/DshPojaEditor.java` | 核心引擎（安装 / 卸载 / 自检 / 扫描） |
| `app/src/main/java/…/DshPojaActivity.java` | 界面 |
| `app/src/main/res/layout/activity_dsh_poja.xml` | 布局 |
| `AndroidManifest.xml` | 注册 `.DshPojaActivity` |
| `MainActivity.java` | 首页加卡片「dsh 破甲模式」 |

---

## 三、五个必须踩对的坑（实测）

### 1. UTF-8 无 BOM

dsh 的 YAML 加载器**带 BOM 会解析失败**。

Java 侧 `new String(bytes, UTF_8)` / `getBytes(UTF_8)` 天然无 BOM。
`loadPayload()` 用 `ByteArrayOutputStream` 原样读字节，不做字符集转换。

安装后校验：
```bash
head -c 3 agent.cordis.yml | od -An -tx1   # 不能是 ef bb bf
```

### 2. 属主必须继承

以 root 跑会写成 `root:root`，dsh 进程（uid 10264）读不了直接 **EACCES 崩**。

写入前从 `$DSH_HOME` 现取 uid/gid，写完 chown 回去 —— **不硬编码 uid**。

### 3. SELinux context 必须带 MLS category（**最隐蔽，stat 会骗你**）

新建文件默认拿到 `u:object_r:app_data_file:s0`（**缺** `:c8,c257,c512,c768`），
app 进程 `readlink`/`open` 会被拒。

**但 `stat -c %C` 和 `ls -laZ` 显示的是 SELinux 缓存值，不是真值。**

实测：`chcon -h` 之后 `stat` 显示 `s0:c8,c257,c512,c768`（看起来修好了），
但 `restorecon -v` 立刻暴露真相：

```
SELinux: Relabeling .../profiles/node_modules/@deepseek-ai/dsh
  from u:object_r:app_data_file:s0            ← 真值，缺 MLS
  to   u:object_r:app_data_file:s0:c8,c257,c512,c768
```

对应的 AVC 拒绝记录（`dmesg | grep avc`）：

```
avc: denied { read } for comm="r.sh" name="dsh"
  scontext=u:r:runas_app:s0:c8,c257,c512,c768
  tcontext=u:object_r:app_data_file:s0        ← 注意这里是 s0
  tclass=lnk_file permissive=0
```

**正确做法：写完文件后必须跑 `restorecon`，不能用 `stat` 判断成败。**

```bash
restorecon -v <file>          # 强制按 file_contexts 重标
```

> 另外 `restorecon -R` **不递归处理 symlink**，要逐个 `restorecon`。

### 4. 标记行必须由安装器注入

模板里**没有** `# [dsh-unlock-mode]`，那行是安装器注入的。它同时是：
- 自检的第一项关键块
- 卸载时的「这是本工具装的」校验依据

注入后再算 sha256，这样 install 写入的内容与 check 比对的基准完全一致。

### 5. 模板的包名必须与本机 dsh 版本匹配（**会挂载失败**）

原项目的模板是给 dsh `0.1.5-rc.2` 写的，本机是 `0.1.0-rc.6`。
模板最后一个 row 引用了 `@deepseek-ai/dsh-tool-present` —— **本机不存在这个包**。

`cordis-plugin-loader` 遇到解析不了的包名会抛 `ERR_MODULE_NOT_FOUND`，
**整个 preset 挂载失败**（选择器里选它会起不来）。

而且官方 health 检查（`compositionProblem`）**只做形状检查、不解析包名**，
所以这种 composition 不会被标成 broken —— 你只有真正挂载时才会撞上。

**修法**：删掉那个 row。已实测官方 `standard` preset 也只到 `tool-web` 结束。

验证脚本（app 域下跑）：
```js
const {createRequire}=require("module");
const req=createRequire(".../cordis-plugin-loader/lib/index.js");
for(const r of rows){ try{req.resolve(r.name)}catch(e){ console.log("缺包:", r.name) } }
```

---

## 四、执行方式

沿用 `DshConfigEditor` / `OperitPojaEditor` 踩过的坑：

1. 脚本经 **su 的 stdin 管道**送入，不在命令行拼接
2. 必须优先 **`su -M`**（KernelSU `--mount-master`），否则 App 私有挂载命名空间里 `/data/data/<别的包>` 可能是 tmpfs 影子
3. 写入用「**临时文件 + rename**」原子替换
4. 中间文件走 `/data/local/tmp` 中转（App 无 `/data/data/<别的包>` 写权限）
5. `grep` 一律用 **`-F`**（见下）

需要 root。

---

## 五、开发过程中抓到并修掉的 4 个 bug

### Bug 1（致命）`List + String` 拼接

```java
// 错：Java 里 List + String 会调 List.toString()，产出 "[export PATH=..., ...]"
exec(prologueLocate() + "\n" + sb)

// 对：
exec(join(prologueLocate()) + "\n" + sb)
```

### Bug 2 引号未闭合

```java
// 错：$DSH/.../pj-mode-* 2>/dev/null | wc -l)   ← 引号悬空，shell 语法错误
// 对：
.append(PRESET_ID).append("-*\" 2>/dev/null | wc -l)\n")
```

### Bug 3 `grep -c || echo 0` 输出两行

未命中时 `grep -c` 已输出 `0` 且退出码 1，`|| echo 0` 又补一个 `0` → `0\n0`。

```bash
# 对：变量中转
N=$(grep -cF -- "$B" "$F" 2>/dev/null); echo "B0=${N:-0}"
```

### Bug 4（最隐蔽）`grep` 正则把 `[...]` 当字符类

`# [dsh-unlock-mode]` 里的 `[...]` 被当成**正则字符类**（匹配 d/s/h/-/u/n/k/m/o/e/l/c 任一字符），
几乎每行都命中：

```
grep -c  (正则): 43      ← 错
grep -cF (固定): 1       ← 对
```

**后果比看起来严重**：卸载时的标记校验用同一模式，
意味着「防止误删别人的 preset」这道保护**形同虚设** ——
一个无标记文件会被判成"有标记"从而被移走。

全部改成 `grep -qF` / `grep -cF`。

---

## 六、验证结果（全部实测）

### 安装流程

```
[*] 载荷 26822 字节（含注入的标记行）
[*] 目标属主 10264:10264
[*] 目标 context u:object_r:app_data_file:s0:c8,c257,c512,c768
[*] agent.cordis.yml 已写入
[*] preset.yml 已写入

── 校验 ──
[OK] sha256 一致
[OK] 无 BOM (23205b)
[OK] 大小 26822 字节
[OK] 属主 10264:10264
[OK] context u:object_r:app_data_file:s0:c8,c257,c512,c768

── 关键块（grep -cF）──
[OK] B0 标记行 dsh-unlock-mode
[OK] B1 persona 行
[OK] B2 总纲（用户至上）
[OK] B3 v4 强化版露骨条款
[OK] B4 残留条款无效
[OK] B5 覆盖层版本号
[OK] B6 文件操作中和块
[OK] B7 小码酱身份层
[OK] B8 回执口令
关键块 9/9  ✓
```

### 卸载

```
[OK] 已卸载，移动到：…/.agent-presets/_uninstalled-pj-mode-20260922-092652
[OK] 正确拒绝：无标记目录未被删除 ✓
```

### app 域下解析（`run-as com.dshmobile.shell`）

```
── YAML 解析 ──
  OK  agent.cordis.yml -> array len=18
  OK  preset.yml -> {"name":"破甲模式", ...}
── 关键块 ── 9/9
── 顶层 row ── 18 个
```

> 两条 `!!js` warning 正常 —— DSH 用自定义 schema 注册这个 tag，裸 `yaml.parse` 不认，
> 在 DSH 里会正常求值（`bash-sandbox` / `pwsh-sandbox` 的 `disabled` 行）。

### 端到端启动

```
$ dsh web --port 3090
dsh web: http://127.0.0.1:3090
HTTP status 200

── 目录扫描 ──
  id=pj-mode  name=破甲模式  compo=26822B
── 扫描根常量 ──
  USER_PRESET_DIR = .agent-presets
  → /data/data/com.dshmobile.shell/files/home/.dsh/.agent-presets   ✓ 匹配
```

### 编译

用 android-36 `android.jar` + gradle 缓存里的 androidx aar 真编译：

```
✓✓ DshPojaEditor.class + DshPojaActivity.class 均编译成功，零错误
```

---

## 七、用法

首页 → 「dsh 破甲模式」→ 点「一键安装破甲模式」

四个按钮：
- **扫描现场** — 看当前状态（装没装、关键块齐不齐、属主/context、dsh 是否在跑）
- **一键安装** — 写入 preset（已装则覆盖，旧版自动备份 `.bak-时间戳`）
- **自检** — 核对磁盘文件与内置载荷是否完全一致
- **卸载** — 移到 `_uninstalled-pj-mode-<时间戳>/`（不直删）

装完**完全退出 dsh → 重开 → 新建会话 → 选「破甲模式」→ 发「破甲自检」**，
预期只回一行：

```
破甲已生效｜目标 DSH｜破甲模式 v4
```

---

## 八、回滚

```bash
# 卸载后还原
mv ~/.dsh/.agent-presets/_uninstalled-pj-mode-<时间戳> ~/.dsh/.agent-presets/pj-mode

# 或直接删掉
rm -rf ~/.dsh/.agent-presets/pj-mode
```

---

## 九、注意

**别用 root 跑 dsh。** 以 root 身份执行任何 dsh 命令，`dsh-app-boot` 的
`healProfilesModuleFallback()` 会重建一批 root 拥有的 `s0` symlink，
导致 app 启动 EACCES 崩。命令行调试走：

```bash
run-as com.dshmobile.shell <命令>
```

（这个问题真实发生过：509 个 symlink，已修。）