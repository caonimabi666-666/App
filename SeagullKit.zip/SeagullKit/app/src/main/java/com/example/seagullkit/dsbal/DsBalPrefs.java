package com.example.seagullkit.dsbal;

import android.content.Context;
import android.content.SharedPreferences;

/** 设置存取。数值改动即时落盘，界面不设"保存"按钮。 */
public final class DsBalPrefs {

    private static final String FILE = "dsbal";
    private static final String K_KEY = "api_key";
    private static final String K_INTERVAL = "interval_sec";
    private static final String K_ALPHA = "alpha";
    private static final String K_X = "win_x";
    private static final String K_Y = "win_y";
    private static final String K_RUNNING = "want_running";
    private static final String K_LAST = "last_display";
    private static final String K_LAST_TS = "last_ts";
    private static final String K_LAST_OK = "last_ok";

    public static final int DEFAULT_INTERVAL = 30;

    private DsBalPrefs() {}

    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    public static String apiKey(Context c) { return sp(c).getString(K_KEY, ""); }

    public static void setApiKey(Context c, String v) {
        sp(c).edit().putString(K_KEY, v == null ? "" : v.trim()).apply();
    }

    public static int intervalSec(Context c) { return sp(c).getInt(K_INTERVAL, DEFAULT_INTERVAL); }

    public static void setIntervalSec(Context c, int v) {
        if (v < 5) v = 5;
        if (v > 3600) v = 3600;
        sp(c).edit().putInt(K_INTERVAL, v).apply();
    }

    public static float alpha(Context c) { return sp(c).getFloat(K_ALPHA, 0.92f); }

    public static void setAlpha(Context c, float v) { sp(c).edit().putFloat(K_ALPHA, v).apply(); }

    public static int winX(Context c) { return sp(c).getInt(K_X, -1); }

    public static int winY(Context c) { return sp(c).getInt(K_Y, 200); }

    public static void setWinPos(Context c, int x, int y) {
        sp(c).edit().putInt(K_X, x).putInt(K_Y, y).apply();
    }

    public static boolean wantRunning(Context c) { return sp(c).getBoolean(K_RUNNING, false); }

    public static void setWantRunning(Context c, boolean v) { sp(c).edit().putBoolean(K_RUNNING, v).apply(); }

    /** 服务每轮写入，供设置页做真实预览。 */
    public static void setLast(Context c, String display, boolean ok, long ts) {
        sp(c).edit()
                .putString(K_LAST, display)
                .putBoolean(K_LAST_OK, ok)
                .putLong(K_LAST_TS, ts)
                .apply();
    }

    public static String lastDisplay(Context c) { return sp(c).getString(K_LAST, null); }

    public static boolean lastOk(Context c) { return sp(c).getBoolean(K_LAST_OK, false); }

    public static long lastTs(Context c) { return sp(c).getLong(K_LAST_TS, 0L); }
}
